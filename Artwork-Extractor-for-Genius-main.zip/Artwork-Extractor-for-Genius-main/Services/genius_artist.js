chrome.storage.local.get([
    'Services/genius_artist.js',
    'isGeniusArtistArtistPage',
    'isGeniusArtistArtistPageZwsp',
    'isGeniusArtistArtistPageInfo',
    'isGeniusArtistArtistId',
    'isGeniusArtistAllSongsAlbumsPage',
    'isGeniusArtistAllSongsAlbumsPageMetadata',
    'isGeniusArtistAllSongsAlbumsPageZwsp',
    'isGeniusArtistFollowButton',
    'isGeniusArtistSpreadsheetButton',
    'isGeniusArtistSearchArtistMetadata',
    'isGeniusArtistRecords'
], async function (result) {
    const isGeniusArtistArtistPage = result.isGeniusArtistArtistPage ?? true;
    const isGeniusArtistArtistPageZwsp = result.isGeniusArtistArtistPageZwsp ?? true;
    const isGeniusArtistArtistPageInfo = result.isGeniusArtistArtistPageInfo ?? true;
    const isGeniusArtistArtistId = result.isGeniusArtistArtistId ?? false;
    const isGeniusArtistAllSongsAlbumsPage = result.isGeniusArtistAllSongsAlbumsPage ?? true;
    const isGeniusArtistAllSongsAlbumsPageMetadata = result.isGeniusArtistAllSongsAlbumsPageMetadata ?? true;
    const isGeniusArtistAllSongsAlbumsPageZwsp = result.isGeniusArtistAllSongsAlbumsPageZwsp ?? true;
    const isGeniusArtistFollowButton = result.isGeniusArtistFollowButton ?? false;
    const isGeniusArtistSpreadsheetButton = result.isGeniusArtistSpreadsheetButton ?? false;
    const isGeniusArtistSearchArtistMetadata = result.isGeniusArtistSearchArtistMetadata ?? true;
    const isGeniusArtistRecords = result.isGeniusArtistRecords ?? true;


    if (result['Services/genius_artist.js'] === false) {
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                  MAIN PROGRAM                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    main();

    async function main() {
        const profilePathPromise = new Promise(resolve => {
            chrome.storage.local.get("profilePath", ({ profilePath }) => {
                resolve(profilePath ?? null);
            });
        });

        const profilePath = await profilePathPromise;

        const isAllAlbums = /https:\/\/(genius\.com|genius-staging.com)\/artists\/[^/]+\/albums$/.test(window.location.href);
        const isAllSongs = /https:\/\/(genius\.com|genius-staging.com)\/artists\/[^/]+\/songs$/.test(window.location.href);
        const isArtist = /https:\/\/(genius\.com|genius-staging.com)\/artists\/[^/]+$/.test(window.location.href);
        const isArtistOld = /https:\/\/(genius\.com|genius-staging.com)\/artists\/[^/?]+\?react=0$/.test(window.location.href);
        const isArtistNew = /https:\/\/(genius\.com|genius-staging.com)\/artists\/[^/?]+\?react=1$/.test(window.location.href);

        const isUser = profilePath ? new RegExp(`https:\\/\\/(genius\\.com|genius-staging\\.com)${profilePath}$`).test(window.location.href) : false;

        if (isAllSongs || isAllAlbums) {
            const state = getScripts("window.__PRELOADED_STATE__");

            const artistId = state?.artistDiscography?.artist;

            if (isGeniusArtistAllSongsAlbumsPage || isGeniusArtistAllSongsAlbumsPageMetadata) checkAllSongsAlbumsPage(artistId, isAllSongs, isAllAlbums);
        } else if (isArtist || isArtistNew || isArtistOld) {
            const state = getScripts("window.__PRELOADED_STATE__");

            if (state?.currentPage === "profilePage") { //NEW
                const userId = state?.session?.currentUser;
                const artistId = state?.profilePage?.artist;
                const alternateNames = state?.entities?.artists?.[artistId]?.alternateNames;
                const baseName = state?.entities?.artists?.[artistId]?.nameComponents?.baseName;
                const headerImageUrl = state?.entities?.artists?.[artistId]?.headerImageUrl;
                const imageUrl = state?.entities?.artists?.[artistId]?.imageUrl;

                if (!userId || !artistId) return;

                if (isGeniusArtistArtistId) showArtistIdButtonNew(artistId, alternateNames);
                if (isGeniusArtistArtistPageInfo) showCoverInfoNew(headerImageUrl, imageUrl);

                if (isGeniusArtistFollowButton) FollowButtonArtistPageNew(artistId);
                if (isGeniusArtistSpreadsheetButton) getSpreadsheetNew(artistId, "artist");

                if (isGeniusArtistSearchArtistMetadata) searchArtistMetadata(baseName);

            } else if (state?.currentPage === "islands") { //OLD
                const { artistId, userId, artistData } = await getArtistInfo();
                if (!artistId || !userId || !artistData) return;

                if (isGeniusArtistArtistId) showArtistIdButton(artistId);
                if (isGeniusArtistArtistPageInfo) showCoverInfo(artistData);

                if (isGeniusArtistArtistPage) checkArtistCover(artistData);
                if (isGeniusArtistFollowButton) FollowButtonArtistPage(artistId);

                if (isGeniusArtistSpreadsheetButton) getSpreadsheet(artistId, "artist");
            }
        } else if (isUser) {
            const userId = document.documentElement.innerHTML.match(/var CURRENT_USER = JSON.parse\('{\\"id\\":(\d+)/)?.[1];
            if (!userId) return;

            if (isGeniusArtistRecords) showRecords();
            if (isGeniusArtistSpreadsheetButton) getSpreadsheet(userId, "user");
        } else {
            if (isGeniusArtistRecords) showRecords();
        }
    }

    async function getArtistInfo() {
        console.log("Run function getArtistInfo()");
        // Artist ID
        const artistId = document.querySelector("link[rel='alternate']")?.href?.split("/")?.pop();

        // User ID
        const userMatch = document.documentElement.innerHTML.match(/var CURRENT_USER = JSON.parse\('{\\"id\\":(\d+)/);
        const userId = userMatch?.[1];

        if (!artistId || !userId) return { artistId: null, userId, artistData: null };

        // Artist Data
        const response = await geniusFetch(`https://genius.com/api/artists/${artistId}`);
        const json = await response.json();

        return { artistId, userId, artistData: json.response.artist };
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                   Artist ID                                    //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    function showArtistIdButton(artistId) {
        const identityTextContainer = document.querySelector(".profile_identity-text");
        const artistIdContainer = document.createElement("div");
        artistIdContainer.className = "profile_identity-alternate_names";
        artistIdContainer.setAttribute("ng-if", "$ctrl.artist.alternate_names.length");
        artistIdContainer.style.marginBottom = "0.25rem";

        const artistIdElement = document.createElement("span");
        artistIdElement.className = "profile_identity-alternate_names";
        artistIdElement.style.fontSize = "0.75rem";

        const artistIdLink = document.createElement("a");
        artistIdLink.href = `https://genius.com/api/artists/${artistId}`;
        artistIdLink.target = "_blank";
        artistIdLink.textContent = artistId;
        artistIdLink.style.textDecoration = "none";
        artistIdLink.style.color = "inherit";
        artistIdLink.onmouseover = () => artistIdLink.style.textDecoration = "underline";
        artistIdLink.onmouseout = () => artistIdLink.style.textDecoration = "none";

        artistIdElement.textContent = "Artist ID: ";
        artistIdElement.appendChild(artistIdLink);
        artistIdContainer.appendChild(artistIdElement);
        identityTextContainer.appendChild(artistIdContainer);
    }

    function showArtistIdButtonNew(artistId, alternateNames) {
        const profileContainer = document.querySelector('h2[class^="ProfileContent-desktop__Heading-"]');
        if (!profileContainer) return;

        const infoBox = document.createElement('div');
        infoBox.style.textAlign = "center";
        infoBox.style.fontSize = '14px';
        infoBox.style.lineHeight = '1.4';

        const idRow = document.createElement('div');
        const idLabel = document.createElement('b');
        idLabel.textContent = "Artist ID: ";

        const idLink = document.createElement('a');
        idLink.href = `https://genius.com/api/artists/${artistId}`;
        idLink.target = "_blank";
        idLink.textContent = artistId;
        idLink.style.textDecoration = "none";
        idLink.style.color = "inherit";

        idLink.onmouseover = () => idLink.style.textDecoration = "underline";
        idLink.onmouseout = () => idLink.style.textDecoration = "none";

        idRow.appendChild(idLabel);
        idRow.appendChild(idLink);
        infoBox.appendChild(idRow);

        const altNamesArray = Array.isArray(alternateNames) ? alternateNames : [];

        if (altNamesArray.length > 0) {
            const akaRow = document.createElement('div');

            const akaLabel = document.createElement('b');
            akaLabel.textContent = altNamesArray.length >= 2 ? "AKAs: " : "AKA: ";

            const akaValue = document.createElement('span');
            akaValue.textContent = altNamesArray.join(', ');

            akaRow.appendChild(akaLabel);
            akaRow.appendChild(akaValue);
            infoBox.appendChild(akaRow);
        }

        profileContainer.insertAdjacentElement('beforebegin', infoBox);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                   COVER INFO                                   //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function showCoverInfo(artistData) {
        console.log("Run function showCoverInfo()");

        const avatar = document.querySelector('.user_avatar.profile_header-avatar');

        const header = document.querySelector('header[class^="PageGrid-desktop-"]');

        if (avatar) {
            avatar.style.position = "relative";

            const existing = avatar.querySelector('p[data-type="resolution-info"]');
            if (existing) existing.remove();

            const infoElement = createResolutionInfo(artistData);

            avatar.append(infoElement);
        }
    }

    function createResolutionInfo(artistData) {
        const resolutionMatch = artistData.image_url.match(/(\d+)x(\d+)/);
        const formatMatch = artistData.image_url.match(/\.(\w+)$/);

        const resolutionText = resolutionMatch?.[1] ? `${resolutionMatch[1]}x${resolutionMatch[2]}` : "No";
        const formatText = formatMatch?.[1] ? formatMatch[1].toUpperCase() : "Cover";

        const resolutionInfo = document.createElement('p');
        resolutionInfo.style.position = "absolute";
        resolutionInfo.style.top = "-1.5rem";
        resolutionInfo.style.left = "50%";
        resolutionInfo.style.transform = "translateX(-50%)";

        resolutionInfo.style.fontSize = "0.75rem";
        resolutionInfo.style.color = "#ffffff";
        resolutionInfo.style.fontWeight = "400";
        resolutionInfo.style.margin = "0";
        resolutionInfo.style.pointerEvents = "none";
        resolutionInfo.style.textShadow = "0 0 4px rgba(0,0,0,0.8), 0 0 8px rgba(0,0,0,0.6)";

        resolutionInfo.dataset.type = "resolution-info";
        resolutionInfo.textContent = `${resolutionText} ${formatText}`;

        return resolutionInfo;
    }

    function showCoverInfoNew(headerImageUrl, imageUrl) {
        const header = document.querySelector('header[class^="PageGrid-desktop-"]');
        if (!header) return;

        const existing = header.querySelector('div[data-type="resolution-info"]');
        if (existing) existing.remove();

        const infoElement = createResolutionInfoNew(headerImageUrl, imageUrl);
        header.insertBefore(infoElement, header.firstChild);
    }

    function createResolutionInfoNew(headerImageUrl, imageUrl) {
        const resolutionInfo = document.createElement('div');

        const avatar = document.querySelector('div[class*="ProfileHeader__ArtistAvatar-"]');
        if (!avatar) return;

        const classes = [...avatar.classList];
        const coverInfoClass = classes.slice(classes.findIndex(c => c.startsWith("ProfileHeader__ArtistAvatar-"))).map(c => c.replace("ArtistAvatar", "CoverInfo")).join(" ");

        resolutionInfo.className = coverInfoClass;
        resolutionInfo.style.textAlign = "center";
        resolutionInfo.style.marginBottom = "-0.75rem";
        resolutionInfo.style.color = "#ffffff";
        resolutionInfo.style.fontSize = "0.75rem";
        resolutionInfo.style.fontWeight = "bold";
        resolutionInfo.style.lineHeight = "1.2";
        resolutionInfo.style.whiteSpace = "pre-line";
        resolutionInfo.dataset.type = "resolution-info";

        const headerRes = headerImageUrl?.match(/(\d+)x(\d+)/);
        const headerFmt = headerImageUrl?.match(/\.(\w+)$/);
        const avatarRes = imageUrl?.match(/(\d+)x(\d+)/);
        const avatarFmt = imageUrl?.match(/\.(\w+)$/);

        const headerText = `Header: ${headerRes ? `${headerRes[1]}x${headerRes[2]}` : "No"} ${headerFmt ? headerFmt[1].toUpperCase() : "Cover"}`;
        const avatarText = `Avatar: ${avatarRes ? `${avatarRes[1]}x${avatarRes[2]}` : "No"} ${avatarFmt ? avatarFmt[1].toUpperCase() : "Cover"}`;

        resolutionInfo.textContent = `${headerText}\n${avatarText}`;

        return resolutionInfo;
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                COVER INDICATOR                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function checkArtistCover(artistData) {
        console.log("Run function checkArtistCover()");

        const container = document.querySelector('.profile_identity_and_description-action_row');
        const editArtistButton = Array.from(container.querySelectorAll('.square_button')).find(button => button.textContent.trim() === 'Edit');
        if (editArtistButton) {
            const iconsToRemove = editArtistButton.querySelectorAll('.inline_icon, .inline_icon--reading_size, .inline_icon--up_1');
            iconsToRemove.forEach(icon => icon.remove());

            let color, borderColor;
            const artistArt = artistData.image_url;

            if (artistArt.endsWith("1000x1000x1.png")) {
                color = '#99f2a5'; // Green
                borderColor = '#66bfa3';
            } else if (artistArt.startsWith("http://assets.genius.com/images/sharing_fallback.png")) {
                if (document.body.innerHTML.includes("https://assets.genius.com/images/default_avatar_300.png")) {
                    color = '#dddddd'; // Grey
                    borderColor = '#aaaaaa';
                } else {
                    color = '#ffff64'; // Yellow
                    borderColor = '#cccc00';
                }
            } else {
                color = '#fa7878'; // Red
                borderColor = '#a74d4d';
            }
            addColoredSquare(editArtistButton, color, borderColor);
            if (isGeniusArtistArtistPageZwsp) checkArtistTitleForZeroWidthSpace();
        }
    }

    function addBlackSquare(square) {
        const existingSquare = square.querySelector('.black-square');
        if (!existingSquare) {
            const blackSquare = document.createElement('span');
            blackSquare.className = 'black-square';
            blackSquare.style.cssText = `
            height: 8px;
            width: 8px;
            background-color: #2C2C2C;
            display: inline-block;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        `;
            square.appendChild(blackSquare);
        }
    }

    function addColoredSquare(button, color, borderColor) {
        const existingSquare = button.querySelector('.square-indicator');
        if (existingSquare) {
            existingSquare.style.backgroundColor = color;
            existingSquare.style.borderColor = borderColor;
        } else {
            const square = document.createElement('span');
            square.className = 'square-indicator';
            square.style.cssText = `
                font-variant: JIS04;
                height: 16px;
                width: 28px;
                display: inline-block;
                margin-left: -0.100rem;
                margin-right: 0.375rem;
                position: relative;
                background-color: ${color};
                border: 1px solid ${borderColor};
            `;
            button.style.cssText += `
                display: inline-flex;
                align-items: center;
                flex-wrap: nowrap;
            `;
            button.prepend(square);
        }
    }

    function checkArtistTitleForZeroWidthSpace() {
        const titleElement = document.querySelector('.profile_identity-name_iq_and_role_icon.u-hair_bottom_margin');
        if (titleElement) {
            const titleText = titleElement.textContent;
            if (titleText.includes('\u200B')) {
                const square = document.querySelector('.square-indicator');
                if (square) {
                    addBlackSquare(square);
                }
            }
        }
    }

    function checkListItemsForZeroWidthSpace() {

        const discographyList = document.querySelector('div[class^="DiscographyItemList__ListSingleContainer"]');
        if (!discographyList) return;

        const listItems = discographyList.querySelectorAll('a[class^="DiscographyItem__Container"]');

        listItems.forEach(item => {
            const h3Element = item.querySelector('h3[class^="DiscographyItem__Title"]');
            if (!h3Element) return;

            const h3Text = h3Element.textContent;
            const targetDiv = item.querySelector('div[class^="DiscographyItem__Content"]');
            if (!targetDiv) return;

            if (h3Text.startsWith('\u200B')) {
                targetDiv.style.borderLeft = '20px solid black';
                targetDiv.style.paddingLeft = '5px';
            }
            else if (h3Text.endsWith('\u200B')) {
                targetDiv.style.borderRight = '20px solid black';
                targetDiv.style.paddingRight = '5px';
            }
            else if (h3Text.includes('\u200B')) {
                targetDiv.style.borderTop = '20px solid black';
            }
        });
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 FOLLOW BUTTON                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function injectButtons(buttonConfigs) {
        const existingFollowButton = document.querySelector('follow-button a.square_button');
        const messageButton = document.querySelector('div.square_button[ng-click="$ctrl.show_conversation_modal = true"][ng-if="$ctrl.can_message_user"]');
        const editButton = document.querySelector('div.square_button[ng-if="$ctrl.can_edit_profile"][ng-click="$ctrl.show_edit_artist_profile_modal = true"]');

        if (!editButton) return;

        const buttonContainer = document.createElement('div');

        const createButton = ({ text, marginLeft = "0", width = "0", onClick }) => {
            const button = document.createElement('button');
            button.className = 'square_button u-bottom_margin';
            button.textContent = text;
            button.style.width = width;
            button.style.whiteSpace = 'nowrap';
            button.style.marginBottom = "0rem";
            button.style.marginLeft = marginLeft;

            if (onClick) {
                button.addEventListener('click', async () => {
                    await onClick(button);
                });
            }

            return button;
        };

        const createInput = ({ placeholder = "", marginLeft = "0" }) => {
            const input = document.createElement("input");
            input.type = "text";
            input.placeholder = placeholder;

            input.style.margin = "0";
            input.style.marginTop = "0.5rem";
            input.style.marginLeft = marginLeft;
            input.style.color = "#000000";
            input.style.width = "6.25rem";
            input.style.borderWidth = ".15rem";
            input.style.borderStyle = "solid";
            input.style.cursor = "text";
            input.style.display = "inline-block";
            input.style.fontFamily = "Programme, Arial, sans-serif";
            input.style.fontSize = "1rem";
            input.style.lineHeight = "1.4rem";
            input.style.textAlign = "center";
            input.style.padding = ".25rem .5rem";

            return input;
        };

        buttonConfigs.forEach(cfg => {
            if (cfg.type === "input") {
                const input = createInput(cfg);
                buttonContainer.appendChild(input);
                buttonContainer._songIdInput = input;
            } else {
                buttonContainer.appendChild(createButton(cfg));
            }
        });

        editButton.parentNode.insertBefore(buttonContainer, editButton.nextSibling);

        const buttonWidths = (existingFollowButton && messageButton) || (!existingFollowButton && !messageButton) ? '6.25rem' : '9.5rem';
        [existingFollowButton, messageButton, editButton].forEach(btn => btn && (btn.style.width = buttonWidths));
        editButton.style.justifyContent = 'center';
    }

    function insertButtons(wrapper, buttonConfigs) {
        const navBar = document.querySelector('nav[class^="ProfileContent-desktop__Section-"]');
        const referenceButton = navBar?.querySelector('button[class^="SmallButton__Container-"]');
        if (!referenceButton) return;

        const referenceClass = referenceButton.className;

        const createInput = ({ placeholder = "" }) => {
            const input = document.createElement("input");
            input.type = "text";
            input.placeholder = placeholder;

            input.style.width = "6.25rem";
            input.style.border = "1px solid";
            input.style.borderRadius = "1.25rem";
            input.style.fontFamily = "Programme, 'Programme Pan', Arial, sans-serif";
            input.style.textAlign = "center";

            return input;
        };

        buttonConfigs.forEach(cfg => {

            if (cfg.type === "input") {
                const input = createInput(cfg);

                wrapper._songIdInput = input;

                wrapper.appendChild(input);
                return;
            }

            const btn = document.createElement('button');
            btn.type = "button";
            btn.className = referenceClass;
            btn.textContent = cfg.text;

            btn.style.flex = "1";
            btn.style.justifyContent = "center";
            btn.style.backgroundColor = "white";
            btn.style.color = "black";
            btn.style.border = "1px solid";
            btn.style.borderColor = "black";

            btn.addEventListener("mouseover", () => {
                btn.style.backgroundColor = "black";
                btn.style.color = "white";
                btn.style.borderColor = "white";
            });

            btn.addEventListener("mouseout", () => {
                btn.style.backgroundColor = "white";
                btn.style.color = "black";
                btn.style.borderColor = "black";
            });

            if (cfg.onClick) {
                btn.addEventListener('click', () => cfg.onClick(btn));
            }

            wrapper.appendChild(btn);
        });
    }

    function FollowButtonArtistPage(artistId) {
        injectButtons([
            {
                text: 'Follow All Songs',
                width: "9.5rem",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = 'Following...';

                    const songIds = await fetchAllSongIds(artistId);
                    for (const songId of songIds) {
                        await toggleFollowSong(songId, 'follow');
                        await new Promise(r => setTimeout(r, 25));
                    }

                    button.textContent = 'Following';
                    button.disabled = false;
                }
            },
            {
                text: 'Unfollow All Songs',
                width: "9.5rem",
                marginLeft: "0.25rem",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = 'Unfollowing...';

                    const songIds = await fetchAllSongIds(artistId);
                    for (const songId of songIds) {
                        await toggleFollowSong(songId, 'unfollow');
                        await new Promise(r => setTimeout(r, 25));
                    }

                    button.textContent = 'Unfollowing';
                    button.disabled = false;
                }
            }
        ]);
    }

    function FollowButtonArtistPageNew(artistId) {
        const profileContainer = document.querySelector('h2[class^="ProfileContent-desktop__Heading-"]');
        if (!profileContainer) return;

        const wrapper = document.createElement('div');
        wrapper.style.display = "flex";
        wrapper.style.flexDirection = "row";
        wrapper.style.width = "100%";
        wrapper.style.gap = "0.5rem";

        insertButtons(wrapper, [
            {
                text: 'Follow All Songs',
                width: "9.5rem",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = 'Following...';

                    const songIds = await fetchAllSongIds(artistId);
                    for (const songId of songIds) {
                        await toggleFollowSong(songId, 'follow');
                        await new Promise(r => setTimeout(r, 25));
                    }

                    button.textContent = 'Following';
                    button.disabled = false;
                }
            },
            {
                text: 'Unfollow All Songs',
                width: "9.5rem",
                marginLeft: "0.25rem",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = 'Unfollowing...';

                    const songIds = await fetchAllSongIds(artistId);
                    for (const songId of songIds) {
                        await toggleFollowSong(songId, 'unfollow');
                        await new Promise(r => setTimeout(r, 25));
                    }

                    button.textContent = 'Unfollowing';
                    button.disabled = false;
                }
            }
        ]);
        profileContainer.parentNode.insertBefore(wrapper, profileContainer);
    }

    async function fetchAllSongIds(artistId) {
        let songIds = [], page = 1, perPage = 50;
        while (true) {
            const json = await geniusFetch(`https://genius.com/api/artists/${artistId}/songs?page=${page}&per_page=${perPage}`)
                .then(res => res.json());
            if (!json.response.songs?.length) break;

            songIds.push(...json.response.songs.map(song => song.api_path.match(/\/songs\/(\d+)/)[1]));
            page++;
        }
        return songIds;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               SPREADSHEET BUTTON                               //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function getSpreadsheet(id, type) {
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        const escapeCSV = (value) => {
            if (value == null) return "";
            const str = String(value);
            return `"${str.replace(/"/g, '""')}"`;
        };

        const getReleaseDate = (comp) => {
            if (!comp?.year) return "";
            const y = comp.year;
            const m = comp.month ? String(comp.month).padStart(2, "0") : null;
            const d = comp.day ? String(comp.day).padStart(2, "0") : null;

            if (y && m && d) return `${y}-${m}-${d}`;
            if (y && m) return `${y}-${m}`;
            return `${y}`;
        };

        const getLyricsStatus = (song) => {
            const hasFullDetails = song.current_user_metadata;

            if (!hasFullDetails) { // Button 1
                const isInstrumental = song.instrumental === true;

                if (isInstrumental) return "instrumental";
                if (song.lyrics_state === "complete") return "transcribed";

                return "not transcribed";
            } else { //Button 2
                const validated =
                    song.lyrics_marked_complete_by ||
                    song.lyrics_marked_staff_approved_by ||
                    song.lyrics_verified === true;

                const hasExcluded = song.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq");
                const hasPermission = song.current_user_metadata?.permissions?.includes("award_transcription_iq");
                const isInstrumental = song.instrumental === true;

                let status = "not transcribed";

                if (validated && hasExcluded) status = "completed";
                else if (song.lyrics_state === "complete" && isInstrumental) status = "instrumental";
                else if (song.lyrics_state === "complete" && hasExcluded) status = "transcribed";
                else if (song.lyrics_state === "complete" && hasPermission) status = "not awarded";

                return status;
            }
        };

        const getCoverInfo = (url) => {
            if (!url.startsWith("https://images.genius.com")) {
                return "No Genius Image";
            }

            const match = url.match(/\.([0-9]+x[0-9]+)x[0-9]+\.(\w+)$/i);

            if (!match) {
                return "No Genius Image";
            }

            const size = match[1];
            const ext = match[2].toUpperCase();

            return `${size} ${ext}`;
        };

        async function fetchPaginated({
            startPages,
            fetchPage,
            onPageData,
            updateButton,
            stopCondition
        }) {
            const workerCount = startPages.length;
            const workerFinished = Array(workerCount).fill(false);
            let counter = 0;

            async function worker(workerIndex, startPage) {
                let page = startPage;

                while (true) {
                    const json = await fetchPage(page);
                    counter++;
                    updateButton(counter);

                    const items = onPageData(json);

                    if (stopCondition(items)) {
                        workerFinished[workerIndex] = true;

                        if (workerFinished.every(f => f)) {
                            return;
                        }

                        return;
                    }

                    page += workerCount;
                }
            }

            const promises = [];
            for (let i = 0; i < workerCount; i++) {
                await sleep(50 * i);
                promises.push(worker(i, startPages[i]));
            }

            await Promise.all(promises);
        }

        async function fetchSongsPage(id, type, page, perPage = 50, maxRetries = 5) {
            let attempt = 0;

            while (true) {
                try {
                    const url =
                        type === "artist"
                            ? `https://genius.com/api/artists/${id}/songs?page=${page}&per_page=${perPage}`
                            : `https://genius.com/api/users/${id}/contributions/transcriptions?next_cursor=${page}&per_page=${perPage}`;

                    const res = await fetch(url);

                    if (res.status === 503) {
                        attempt++;
                        if (attempt > maxRetries) throw new Error(`503 after ${maxRetries} retries`);
                        await sleep(200 * attempt);
                        continue;
                    }

                    return await res.json();

                } catch (err) {
                    attempt++;
                    if (attempt > maxRetries) throw err;
                    await sleep(200 * attempt);
                }
            }
        }

        function parseSongsFromPage(json, type) {
            if (type === "artist") {
                return json.response?.songs || [];
            }

            const groups = json.response?.contribution_groups || [];
            const songs = [];

            for (const g of groups) {
                if (g.contribution_type !== "song") continue;
                for (const c of g.contributions) {
                    if (c._type === "song") songs.push(c);
                }
            }

            return songs;
        }

        async function fetchSongDetails(songId) {
            const res = await geniusFetch(`https://genius.com/api/songs/${songId}`);
            if (!res.ok) throw new Error(`Song ${songId}: ${res.status}`);
            return res.json();
        }

        async function fetchAllSongsDirect(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let allSongs = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchSongsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const songs = parseSongsFromPage(json, type);

                    for (const song of songs) {
                        allSongs.push({
                            ...song,
                            id: Number(song.id)
                        });
                    }

                    return songs;
                },
                stopCondition: (songs) => !songs.length
            });

            return allSongs.sort((a, b) => a.id - b.id);
        }

        async function fetchAllSongIds(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let ids = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchSongsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const songs = parseSongsFromPage(json, type);
                    for (const song of songs) ids.push(Number(song.id));
                    return songs;
                },
                stopCondition: (songs) => !songs.length
            });

            return ids.sort((a, b) => a - b);
        }

        async function fetchSongDetailsByIds(songIds, button) {
            const workers = 3;
            let results = [];
            let counter = 0;

            async function worker(startIndex) {
                let index = startIndex;
                while (index < songIds.length) {
                    const id = songIds[index];
                    try {
                        const json = await fetchSongDetails(id);
                        results.push({ id, data: json });
                        counter++;
                        button.textContent = `Song: ${counter}`;
                    } catch (err) {
                        console.error("Error fetching song", id, err);
                    }
                    index += workers;
                }
            }

            const promises = [];
            for (let i = 0; i < workers; i++) {
                await sleep(200 * i);
                promises.push(worker(i));
            }

            await Promise.all(promises);
            return results;
        }


        function filterSongIds(ids, text) {
            if (!text) return ids;

            if (text.includes(",")) {
                const list = text
                    .split(",")
                    .map(x => Number(x.trim()))
                    .filter(n => !isNaN(n));
                return ids.filter(id => list.includes(id));
            }

            if (text.includes("-") && text.indexOf("-") > 0) {
                const [minStr, maxStr] = text.split("-");
                const min = Number(minStr);
                const max = Number(maxStr);
                return ids.filter(id => id >= min && id <= max);
            }

            if (text.startsWith("-")) {
                const max = Number(text.slice(1));
                return ids.filter(id => id <= max);
            }

            const min = Number(text);
            return ids.filter(id => id >= min);
        }

        function exportCSV(rows, header, filename) {
            const csv = "\uFEFF" + header.join(",") + "\n" + rows.join("\n");
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
        }

        injectButtons([
            {
                text: "Spreadsheet 1",
                width: "8.5rem",
                onClick: async (button) => {
                    const songs = await fetchAllSongsDirect(id, type, button);

                    const header = [
                        "Song ID",
                        "Primary Artist",
                        "Song Title",
                        "URL",
                        "Release Date",
                        "Cover Image Info",
                        "Lyrics Status",
                        "Pageviews",
                    ];

                    const rows = songs.map(song =>
                        [
                            song.id,
                            escapeCSV(song.primary_artist_names),
                            escapeCSV(song.title),
                            escapeCSV(song.url),
                            escapeCSV(getReleaseDate(song.release_date_components)),
                            escapeCSV(getCoverInfo(song.song_art_image_url)),
                            escapeCSV(getLyricsStatus(song)),
                            escapeCSV(song.stats.pageviews),
                        ].join(",")
                    );

                    button.textContent = "Downloading CSV";
                    exportCSV(rows, header, `${type}_${id}_songs_1.csv`);
                    button.textContent = "Spreadsheet 1";
                }
            },
            {
                type: "input",
                placeholder: "Song ID",
                marginLeft: "0.25rem",
            },
            {
                text: "Spreadsheet 2",
                width: "8.5rem",
                marginLeft: "0.25rem",
                onClick: async (button) => {
                    const container = button.parentElement;
                    const input = container._songIdInput;
                    const filterText = input?.value.trim() || "";

                    const ids = await fetchAllSongIds(id, type, button);
                    const filteredIds = filterSongIds(ids, filterText);

                    let details = await fetchSongDetailsByIds(filteredIds, button);
                    details = details.sort((a, b) => a.id - b.id);

                    const header = [
                        "Song ID",
                        "Primary Artist",
                        "Song Title",
                        "URL",
                        "Release Date",
                        "Albums",
                        "Cover Image Info",
                        "Tags",
                        "Language",
                        "Lyrics Status",
                        "Pending LEPs",
                        "Pageviews",
                    ];

                    const rows = details.map(item => {
                        const song = item.data.response.song;
                        return [
                            song.id,
                            escapeCSV(song.primary_artist_names),
                            escapeCSV(song.title),
                            escapeCSV(song.url),
                            escapeCSV(getReleaseDate(song.release_date_components)),
                            escapeCSV(song.albums.map(album => album.name).join(", ")),
                            escapeCSV(getCoverInfo(song.song_art_image_url)),
                            escapeCSV([song.primary_tag?.name, ...song.tags.map(tag => tag.name).filter(name => name !== song.primary_tag?.name).sort((a, b) => a.localeCompare(b))].join(", ")),
                            escapeCSV(song.language),
                            escapeCSV(getLyricsStatus(song)),
                            escapeCSV(song.pending_lyrics_edits_count),
                            escapeCSV(song.stats.pageviews),
                        ].join(",");
                    });

                    button.textContent = "Downloading CSV";
                    exportCSV(rows, header, `${type}_${id}_songs_2.csv`);
                    button.textContent = "Spreadsheet 2";
                }
            }

        ]);
    }

    function getSpreadsheetNew(id, type) {
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        const escapeCSV = (value) => {
            if (value == null) return "";
            const str = String(value);
            return `"${str.replace(/"/g, '""')}"`;
        };

        const getReleaseDate = (comp) => {
            if (!comp?.year) return "";
            const y = comp.year;
            const m = comp.month ? String(comp.month).padStart(2, "0") : null;
            const d = comp.day ? String(comp.day).padStart(2, "0") : null;

            if (y && m && d) return `${y}-${m}-${d}`;
            if (y && m) return `${y}-${m}`;
            return `${y}`;
        };

        const getLyricsStatus = (song) => {
            const hasFullDetails = song.current_user_metadata;

            if (!hasFullDetails) { // Button 1
                const isInstrumental = song.instrumental === true;

                if (isInstrumental) return "instrumental";
                if (song.lyrics_state === "complete") return "transcribed";

                return "not transcribed";
            } else { //Button 2
                const validated =
                    song.lyrics_marked_complete_by ||
                    song.lyrics_marked_staff_approved_by ||
                    song.lyrics_verified === true;

                const hasExcluded = song.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq");
                const hasPermission = song.current_user_metadata?.permissions?.includes("award_transcription_iq");
                const isInstrumental = song.instrumental === true;

                let status = "not transcribed";

                if (validated && hasExcluded) status = "completed";
                else if (song.lyrics_state === "complete" && isInstrumental) status = "instrumental";
                else if (song.lyrics_state === "complete" && hasExcluded) status = "transcribed";
                else if (song.lyrics_state === "complete" && hasPermission) status = "not awarded";

                return status;
            }
        };

        const getCoverInfo = (url) => {
            if (!url.startsWith("https://images.genius.com")) {
                return "No Genius Image";
            }

            const match = url.match(/\.([0-9]+x[0-9]+)x[0-9]+\.(\w+)$/i);

            if (!match) {
                return "No Genius Image";
            }

            const size = match[1];
            const ext = match[2].toUpperCase();

            return `${size} ${ext}`;
        };

        async function fetchPaginated({
            startPages,
            fetchPage,
            onPageData,
            updateButton,
            stopCondition
        }) {
            const workerCount = startPages.length;
            const workerFinished = Array(workerCount).fill(false);
            let counter = 0;

            async function worker(workerIndex, startPage) {
                let page = startPage;

                while (true) {
                    const json = await fetchPage(page);
                    counter++;
                    updateButton(counter);

                    const items = onPageData(json);

                    if (stopCondition(items)) {
                        workerFinished[workerIndex] = true;

                        if (workerFinished.every(f => f)) {
                            return;
                        }

                        return;
                    }

                    page += workerCount;
                }
            }

            const promises = [];
            for (let i = 0; i < workerCount; i++) {
                await sleep(50 * i);
                promises.push(worker(i, startPages[i]));
            }

            await Promise.all(promises);
        }

        async function fetchSongsPage(id, type, page, perPage = 50, maxRetries = 5) {
            let attempt = 0;

            while (true) {
                try {
                    const url =
                        type === "artist"
                            ? `https://genius.com/api/artists/${id}/songs?page=${page}&per_page=${perPage}`
                            : `https://genius.com/api/users/${id}/contributions/transcriptions?next_cursor=${page}&per_page=${perPage}`;

                    const res = await fetch(url);

                    if (res.status === 503) {
                        attempt++;
                        if (attempt > maxRetries) throw new Error(`503 after ${maxRetries} retries`);
                        await sleep(200 * attempt);
                        continue;
                    }

                    return await res.json();

                } catch (err) {
                    attempt++;
                    if (attempt > maxRetries) throw err;
                    await sleep(200 * attempt);
                }
            }
        }

        async function fetchAlbumsPage(id, type, page, perPage = 50, maxRetries = 5) {
            let attempt = 0;

            while (true) {
                try {
                    const url =
                        type === "artist"
                            ? `https://genius.com/api/artists/${id}/albums?page=${page}&per_page=${perPage}`
                            : `https://genius.com/api/users/${id}/contributions/transcriptions?next_cursor=${page}&per_page=${perPage}`;

                    const res = await fetch(url);

                    if (res.status === 503) {
                        attempt++;
                        if (attempt > maxRetries) throw new Error(`503 after ${maxRetries} retries`);
                        await sleep(200 * attempt);
                        continue;
                    }

                    return await res.json();

                } catch (err) {
                    attempt++;
                    if (attempt > maxRetries) throw err;
                    await sleep(200 * attempt);
                }
            }
        }

        function parseSongsFromPage(json, type) {
            if (type === "artist") {
                return json.response?.songs || [];
            }

            const groups = json.response?.contribution_groups || [];
            const songs = [];

            for (const g of groups) {
                if (g.contribution_type !== "song") continue;
                for (const c of g.contributions) {
                    if (c._type === "song") songs.push(c);
                }
            }

            return songs;
        }

        function parseAlbumsFromPage(json, type) {
            if (type === "artist") {
                return json.response?.albums || [];
            }

            const groups = json.response?.contribution_groups || [];
            const albums = [];

            for (const g of groups) {
                if (g.contribution_type !== "album") continue;
                for (const c of g.contributions) {
                    if (c._type === "album") albums.push(c);
                }
            }

            return albums;
        }

        async function fetchSongDetails(songId) {
            const res = await geniusFetch(`https://genius.com/api/songs/${songId}`);
            if (!res.ok) throw new Error(`Song ${songId}: ${res.status}`);
            return res.json();
        }

        async function fetchAlbumDetails(albumId) {
            const res = await geniusFetch(`https://genius.com/api/albums/${albumId}`);
            if (!res.ok) throw new Error(`Album ${albumId}: ${res.status}`);
            return res.json();
        }

        async function fetchAllSongsDirect(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let allSongs = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchSongsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const songs = parseSongsFromPage(json, type);

                    for (const song of songs) {
                        allSongs.push({
                            ...song,
                            id: Number(song.id)
                        });
                    }

                    return songs;
                },
                stopCondition: (songs) => !songs.length
            });

            return allSongs.sort((a, b) => a.id - b.id);
        }

        async function fetchAllAlbumsDirect(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let allAlbums = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchAlbumsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const albums = parseAlbumsFromPage(json, type);

                    for (const album of albums) {
                        allAlbums.push({
                            ...album,
                            id: Number(album.id)
                        });
                    }

                    return albums;
                },
                stopCondition: (albums) => !albums.length
            });

            return allAlbums.sort((a, b) => a.id - b.id);
        }

        async function fetchAllSongIds(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let ids = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchSongsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const songs = parseSongsFromPage(json, type);
                    for (const song of songs) ids.push(Number(song.id));
                    return songs;
                },
                stopCondition: (songs) => !songs.length
            });

            return ids.sort((a, b) => a - b);
        }

        async function fetchAllAlbumIds(id, type, button) {
            const perPage = 50;
            const workers = [1, 2, 3];
            let ids = [];

            await fetchPaginated({
                startPages: workers,
                fetchPage: (page) => fetchAlbumsPage(id, type, page, perPage),
                updateButton: (count) => button.textContent = `Page: ${count}`,
                onPageData: (json) => {
                    const albums = parseAlbumsFromPage(json, type);
                    for (const album of albums) ids.push(Number(album.id));
                    return albums;
                },
                stopCondition: (albums) => !albums.length
            });

            return ids.sort((a, b) => a - b);
        }

        async function fetchSongDetailsByIds(songIds, button) {
            const workers = 3;
            let results = [];
            let counter = 0;

            async function worker(startIndex) {
                let index = startIndex;
                while (index < songIds.length) {
                    const id = songIds[index];
                    try {
                        const json = await fetchSongDetails(id);
                        results.push({ id, data: json });
                        counter++;
                        button.textContent = `Song: ${counter}`;
                    } catch (err) {
                        console.error("Error fetching song", id, err);
                    }
                    index += workers;
                }
            }

            const promises = [];
            for (let i = 0; i < workers; i++) {
                await sleep(200 * i);
                promises.push(worker(i));
            }

            await Promise.all(promises);
            return results;
        }

        async function fetchAlbumDetailsByIds(albumIds, button) {
            const workers = 3;
            let results = [];
            let counter = 0;

            async function worker(startIndex) {
                let index = startIndex;
                while (index < albumIds.length) {
                    const id = albumIds[index];
                    try {
                        const json = await fetchAlbumDetails(id);
                        results.push({ id, data: json });
                        counter++;
                        button.textContent = `Album: ${counter}`;
                    } catch (err) {
                        console.error("Error fetching album", id, err);
                    }
                    index += workers;
                }
            }

            const promises = [];
            for (let i = 0; i < workers; i++) {
                await sleep(200 * i);
                promises.push(worker(i));
            }

            await Promise.all(promises);
            return results;
        }

        function filterSongIds(ids, text) {
            if (!text) return ids;

            if (text.includes(",")) {
                const list = text
                    .split(",")
                    .map(x => Number(x.trim()))
                    .filter(n => !isNaN(n));
                return ids.filter(id => list.includes(id));
            }

            if (text.includes("-") && text.indexOf("-") > 0) {
                const [minStr, maxStr] = text.split("-");
                const min = Number(minStr);
                const max = Number(maxStr);
                return ids.filter(id => id >= min && id <= max);
            }

            if (text.startsWith("-")) {
                const max = Number(text.slice(1));
                return ids.filter(id => id <= max);
            }

            const min = Number(text);
            return ids.filter(id => id >= min);
        }

        function exportCSV(rows, header, filename) {
            const csv = "\uFEFF" + header.join(",") + "\n" + rows.join("\n");
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
        }

        const profileContainer = document.querySelector('h2[class^="ProfileContent-desktop__Heading-"]');
        if (!profileContainer) return;

        const wrapper = document.createElement('div');
        wrapper.style.display = "flex";
        wrapper.style.flexDirection = "row";
        wrapper.style.width = "100%";
        wrapper.style.gap = "0.5rem";

        insertButtons(wrapper, [
            // Spreadsheet 1
            {
                text: "Spreadsheet 1",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = "Downloading CSV";

                    const songs = await fetchAllSongsDirect(id, type, button);

                    const header = [
                        "Song ID",
                        "Primary Artist",
                        "Song Title",
                        "URL",
                        "Release Date",
                        "Cover Image Info",
                        "Lyrics Status",
                        "Pageviews",
                    ];

                    const rows = songs.map(song =>
                        [
                            song.id,
                            escapeCSV(song.primary_artist_names),
                            escapeCSV(song.title),
                            escapeCSV(song.url),
                            escapeCSV(getReleaseDate(song.release_date_components)),
                            escapeCSV(getCoverInfo(song.song_art_image_url)),
                            escapeCSV(getLyricsStatus(song)),
                            escapeCSV(song.stats.pageviews),
                        ].join(",")
                    );

                    exportCSV(rows, header, `${type}_${id}_songs_1.csv`);

                    button.textContent = "Spreadsheet 1";
                    button.disabled = false;
                }
            },

            // Input Field
            {
                type: "input",
                placeholder: "Song ID",
                marginLeft: "0.25rem",
            },

            // Spreadsheet 2
            {
                text: "Spreadsheet 2",
                marginLeft: "0.25rem",
                onClick: async (button) => {
                    button.disabled = true;
                    button.textContent = "Downloading CSV";

                    const input = wrapper._songIdInput;
                    const filterText = input?.value.trim() || "";

                    const ids = await fetchAllSongIds(id, type, button);
                    const filteredIds = filterSongIds(ids, filterText);

                    let details = await fetchSongDetailsByIds(filteredIds, button);
                    details = details.sort((a, b) => a.id - b.id);

                    const header = [
                        "Song ID",
                        "Primary Artist",
                        "Song Title",
                        "URL",
                        "Release Date",
                        "Albums",
                        "Cover Image Info",
                        "Tags",
                        "Language",
                        "Lyrics Status",
                        "Pending LEPs",
                        "Pageviews",
                    ];

                    const rows = details.map(item => {
                        const song = item.data.response.song;
                        return [
                            song.id,
                            escapeCSV(song.primary_artist_names),
                            escapeCSV(song.title),
                            escapeCSV(song.url),
                            escapeCSV(getReleaseDate(song.release_date_components)),
                            escapeCSV(song.albums.map(a => a.name).join(", ")),
                            escapeCSV(getCoverInfo(song.song_art_image_url)),
                            escapeCSV([
                                song.primary_tag?.name,
                                ...song.tags
                                    .map(tag => tag.name)
                                    .filter(name => name !== song.primary_tag?.name)
                                    .sort((a, b) => a.localeCompare(b))
                            ].join(", ")),
                            escapeCSV(song.language),
                            escapeCSV(getLyricsStatus(song)),
                            escapeCSV(song.pending_lyrics_edits_count),
                            escapeCSV(song.stats.pageviews),
                        ].join(",");
                    });

                    exportCSV(rows, header, `${type}_${id}_songs_2.csv`);

                    button.textContent = "Spreadsheet 2";
                    button.disabled = false;
                }
            }
        ]);

        const wrapper2 = document.createElement('div');
        wrapper2.style.display = "flex";
        wrapper2.style.flexDirection = "row";
        wrapper2.style.width = "100%";
        wrapper2.style.gap = "0.5rem";

        const translationArtists = [
            "https://genius.com/artists/Genius-afrikaanse-vertalings",
            "https://genius.com/artists/Genius-perkthime-ne-shqip",
            "https://genius.com/artists/Genius-amharic-translations",
            "https://genius.com/artists/Genius-aragonese-translations",
            "https://genius.com/artists/Genius-asturian-translations",
            "https://genius.com/artists/Genius-arabic-translations",
            "https://genius.com/artists/Genius-armenian-translations",
            "https://genius.com/artists/Genius-osterreichische-ubersetzungen",
            "https://genius.com/artists/Genius-azrbaycan-trcum",
            "https://genius.com/artists/Genius-bashkir-translations",
            "https://genius.com/artists/Genius-itzulpena-euskarara",
            "https://genius.com/artists/Genius-belarusian-translations",
            "https://genius.com/artists/Genius-bengali-translations",
            "https://genius.com/artists/Genius-bosanski-prijevodi",
            "https://genius.com/artists/Genius-brasil-traducoes",
            "https://genius.com/artists/Genius-bulgarian-translations",
            "https://genius.com/artists/Genius-burmese-translations",
            "https://genius.com/artists/Genius-tradusons-na-kriolu-kabuverdianu",
            "https://genius.com/artists/Genius-traduccions-al-catala",
            "https://genius.com/artists/Genius-cebuano-translations",
            "https://genius.com/artists/Genius-cherokee-translations",
            "https://genius.com/artists/Genius-chinese-translations",
            "https://genius.com/artists/Genius-hrvatski-prijevodi",
            "https://genius.com/artists/Genius-ceske-preklady",
            "https://genius.com/artists/Genius-danske-oversttelser",
            "https://genius.com/artists/Genius-nederlandse-vertalingen",
            "https://genius.com/artists/Genius-english-translations",
            "https://genius.com/artists/Genius-eestikeelsed-tolked",
            "https://genius.com/artists/Genius-farsi-translations",
            "https://genius.com/artists/Genius-pagsasalin-sa-filipino",
            "https://genius.com/artists/Genius-suomenkielinen-kaannos",
            "https://genius.com/artists/Genius-traductions-francaises",
            "https://genius.com/artists/Genius-traducions-ao-galego",
            "https://genius.com/artists/Genius-georgian-translations",
            "https://genius.com/artists/Genius-deutsche-ubersetzungen",
            "https://genius.com/artists/Genius-greek-translations",
            "https://genius.com/artists/Genius-guarani-translations",
            "https://genius.com/artists/Genius-unuhi-olelo-hawaii",
            "https://genius.com/artists/Genius-hebrew-translations",
            "https://genius.com/artists/Genius-hochdeutsche-ubersetzungen",
            "https://genius.com/artists/Genius-hindi-translations",
            "https://genius.com/artists/Genius-magyar-forditasok",
            "https://genius.com/artists/Genius-islensk-yingar",
            "https://genius.com/artists/Genius-ilocano-translations",
            "https://genius.com/artists/Genius-terjemahan-indonesia",
            "https://genius.com/artists/Genius-inuktitut-translations",
            "https://genius.com/artists/Genius-aistriuchain-gaeilge",
            "https://genius.com/artists/Genius-traduzioni-italiane",
            "https://genius.com/artists/Genius-japanese-translations",
            "https://genius.com/artists/Genius-kannada-translations",
            "https://genius.com/artists/Genius-kazakh-translations",
            "https://genius.com/artists/Genius-khmer-translations",
            "https://genius.com/artists/Genius-korean-translations",
            "https://genius.com/artists/Genius-kurdish-translations",
            "https://genius.com/artists/Genius-translationes-latina",
            "https://genius.com/artists/Genius-latviesu-tulkojums",
            "https://genius.com/artists/Genius-lietuviskos-vertimai",
            "https://genius.com/artists/Genius-letzebuergesch-iwwersetzungen",
            "https://genius.com/artists/Genius-makedonski-prevodi",
            "https://genius.com/artists/Terjemahan-bahasa-melayu-genius",
            "https://genius.com/artists/Genius-malayalam-translations",
            "https://genius.com/artists/Genius-mongolian-translations",
            "https://genius.com/artists/Genius-nepali-translations",
            "https://genius.com/artists/Genius-liphetolelo-yasesotho",
            "https://genius.com/artists/Genius-norske-oversettelser",
            "https://genius.com/artists/Genius-pashto-translations",
            "https://genius.com/artists/Genius-plattdeutsche-ubersetzungen",
            "https://genius.com/artists/Polskie-tumaczenia-genius",
            "https://genius.com/artists/Genius-portugal-traducoes",
            "https://genius.com/artists/Genius-traducions-ao-galego-reintegrado",
            "https://genius.com/artists/Genius-traduceri-in-romana",
            "https://genius.com/artists/Genius-russian-translations",
            "https://genius.com/artists/Genius-sakha-translations",
            "https://genius.com/artists/Genius-samoan-translations",
            "https://genius.com/artists/Genius-srpski-prevodi",
            "https://genius.com/artists/Genius-sinhala-translations",
            "https://genius.com/artists/Genius-slovenske-preklady",
            "https://genius.com/artists/Genius-slovenski-prevod",
            "https://genius.com/artists/Genius-traducciones-al-espanol",
            "https://genius.com/artists/Genius-swahili-translations",
            "https://genius.com/artists/Genius-svenska-oversattningar",
            "https://genius.com/artists/Genius-tamazight-translations",
            "https://genius.com/artists/Genius-tamil-translations",
            "https://genius.com/artists/Genius-tatar-translations",
            "https://genius.com/artists/Genius-telugu-translations",
            "https://genius.com/artists/Genius-thai-translations",
            "https://genius.com/artists/Genius-toki-pona-pi-toki-ante",
            "https://genius.com/artists/Genius-turkce-ceviriler",
            "https://genius.com/artists/Genius-twi-kasadan",
            "https://genius.com/artists/Genius-ukrainian-translations",
            "https://genius.com/artists/Genius-urdu-translations",
            "https://genius.com/artists/Genius-ozbekcha-tarjimalar",
            "https://genius.com/artists/Genius-ban-dich-tieng-viet",
            "https://genius.com/artists/Genius-cyfieithiadau-cymraeg",
            "https://genius.com/artists/Genius-izinguqulelo-yesixhosa",
            "https://genius.com/artists/Genius-romanizations"
        ];

        const current = window.location.href;
        const isTranslationArtist = translationArtists.some(url => current.startsWith(url));

        if (isTranslationArtist) {
            insertButtons(wrapper2, [
                // Spreadsheet 3
                {
                    text: "Spreadsheet 3",
                    onClick: async (button) => {
                        button.disabled = true;
                        button.textContent = "Downloading CSV";

                        const albums = await fetchAllAlbumsDirect(id, type, button);
                        console.log("Fetched albums:", albums);

                        const header = [
                            "Album ID",
                            "Primary Artist",
                            "Album Title",
                            "URL",
                            "Release Date",
                            "Cover Image Info",
                        ];

                        const rows = albums.map(album =>
                            [
                                album.id,
                                escapeCSV(album.primary_artist_names),
                                escapeCSV(album.name),
                                escapeCSV(album.url),
                                escapeCSV(getReleaseDate(album.release_date_components)),
                                escapeCSV(getCoverInfo(album.cover_art_url)),
                            ].join(",")
                        );

                        exportCSV(rows, header, `${type}_${id}_albums_3.csv`);

                        button.textContent = "Spreadsheet 3";
                        button.disabled = false;
                    }
                },

                // Input Field
                {
                    type: "input",
                    placeholder: "Album ID",
                    marginLeft: "0.25rem",
                },

                // Spreadsheet 4
                {
                    text: "Spreadsheet 4",
                    marginLeft: "0.25rem",
                    onClick: async (button) => {
                        button.disabled = true;
                        button.textContent = "Downloading CSV";

                        const input = wrapper._songIdInput;
                        const filterText = input?.value.trim() || "";

                        const ids = await fetchAllAlbumIds(id, type, button);
                        const filteredIds = filterSongIds(ids, filterText);

                        let details = await fetchAlbumDetailsByIds(filteredIds, button);
                        details = details.sort((a, b) => a.id - b.id);

                        const header = [
                            "Album ID",
                            "Primary Artist",
                            "Album Title",
                            "URL",
                            "Release Date",
                            "Cover Image Info",
                            "Language",
                            "Translation Of",
                            "Translation Of URL"
                        ];

                        const rows = details.map(item => {
                            const album = item.data.response.album;
                            return [
                                album.id,
                                escapeCSV(album.primary_artist_names),
                                escapeCSV(album.name),
                                escapeCSV(album.url),
                                escapeCSV(getReleaseDate(album.release_date_components)),
                                escapeCSV(getCoverInfo(album.cover_art_url)),
                                escapeCSV(album.language),
                                escapeCSV(album.translation_of ? `${album.translation_of.primary_artist_names} - ${album.translation_of.name}` : ""),
                                escapeCSV(album.translation_of ? album.translation_of.url : "")
                            ].join(",")
                        });

                        exportCSV(rows, header, `${type}_${id}_albums_4.csv`);

                        button.textContent = "Spreadsheet 4";
                        button.disabled = false;
                    }
                }
            ]);
        }

        profileContainer.parentNode.insertBefore(wrapper, profileContainer);
        profileContainer.parentNode.insertBefore(wrapper2, profileContainer);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                             SEARCH ARTISTMETADATA                              //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    function searchArtistMetadata(baseName) {
        console.log("Run function searchArtistMetadata()");

        const observer = new MutationObserver(() => {
            const modal = document.querySelector('form[class^="MetadataModal-shared__MetadataModalForm"]');
            if (!modal) return;

            const streamingSection = modal.querySelector('#collapsible-streaming_links-content');
            if (!streamingSection) return;

            const fields = streamingSection.querySelectorAll('div[class^="Field-shared__FieldControlWithLabel-"]');

            fields.forEach(row => {
                const labelSpan = row.querySelector('span[class^="Field-shared__FieldLabel-"]');
                if (!labelSpan) return;

                const innerLabel = row.querySelector('span[class^="EditLinksGrid__LabelWithIcon-"]');
                if (!innerLabel) return;

                const service = innerLabel.textContent.trim().toLowerCase();
                if (service.includes("shazam")) return;

                if (labelSpan.querySelector(".metadata-search-button")) return;

                const btn = document.createElement("button");
                btn.type = "button";
                btn.className = "metadata-search-button";
                btn.textContent = "Search ⤤";
                btn.style.marginLeft = "auto";

                btn.addEventListener("mouseenter", () => { btn.style.textDecoration = "underline"; });
                btn.addEventListener("mouseleave", () => { btn.style.textDecoration = "none"; });

                btn.addEventListener("click", () => {
                    const SEARCH_URLS = {
                        "apple music": n => `https://music.apple.com/search?term=${encodeURIComponent(n)}`,
                        "spotify": n => `https://open.spotify.com/search/${encodeURIComponent(n)}`,
                        "youtube": n => `https://www.youtube.com/results?search_query=${encodeURIComponent(n)}`,
                        "tidal": n => `https://listen.tidal.com/search?q=${encodeURIComponent(n)}`,
                        "amazon music": n => `https://music.amazon.com/search/${encodeURIComponent(n)}`,
                        "bandcamp": n => `https://bandcamp.com/search?q=${encodeURIComponent(n)}`,
                        "soundcloud": n => `https://soundcloud.com/search?q=${encodeURIComponent(n)}`,
                    };

                    const key = Object.keys(SEARCH_URLS).find(k => service.includes(k));
                    if (!key) return;

                    const url = SEARCH_URLS[key](baseName);

                    window.open(url, "_blank");
                });

                labelSpan.appendChild(btn);
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                            ALL SONGS / ALBUMS PAGES                            //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function checkAllSongsAlbumsPage(artistId, isAllSongs, isAllAlbums) {
        console.log("Run function checkAllSongsAlbumsPage()");

        let cachedSongs = null;
        let cachedAlbums = null;
        let items = [];
        let entriesLoaded = false;
        let metadataToggleActive = false;

        function injectMetadataToggle() {
            const sortContainer = document.querySelector('div[class^="ListSection-desktop__Sort-"]');
            if (!sortContainer) return;

            if (document.getElementById('metadataToggleSwitch')) return;

            const wrapper = document.createElement("label");
            wrapper.id = "metadataToggleSwitch";
            wrapper.style.display = "flex";
            wrapper.style.alignItems = "center";
            wrapper.style.gap = "0.35rem";
            wrapper.style.cursor = "pointer";
            wrapper.style.marginLeft = "auto";
            wrapper.style.marginRight = "1rem";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";

            Object.assign(checkbox.style, {
                appearance: "none",
                border: "1px solid #000",
                backgroundColor: "transparent",
                width: "0.75rem",
                height: "0.75rem",
                cursor: "pointer"
            });

            const checkSvg =
                "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")";

            const updateCheckboxStyle = () => {
                if (checkbox.checked) {
                    checkbox.style.backgroundColor = "#000";
                    checkbox.style.backgroundImage = checkSvg;
                } else {
                    checkbox.style.backgroundColor = "transparent";
                    checkbox.style.backgroundImage = "none";
                }
            };

            checkbox.addEventListener("change", () => {
                metadataToggleActive = checkbox.checked;
                updateCheckboxStyle();
            });

            const label = document.createElement("span");
            label.textContent = "Pull Song Data";
            label.style.fontSize = "0.75rem";

            wrapper.appendChild(checkbox);
            wrapper.appendChild(label);

            sortContainer.parentNode.insertBefore(wrapper, sortContainer);
        }

        injectMetadataToggle();

        async function fetchAll(artistId, type) {
            const results = [];
            const workers = 5;
            const perPage = 50;

            async function worker(startPage) {
                for (let page = startPage; ; page += workers) {
                    const res = await fetch(
                        `https://genius.com/api/artists/${artistId}/${type}?page=${page}&per_page=${perPage}&sort=popularity&text_format=html%2Cmarkdown`
                    );

                    if (!res.ok) break;

                    const json = await res.json();
                    const items = json.response[type];

                    if (!items?.length) break;

                    results.push(...items);
                }
            }

            const promises = [];
            for (let i = 1; i <= workers; i++) {
                await new Promise(r => setTimeout(r, 250 * (i - 1)));
                promises.push(worker(i));
            }

            await Promise.all(promises);
            return results;
        }

        async function checkAllEntriesAndFetchFunctions(artistId) {
            if (isAllSongs) {
                if (!cachedSongs) cachedSongs = await fetchAll(artistId, "songs");
                items = cachedSongs;
            } else if (isAllAlbums) {
                if (!cachedAlbums) cachedAlbums = await fetchAll(artistId, "albums");
                items = cachedAlbums;
            }

            return items;
        }

        function injectPullDataButton() {
            const sortContainer = document.querySelector('div[class^="ListSection-desktop__Sort-"]');
            if (!sortContainer) return;

            if (document.getElementById('pullDataButton')) return;

            const smallButton = document.querySelector('[class^="SmallButton__Container-"]');
            if (!smallButton) return;

            const triggerBtn = document.createElement("button");
            triggerBtn.id = "pullDataButton";
            triggerBtn.type = "button";
            triggerBtn.className = smallButton.className;
            triggerBtn.textContent = "Pull Data";
            triggerBtn.style.marginRight = "1rem";

            sortContainer.parentNode.insertBefore(triggerBtn, sortContainer);

            triggerBtn.addEventListener("click", async () => {
                triggerBtn.textContent = "Loading…";
                await checkAllEntriesAndFetchFunctions(artistId);
                entriesLoaded = true;
                triggerBtn.style.display = "none";
            });
        }

        injectPullDataButton();



        async function checkCoverImage() {
            let updates = [];

            const discographyList = document.querySelector('ul[class^="DiscographyItemList__ListSingleContainer"]');
            if (!discographyList) return;

            const listItems = discographyList.querySelectorAll('a[class^="DiscographyItem__Container"]');
            const itemMap = new Map(items.map(item => [item.url, item]));

            listItems.forEach((item) => {
                const targetDiv = item.querySelector('div[class^="DiscographyItem__CoverArt"]');
                if (!targetDiv) return;

                if (['#99f2a5', '#fa7878', '#dddddd'].includes(targetDiv.style.backgroundColor)) return;

                const itemLink = item.href;
                let artImageUrl, artistImageUrl;

                if (itemLink && itemMap.has(itemLink)) {
                    const titleMatch = itemMap.get(itemLink);
                    console.log("Match found for URL:", itemLink, titleMatch);
                    if (isAllSongs) {
                        artImageUrl = titleMatch.song_art_image_url;
                        artistImageUrl = titleMatch.primary_artist.image_url;
                    } else if (isAllAlbums) {
                        artImageUrl = titleMatch.cover_art_url;
                        artistImageUrl = titleMatch.artist.image_url;
                    }
                }

                let color;
                if (artImageUrl === artistImageUrl ||
                    artImageUrl.startsWith('https://assets.genius.com/images/default_cover_art.png?') ||
                    artImageUrl.startsWith('https://assets.genius.com/images/default_cover_image.png?')) {
                    color = '#dddddd';
                } else if (artImageUrl.endsWith('1000x1000x1.png')) {
                    color = '#99f2a5';
                } else {
                    color = '#ff7878';
                }

                updates.push({ targetDiv, color });
            });

            return updates;
        }

        const cachedSongData = new Map();
        async function checkMetadata() {
            const container = document.querySelector('ul[class^="DiscographyItemList__ListSingleContainer"]');
            if (!container) return;

            const itemsDom = container.querySelectorAll('a[class^="DiscographyItem__Container"]');

            const targetLinks = Array.from(itemsDom)
                .map(a => a.href)
                .filter(href => href.startsWith("https://genius.com/") && (href.endsWith("-lyrics") || href.endsWith("-annotated")));

            const matchedSongs = items.filter(song => targetLinks.includes(song.url));
            const uncachedSongs = matchedSongs.filter(song => !cachedSongData.has(song.id));

            const chunkSize = 5;
            const delayMs = 400;

            for (let i = 0; i < uncachedSongs.length; i += chunkSize) {
                const chunk = uncachedSongs.slice(i, i + chunkSize);

                const chunkResults = await Promise.all(
                    chunk.map(song =>
                        geniusFetch(`https://genius.com/api/songs/${song.id}`)
                            .then(res => res.json())
                            .then(json => {
                                const songData = json.response.song;
                                cachedSongData.set(song.id, songData);
                                return { song, songData };
                            })
                            .catch(error => {
                                console.warn(`Error fetching song ${song.id}:`, error);
                                return null;
                            })
                    )
                );

                chunkResults.filter(Boolean).forEach(({ song, songData }) => {
                    updateSongUI(song, songData);
                });

                if (i + chunkSize < uncachedSongs.length) {
                    await new Promise(resolve => setTimeout(resolve, delayMs));
                }
            }

            matchedSongs
                .filter(song => cachedSongData.has(song.id))
                .forEach(song => {
                    const songData = cachedSongData.get(song.id);
                    updateSongUI(song, songData);
                });
        }

        function updateSongUI(song, songData) {
            const discographyList = document.querySelector('ul[class^="DiscographyItemList__ListSingleContainer"]');
            if (!discographyList) return;

            const link = discographyList.querySelector(`a[class^="DiscographyItem__Container"][href="${song.url}"]`);
            if (!link) return;

            const infoContainer = link.querySelector('div[class^="DiscographyItem__Content"]');
            if (!infoContainer) return;

            const lyricsAreValidated =
                songData.lyrics_marked_complete_by ||
                songData.lyrics_marked_staff_approved_by ||
                songData.lyrics_verified === true;

            if (lyricsAreValidated &&
                songData.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {

                infoContainer.style.backgroundColor = '#99f2a5';

            } else if (songData.lyrics_state === 'complete' &&
                songData.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {

                infoContainer.style.backgroundColor = '#ffff64';

            } else if (songData.lyrics_state === 'complete' &&
                songData.current_user_metadata?.permissions?.includes("award_transcription_iq")) {

                infoContainer.style.backgroundColor = '#ffa335';

            } else {

                infoContainer.style.backgroundColor = '#ff7878';
            }

            if (!songData.album) {
                link.style.borderTop = '3.5px dashed';
                link.style.borderBottom = '3.5px dashed';
            }
        }


        document.addEventListener('click', async () => {
            if (!entriesLoaded) return;

            if ((isAllSongs && isGeniusArtistAllSongsAlbumsPage) || (isAllAlbums && isGeniusArtistAllSongsAlbumsPage) && isGeniusArtistAllSongsAlbumsPage) {
                updates = await checkCoverImage();
            }

            if (updates && updates.length > 0) {
                updates.forEach(({ targetDiv, color }) => {
                    targetDiv.style.border = `12.5px solid ${color}`;
                });
                if (isGeniusArtistAllSongsAlbumsPageZwsp) checkListItemsForZeroWidthSpace();
            }

            if (metadataToggleActive && isAllSongs && isGeniusArtistAllSongsAlbumsPageMetadata) {
                await checkMetadata();
            }
        });
    }


    function showRecords() {
        const el = document.querySelector('profile-achievements');
        if (el) {
            el.style.display = 'block';
        }
    }


});