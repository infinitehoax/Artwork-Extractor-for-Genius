const DELAY_BEFORE_CLEANUP = 250; // ? milliseconds

chrome.storage.local.get([
    'Services/genius_album.js',
    'isGeniusAlbumAlbumPage',
    'isGeniusAlbumAlbumPageZwsp',
    'isGeniusAlbumAlbumPageInfo',
    'isGeniusAlbumAlbumId',
    'isGeniusAlbumAlbumPageLyrics',
    'isGeniusAlbumExpandTracklist',
    'isGeniusAlbumEditTracklist',
    'isGeniusAlbumUploadCover',
    'isGeniusAlbumRenameButtons',
    'isGeniusAlbumSongCreditsButton',
    'isGeniusAlbumSongCreditsAutoReopen',
    'isGeniusAlbumFollowButton',
    'isGeniusAlbumCleanupButton',
    'functionOrder'
], function (result) {
    const isGeniusAlbumAlbumPage = result.isGeniusAlbumAlbumPage ?? true;
    const isGeniusAlbumAlbumPageZwsp = result.isGeniusAlbumAlbumPageZwsp ?? true;
    const isGeniusAlbumAlbumPageInfo = result.isGeniusAlbumAlbumPageInfo ?? true;
    const isGeniusAlbumAlbumId = result.isGeniusAlbumAlbumId ?? true;
    const isGeniusAlbumAlbumPageLyrics = result.isGeniusAlbumAlbumPageLyrics ?? false;
    const isGeniusAlbumExpandTracklist = result.isGeniusAlbumExpandTracklist ?? true;
    const isGeniusAlbumEditTracklist = result.isGeniusAlbumEditTracklist ?? true;
    const isGeniusAlbumUploadCover = result.isGeniusAlbumUploadCover ?? true;
    const isGeniusAlbumRenameButtons = result.isGeniusAlbumRenameButtons ?? true;
    const isGeniusAlbumSongCreditsButton = result.isGeniusAlbumSongCreditsButton ?? true;
    const isGeniusAlbumFollowButton = result.isGeniusAlbumFollowButton ?? true;
    const isGeniusAlbumCleanupButton = result.isGeniusAlbumCleanupButton ?? true;


    // ? Live state of the "Auto-Reopen" toggle inside the song credits editor.
    // * Initialized from the settings page value and kept in sync with it, so toggling it in the editor sticks.
    let autoReopenSongCredits = result.isGeniusAlbumSongCreditsAutoReopen ?? false;

    function setAutoReopenSongCredits(enabled) {
        autoReopenSongCredits = enabled;
        chrome.storage.local.set({ isGeniusAlbumSongCreditsAutoReopen: enabled });
    }

    // ? Slider switch for the "Auto-Reopen" option, shared by both song credits editors.
    // * Mirrors the settings page switch (40x20 pill, 14px knob), styled inline because the editors are injected into Genius pages.
    function createAutoReopenSwitch({ orientation = "column", caption = "Reopen", captionColor = "#fff", offColor = "#8c8c8c", onColor = "#24c609", ringColor = "rgba(255, 255, 255, 0.7)" } = {}) {
        const isRow = orientation === "row";
        const trackBorder = "inset 0 0 0 1px rgba(0, 0, 0, 0.15)";

        const field = document.createElement("label");
        field.title = "Reopen the editor automatically after saving";
        Object.assign(field.style, {
            position: "relative",
            display: "flex",
            flexDirection: isRow ? "row" : "column",
            alignItems: "center",
            gap: isRow ? "0.6rem" : "9px",
            cursor: "pointer",
            userSelect: "none"
        });

        const input = document.createElement("input");
        input.type = "checkbox";
        input.id = "auto_reopen_song_credits";
        input.checked = autoReopenSongCredits;
        Object.assign(input.style, {
            position: "absolute",
            width: "1px",
            height: "1px",
            margin: "0",
            opacity: "0"
        });

        const track = document.createElement("span");
        Object.assign(track.style, {
            position: "relative",
            display: "block",
            flex: "0 0 auto",
            width: "40px",
            height: "20px",
            borderRadius: "20px",
            boxShadow: trackBorder,
            transition: "background-color 0.25s ease, box-shadow 0.25s ease, filter 0.25s ease"
        });

        const knob = document.createElement("span");
        Object.assign(knob.style, {
            position: "absolute",
            top: "3px",
            left: "3px",
            width: "14px",
            height: "14px",
            borderRadius: "50%",
            backgroundColor: "#fff",
            boxShadow: "0 1px 2px rgba(0, 0, 0, 0.35)",
            transition: "transform 0.25s ease"
        });

        const text = document.createElement("div");
        text.textContent = caption;
        Object.assign(text.style, {
            fontSize: "0.75rem",
            color: captionColor,
            textAlign: "center",
            transition: "opacity 0.25s ease"
        });

        track.appendChild(knob);
        field.appendChild(input);
        field.appendChild(track);
        field.appendChild(text);

        function refresh() {
            track.style.backgroundColor = input.checked ? onColor : offColor;
            knob.style.transform = input.checked ? "translateX(20px)" : "translateX(0)";
            text.style.opacity = input.checked ? "1" : "0.65";
            field.setAttribute("aria-label", `Auto-Reopen after saving: ${input.checked ? "on" : "off"}`);
        }

        input.addEventListener("change", () => {
            setAutoReopenSongCredits(input.checked);
            refresh();
        });

        field.addEventListener("mouseenter", () => track.style.filter = "brightness(1.15)");
        field.addEventListener("mouseleave", () => track.style.filter = "none");

        // ? The checkbox itself is visually hidden, so mirror its focus state on the track.
        input.addEventListener("focus", () => track.style.boxShadow = `${trackBorder}, 0 0 0 2px ${ringColor}`);
        input.addEventListener("blur", () => track.style.boxShadow = trackBorder);

        refresh();

        return { field, input };
    }


    if (result['Services/genius_album.js'] === false) {
        return;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                  MAIN PROGRAM                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    let geniusStarted = false;

    main();

    async function main() {
        const isAlbum = /https:\/\/(genius\.com|genius-staging\.com)\/albums\/[^/]+\/[^/]+$/.test(window.location.href);
        //const isAlbumNew = /https:\/\/(genius\.com|genius-staging\.com)\/albums\/[^/]+\/[^/?]+\?react=1$/.test(window.location.href);
        const isAlbumNew = Array.from(document.querySelectorAll("button")).some(btn => btn.textContent.includes("View Old Album Page"));

        if (isAlbumNew) {
            const state = getScripts("window.__PRELOADED_STATE__");
            console.log(state);
            const userId = state?.session?.currentUser;
            const userUrl = state?.entities?.users?.[userId]?.url;
            const userRole = state?.entities?.users?.[userId]?.roleForDisplay;
            const albumId = state?.albumPage?.album;
            const highContrastMode = state?.albumPage?.highContrastMode;
            const primaryColor = state?.entities?.albums?.[albumId]?.albumArtPrimaryColor;
            const secondaryColor = state?.entities?.albums?.[albumId]?.albumArtSecondaryColor;
            const textColor = state?.entities?.albums?.[albumId]?.albumArtTextColor;
            const coverArtUrl = state?.entities?.albums?.[albumId]?.coverArtUrl;
            const coverArts = state?.entities?.albums?.[albumId]?.coverArts?.map(id => state?.entities?.coverArts?.[id]);
            const albumType = state?.entities?.albums?.[albumId]?.albumType;
            const albumTitle = state?.entities?.albums?.[albumId]?.name;
            const albumFollow = state?.entities?.albums?.[albumId]?.currentUserMetadata?.interactions?.following;


            const albumData = state?.entities;
            const songIds = state?.entities?.albumAppearances ? Object.values(state.entities.albumAppearances).sort((a, b) => a.trackNumber - b.trackNumber).map(entry => entry.song) : [];


            if (isGeniusAlbumAlbumPageInfo) showCoverArtInfo();

            //const userId = getId("currentUser");
            //const albumId = getId("album");
            //const songIds = getSongIds();

            //const { user: userData } = await getApiData(userId, "users");
            //const { album: albumData } = await getApiData(albumId, "albums");

            if (!userId || !userRole || !albumId || !albumData) return;

            console.log("• User ID:", userId);
            console.log("• User Role:", userRole);
            console.log("• Album Data:", albumData);
            console.log("• Album ID:", albumId);
            console.log("• Song IDs:", songIds);


            if (isGeniusAlbumAlbumId) showAlbumIdButton(albumId);

            if (isGeniusAlbumAlbumPageInfo) showCoverInfo(coverArtUrl, primaryColor, secondaryColor, textColor);
            if (isGeniusAlbumAlbumPage) checkAlbumCover(coverArtUrl);

            if (isGeniusAlbumUploadCover) uploadAlbumCover(albumId, coverArts);

            if (isGeniusAlbumExpandTracklist) expandTracklist(highContrastMode, textColor);
            if (isGeniusAlbumEditTracklist) addTracklistCheckboxes(userRole, highContrastMode, textColor, primaryColor, secondaryColor);


            if (isGeniusAlbumSongCreditsButton) songCreditsButtonAlbumPage(songIds);
            //if (isGeniusAlbumCleanupButton) cleanupAlbumType(albumId, albumType, albumTitle);


            /*async function songDataFunctions() {
                const songDataAlbum = await Promise.all(
                    songIds.map(async songId => {
                        const { song: songData } = await getApiData(songId, "songs");
                        return songData;
                    })
                );
                if (!songDataAlbum) return;

                if (isGeniusAlbumFollowButton) followButtonAlbumPage(songDataAlbum, albumData);
                if (isGeniusAlbumCleanupButton) cleanupMetadata(songDataAlbum, userData);
                if (isGeniusAlbumAlbumPageLyrics) lyricStateTracklist(songDataAlbum, userData);
            }*/

            async function songDataFunctions() {
                // ? Every function below needs the full song payload, which the API only serves one song at a time.
                // * So don't spend a request per track when none of them are switched on.
                if (!isGeniusAlbumFollowButton && !isGeniusAlbumCleanupButton && !isGeniusAlbumAlbumPageLyrics) return;

                // * getApiDataBatch() queues through the shared rate limiter, so this stays under the API budget.
                const songDataAlbum = (await getApiDataBatch(songIds, "songs")).map(data => data?.song).filter(Boolean);

                if (!songDataAlbum.length) return;

                if (isGeniusAlbumFollowButton) followButtonAlbumPage(songDataAlbum, albumId, albumFollow);
                if (isGeniusAlbumCleanupButton) cleanupMetadata(songDataAlbum, userRole);
                if (isGeniusAlbumAlbumPageLyrics) lyricStateTracklist(songDataAlbum, userRole);
            }


            function createSongDataFunctionsButton() {
                const { stickyToolbarRight, smallButton } = getDomElements();
                if (!stickyToolbarRight || !smallButton) return;

                const existingButton = [...stickyToolbarRight.querySelectorAll("button")]
                    .find(btn => ["Pull Song Data", "Loading…"].includes(btn.textContent.trim()));
                if (existingButton) existingButton.remove();

                const runButton = document.createElement("button");
                runButton.type = "button";
                runButton.className = smallButton.className;
                runButton.textContent = "Pull Song Data";
                stickyToolbarRight.insertBefore(runButton, stickyToolbarRight.firstChild);

                runButton.addEventListener("click", async () => {
                    runButton.disabled = true;
                    runButton.textContent = "Loading…";

                    try {
                        await songDataFunctions();

                        runButton.style.opacity = "0";
                        runButton.style.pointerEvents = "none";

                        setTimeout(() => runButton.remove(), 300);
                    } catch (err) {
                        runButton.textContent = "Error";

                        setTimeout(() => {
                            runButton.disabled = false;
                            runButton.textContent = "Pull Song Data";
                        }, 1500);
                    }
                });
            }

            /*chrome.runtime.sendMessage({ type: "IS_ACTIVE_TAB" }, (isActive) => {
                if (isActive && !geniusStarted) {
                    geniusStarted = true;
                    songDataFunctions();
                }
            });

            chrome.runtime.onMessage.addListener((msg) => {
                if (msg.type === "TAB_ACTIVATED" && !geniusStarted) {
                    geniusStarted = true;
                    songDataFunctions();
                }
            });*/

            chrome.runtime.sendMessage({ type: "IS_ACTIVE_TAB" }, (isActive) => {
                if (isActive && !geniusStarted) {
                    geniusStarted = true;
                    createSongDataFunctionsButton();
                }
            });

            chrome.runtime.onMessage.addListener((msg) => {
                if (msg.type === "TAB_ACTIVATED" && !geniusStarted) {
                    geniusStarted = true;
                    createSongDataFunctionsButton();
                }
            });


        } else if (isAlbum) {
            console.log("Album Page detected");
            const [albumId, userId] = await getAlbumInfo();
            const userRoles = await getUserRoles(userId);

            if (isGeniusAlbumRenameButtons) renameAlbumButtons();
            if (isGeniusAlbumAlbumPage) checkAlbumPage();
            if (isGeniusAlbumExpandTracklist) expandAllTracksInTracklist();
            if (isGeniusAlbumEditTracklist) addTracklistCheckbox();
            if (isGeniusAlbumUploadCover) monitorCover(albumId);

            getSongData(document.documentElement.innerHTML).then(json => {
                if (isGeniusAlbumSongCreditsButton) songCreditsButtonAlbumPageOld(json);
                if (isGeniusAlbumFollowButton) followButtonAlbumPageOld(json);
                if (isGeniusAlbumCleanupButton) cleanupMetadataOld(userId, userRoles, json);
                if (isGeniusAlbumAlbumPageLyrics) lyricStateTracklistOld(userRoles, json);
            });

            monitorTracklist();
        }

        async function getAlbumInfo() {
            const albumId = document.querySelector("meta[content*='Album ID']")?.content.match(/"Album ID","value":(\d+)/)?.[1];
            const userId = document.documentElement.innerHTML.match(/var CURRENT_USER = JSON.parse\('{\\"id\\":(\d+)/)?.[1];

            //const response = await fetch(`https://genius.com/api/albums/${albumId}`);
            //const json = await response.json();

            return [albumId, userId];
        }

        async function getUserRoles(userId) {
            const { user: userData } = await getApiData(userId, "users");
            return userData?.roles_for_display ?? [];
        }

        async function getSongData(html) {
            const songIdRegex = /&quot;api_path&quot;:&quot;\/songs\/(\d+)&quot;/g;
            let match;
            const songIds = [];

            while ((match = songIdRegex.exec(html)) !== null) {
                songIds.push(match[1]);
            }
            // * geniusFetch() queues through the shared rate limiter, so long tracklists don't fire at once.
            const responses = await Promise.all(songIds.map(songId =>
                geniusFetch(`https://genius.com/api/songs/${songId}`).then(res => res.json())
            ));
            return responses;
        }


        function monitorTracklist() {
            const tracklistContainer = document.querySelector('div[ng-hide="$ctrl.editing_tracklist"]');

            if (!tracklistContainer) return;

            function getTracklistData() {
                return Array.from(document.querySelectorAll("album-tracklist-row")).map(row => {
                    const songLink = row.querySelector(".chart_row-content a")?.getAttribute("href");
                    const trackNumber = row.querySelector(".chart_row-number_container-number span")?.textContent.trim();
                    return `${trackNumber}-${songLink}`;
                });
            }

            let previousTracklist = getTracklistData();
            const observer = new MutationObserver(() => {
                const currentTracklist = getTracklistData();

                if (JSON.stringify(currentTracklist) !== JSON.stringify(previousTracklist)) {
                    previousTracklist = currentTracklist;
                    removeSongCreditsButtons();
                    getSongData();
                }
            });

            observer.observe(tracklistContainer, { childList: true, subtree: true, characterData: true });
        }

        function removeSongCreditsButtons() {
            document.querySelectorAll('button.square_button.u-bottom_margin').forEach(button => {
                const clickAction = button.getAttribute('ng-click');
                if (["$ctrl.songCredits()", "$ctrl.follow()", "$ctrl.removeZWSP()"].includes(clickAction)) {
                    button.remove();
                }
            });
        }

    }

    function getDomElements() {
        const metadatastatsContainer = document.querySelector('div[class^="AlbumMetadataStats__Container-"]');
        const labelwithiconLabel = metadatastatsContainer?.querySelector('span[class^="LabelWithIcon__Label-"]');
        const stackedCoverArts = document.querySelector('div[class^="StackedCoverArts__Container-"]');
        const CoverArtAnnotationNavigationContainer = document.querySelector('div[class^="CoverArtAnnotationNavigation__Container-"]');
        const stickyToolbarLeft = document.querySelector('div[class^="StickyToolbar__Left-"]');
        const stickyToolbarRight = document.querySelector('div[class^="StickyToolbar__Right-"]');
        const smallButton = stickyToolbarLeft?.querySelector('button[class*="SmallButton__Container-"]') || stickyToolbarRight?.querySelector('button[class*="SmallButton__Container-"]');
        const editmetadatabutonSmallbutton = [...(stickyToolbarLeft?.querySelectorAll('button[class*="SmallButton__Container-"]') || [])].find(btn => btn.textContent.trim() === "Edit Metadata") || null;

        return { metadatastatsContainer, labelwithiconLabel, stackedCoverArts, CoverArtAnnotationNavigationContainer, stickyToolbarLeft, stickyToolbarRight, smallButton, editmetadatabutonSmallbutton };
    }


    document.addEventListener('click', (event) => {
        const link = event.target.closest('a');
        if (!link || !link.href) return;

        if (link.href.startsWith('https://genius.com/albums/') || link.href.startsWith('https://genius-staging.com/albums/')) {
            event.preventDefault();
            window.location.href = link.href;
            return;
        }

        if (event.target.closest('.global_search-search_results')) {
            event.preventDefault();
            window.location.href = link.href;
            return;
        }
    });

    new MutationObserver(() => {
        document.querySelector('.global_search-search_results')?.addEventListener('click', (event) => {
            const link = event.target.closest('a');
            if (link) {
                event.preventDefault();
                window.location.href = link.href;
            }
        });
    }).observe(document.body, { childList: true, subtree: true });


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                ALBUM ID BUTTON                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function showAlbumIdButton(albumId) {
        const { metadatastatsContainer, labelwithiconLabel } = getDomElements();

        if (metadatastatsContainer && !document.getElementById("album-id-button")) {
            const albumIdElement = document.createElement('span');
            albumIdElement.id = "album-id-button";
            albumIdElement.className = labelwithiconLabel?.className;

            const albumIdLink = document.createElement('a');
            albumIdLink.href = `https://genius.com/api/albums/${albumId}`;
            albumIdLink.target = "_blank";
            albumIdLink.textContent = albumId;
            albumIdLink.style.textDecoration = "none";
            albumIdLink.style.color = "inherit";
            albumIdLink.onmouseover = () => albumIdLink.style.textDecoration = "underline";
            albumIdLink.onmouseout = () => albumIdLink.style.textDecoration = "none";

            albumIdElement.textContent = "Album ID: ";
            albumIdElement.appendChild(albumIdLink);

            metadatastatsContainer.appendChild(albumIdElement);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                   COVER INFO                                   //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function showCoverArtInfo() {
        console.log("Run function showCoverArtInfo()");

        let modalObserver = null;
        let modalCloseObserver = null;
        let coverObserver = null;

        startModalObserver();

        function startModalObserver() {
            modalObserver = new MutationObserver(() => {
                const modal = document.getElementById("artwork-annotation-modal");
                if (!modal) return;

                setTimeout(() => observeCoverElement(modal), 50);

                modalObserver.disconnect();
                startModalCloseObserver(modal);
            });

            modalObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        function startModalCloseObserver(modal) {
            modalCloseObserver = new MutationObserver(() => {
                if (!document.body.contains(modal)) {
                    reset();
                }
            });

            modalCloseObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        function observeCoverElement(modal) {
            const coverDiv = modal.querySelector('img[class*="CoverArtAnnotationModalContent__SizedImage-"]');
            if (!coverDiv) return;

            if (coverObserver) coverObserver.disconnect();

            coverObserver = new MutationObserver(() => updateInfo(coverDiv, modal));
            coverObserver.observe(coverDiv, {
                attributes: true,
                attributeFilter: ["src"]
            });

            updateInfo(coverDiv, modal);
        }

        function updateInfo(coverDiv, modal) {
            const { CoverArtAnnotationNavigationContainer } = getDomElements();
            if (!CoverArtAnnotationNavigationContainer) return;

            const CoverArtAnnotationNavigationArrows =
                CoverArtAnnotationNavigationContainer.querySelector('[class*="CoverArtAnnotationNavigation__Arrows-"]');
            if (!CoverArtAnnotationNavigationArrows) return;

            const src = coverDiv.src;

            let cleaned = src;
            const unsafeMatch = cleaned.match(/unsafe\/\d+x\d+\/(.+)$/);
            if (unsafeMatch) {
                cleaned = unsafeMatch[1];
            }

            const finalUrl = decodeURIComponent(cleaned);
            const existing = CoverArtAnnotationNavigationContainer.querySelector('[data-type="annotation-resolution-info"]');
            if (existing) existing.remove();

            const info = createAnnotationResolutionInfo(finalUrl);

            info.style.textAlign = "right";

            CoverArtAnnotationNavigationContainer.insertBefore(info, CoverArtAnnotationNavigationArrows);
        }

        function createAnnotationResolutionInfo(url) {
            const resolution = extractResolutionFromUrl(url);
            const formatMatch = url.match(/\.(\w+)$/);
            const format = formatMatch ? formatMatch[1].toUpperCase() : "Cover";

            const el = document.createElement("div");
            el.dataset.type = "annotation-resolution-info";

            el.style.position = "relative";
            el.style.marginLeft = "auto";
            el.style.marginRight = "1.5rem";
            el.style.alignContent = "center";
            el.style.fontSize = "0.875rem";
            el.style.fontWeight = "100";

            el.textContent = `${resolution} ${format}`;

            return el;
        }

        function extractResolutionFromUrl(url) {
            const match = url.match(/(\d+)x(\d+)/);
            return match ? `${match[1]}x${match[2]}` : null;
        }

        function reset() {
            if (coverObserver) coverObserver.disconnect();
            if (modalCloseObserver) modalCloseObserver.disconnect();

            coverObserver = null;
            modalCloseObserver = null;

            startModalObserver();
        }
    }

    function showCoverInfo(coverArtUrl, primaryColor, secondaryColor, textColor) {
        console.log("Run function showCoverInfo()");

        const { stackedCoverArts } = getDomElements();
        if (!stackedCoverArts) return;

        const existing = stackedCoverArts.querySelector('div[data-type="resolution-info"]');
        if (existing) existing.remove();

        const pxToRem = (px) => {
            const rootFontSize = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
            return px / rootFontSize;
        };

        const createResolutionInfo = () => {
            const resolutionMatch = coverArtUrl.match(/(\d+)x(\d+)/);
            const formatMatch = coverArtUrl.match(/\.(\w+)$/);

            const resolutionText = resolutionMatch?.[1] ? `${resolutionMatch[1]}x${resolutionMatch[2]}` : "No";
            const formatText = formatMatch?.[1] ? formatMatch[1].toUpperCase() : "Cover";

            const resolutionInfo = document.createElement('div');
            resolutionInfo.dataset.type = "resolution-info";
            resolutionInfo.style.fontWeight = "100";
            resolutionInfo.style.justifySelf = "center";
            resolutionInfo.style.position = "absolute";
            resolutionInfo.style.color = textColor;

            resolutionInfo.textContent = [`${resolutionText} ${formatText}`, primaryColor, secondaryColor, textColor].join(" | ");

            const updateStyles = () => {
                const imgWidth = stackedCoverArts.clientWidth || 1000;
                const dynamicFontPx = imgWidth * 0.05;
                const fontSizeRem = Math.min(pxToRem(dynamicFontPx), 0.75);
                resolutionInfo.style.fontSize = `${fontSizeRem}rem`;

                const topRem = -fontSizeRem / 2;
                resolutionInfo.style.top = `${topRem - 0.625}rem`;
            };

            updateStyles();

            const observer = new ResizeObserver(updateStyles);
            observer.observe(stackedCoverArts);

            return resolutionInfo;
        };

        const infoElement = createResolutionInfo();
        stackedCoverArts.append(infoElement);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                COVER INDICATOR                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function checkAlbumCover(coverArtUrl) {
        console.log("Run function checkAlbumCover()");

        const { editmetadatabutonSmallbutton } = getDomElements();
        if (!editmetadatabutonSmallbutton) return;

        let color, borderColor;

        const coverArt = coverArtUrl;

        if (coverArt) {
            if (coverArt.startsWith("https://images.genius.com") && coverArt.endsWith("1000x1000x1.png")) {
                color = '#99f2a5'; // Green
                borderColor = '#66bfa3';
            } else if ((coverArt.startsWith("http://images.genius.com") || coverArt.startsWith("http://images.rapgenius.com") || coverArt.startsWith("https://images.rapgenius.com")) && coverArt.endsWith("1000x1000x1.png")) {
                color = '#7689e8'; // Blue
                borderColor = '#4a5e9d';
            } else if (coverArt.startsWith("https://assets.genius.com/images/default_cover_image.png")) {
                color = '#dddddd'; // Grey
                borderColor = '#aaaaaa';
            } else if (coverArt.startsWith("https://filepicker-images-rapgenius.s3.amazonaws.com/filepicker-images-rapgenius/") || coverArt.endsWith("1000x1000bb.png") || coverArt.endsWith("10000x10000bb.png") || coverArt.endsWith("1000x1000.png") || coverArt.endsWith("1000x1000-000000-80-0-0.png")) {
                color = '#ffff64'; // Yellow
                borderColor = '#cccc00';
            } else {
                color = '#fa7878'; // Red
                borderColor = '#a74d4d';
            }
        }

        addColoredCircle(editmetadatabutonSmallbutton, color, borderColor);
        //if (isGeniusAlbumAlbumPageZwsp) checkAlbumTitleForZeroWidthSpace();
    }

    function addColoredCircle(button, color, borderColor) {
        const existingCircle = button.querySelector('.circle-indicator');
        if (existingCircle) {
            existingCircle.style.backgroundColor = color;
            existingCircle.style.borderColor = borderColor;
        } else {
            const circle = document.createElement('span');
            circle.className = 'circle-indicator';
            circle.style.cssText = `
                font-variant: JIS04;
                height: 16px;
                width: 28px;
                display: inline-block;
                margin-right: 0.375rem;
                margin-left: calc(-0.375rem);
                padding: 0px 0.25rem;
                background-color: ${color};
                border: 1px solid ${borderColor};
                border-radius: 1.25rem;
            `;
            button.prepend(circle);
        }
    }

    function addBlackCross(square) {
        const existingCross = square.querySelector('.black-cross');
        if (!existingCross) {
            const cross = document.createElement('span');
            cross.className = 'black-cross';
            cross.style.cssText = `
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

            const line1 = document.createElement('div');
            line1.style.cssText = `
            position: absolute;
            width: 112%;
            height: 3px;
            border-radius: 2px;
            background-color: black;
            transform: rotate(25deg);
        `;

            const line2 = document.createElement('div');
            line2.style.cssText = `
            position: absolute;
            width: 112%;
            height: 3px;
            border-radius: 2px;
            background-color: black;
            transform: rotate(-25deg);
        `;

            cross.appendChild(line1);
            cross.appendChild(line2);
            square.appendChild(cross);
        }
    }

    function addBlackSquare(square) {
        const existingSquare = square.querySelector('.black-square');
        if (!existingSquare) {
            const blackSquare = document.createElement('span');
            blackSquare.className = 'black-square';
            blackSquare.style.cssText = `
            height: 8px;
            width: 8px;
            background-color: #2C2C2C;
            display: inline-block;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        `;
            square.appendChild(blackSquare);
        }
    }

    function addColoredSquare(button, color, borderColor) {
        const existingSquare = button.querySelector('.square-indicator');
        if (existingSquare) {
            existingSquare.style.backgroundColor = color;
            existingSquare.style.borderColor = borderColor;
        } else {
            const square = document.createElement('span');
            square.className = 'square-indicator';
            square.style.cssText = `
                font-variant: JIS04;
                height: 16px;
                width: 28px;
                display: inline-block;
                margin-left: -0.100rem;
                margin-right: 0.375rem;
                position: relative;
                background-color: ${color};
                border: 1px solid ${borderColor};
            `;
            button.style.cssText += `
                display: inline-flex;
                align-items: center;
                flex-wrap: nowrap;
            `;
            button.prepend(square);
        }
    }

    function checkAlbumTitleForZeroWidthSpaceOld() {
        const titleElement = document.querySelector('.header_with_cover_art-primary_info-title');
        if (titleElement) {
            const titleText = titleElement.textContent.trim();
            if (titleText.includes('\u200B')) {
                const square = document.querySelector('.square-indicator');
                if (square) {
                    addBlackSquare(square);
                }
            }
        }
    }

    function checkTracklistForZeroWidthSpace() {
        const trackRows = document.querySelectorAll('album-tracklist-row');
        const zeroWidthSpaceIndices = [];
        trackRows.forEach((row, index) => {
            const h3Element = row.querySelector('h3.chart_row-content-title');
            if (h3Element) {
                let h3Text = h3Element.textContent;
                const ftIndex = h3Text.indexOf("(Ft.");
                if (ftIndex !== -1) {
                    h3Text = h3Text.substring(0, ftIndex).trim();
                }
                const byIndex = h3Text.indexOf(" by");
                if (byIndex !== -1 && h3Text.substring(byIndex).includes(" &")) {
                    h3Text = h3Text.substring(0, byIndex).trim();
                }
                if (h3Text.includes('\u200B')) {
                    zeroWidthSpaceIndices.push(index);
                    console.log(`Zero-Width-Space detected in Track ${index + 1}: ${h3Text}`);
                }
            }
        });
        return zeroWidthSpaceIndices;
    }

    function renameAlbumButtons() {
        const editTracklistButton = document.querySelector('.square_button.u-bottom_margin[ng-click*="editing_tracklist"]');
        if (editTracklistButton) editTracklistButton.textContent = 'Tracklist';
        const editAlbumInfoDiv = document.querySelector('.square_button.u-bottom_margin[ng-click*="editing = true"]');
        if (editAlbumInfoDiv) editAlbumInfoDiv.textContent = 'Album Info';
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               COVER ALBUM PAGES                                //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function checkAlbumPage() {
        const metaTag = document.querySelector('meta[property="og:image"]');
        if (metaTag) {
            const coverImageUrl = metaTag.getAttribute('content');
            const editAlbumButton = document.querySelectorAll('.square_button.u-bottom_margin');
            if (editAlbumButton.length > 1) {
                const secondEditAlbumButton = editAlbumButton[1];
                let color, borderColor;
                if (coverImageUrl.endsWith("1000x1000x1.png")) {
                    color = '#99f2a5'; // Green
                    borderColor = '#66bfa3';
                } else if (coverImageUrl.startsWith("http://assets.genius.com/images/sharing_fallback.png")) {
                    if (document.head.innerHTML.match(/&quot;cover_art_url&quot;:&quot;http:\/\/assets.genius.com/) ||
                        document.head.innerHTML.match(/&quot;cover_art_url&quot;:&quot;https:\/\/assets.genius.com/)) {
                        color = '#dddddd'; // Grey
                        borderColor = '#aaaaaa';
                    } else {
                        color = '#ffff64'; // Yellow
                        borderColor = '#cccc00';
                    }
                } else {
                    color = '#fa7878'; // Red
                    borderColor = '#a74d4d';
                }
                addColoredSquare(secondEditAlbumButton, color, borderColor);
                if (isGeniusAlbumAlbumPageZwsp) checkAlbumTitleForZeroWidthSpaceOld();
            }
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 FOLLOW BUTTON                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    async function followButtonAlbumPageOld(songData) {
        console.log(songData);
        const albumAdminMenu = document.querySelector('album-admin-menu');
        const storageKey = "followState";
        sessionStorage.removeItem(storageKey);
        const followButton = document.createElement('button');
        followButton.className = 'square_button u-bottom_margin';
        followButton.setAttribute('ng-click', "$ctrl.follow()");
        followButton.setAttribute('ng-if', "$ctrl.has_permission('follow')");
        followButton.textContent = 'Loading...';
        followButton.style.marginRight = "0.25rem";
        albumAdminMenu.parentNode.insertBefore(followButton, albumAdminMenu);
        const followingStates = songData.map(data => ({
            songId: data.response?.song?.id,
            following: data.response?.song?.current_user_metadata?.interactions?.following
        }));
        const initiallyFollowing = followingStates.filter(data => data.following).map(data => data.songId);
        sessionStorage.setItem(storageKey, JSON.stringify(initiallyFollowing));
        let isFollowingAll = initiallyFollowing.length === followingStates.length;
        followButton.textContent = isFollowingAll ? 'Following' : 'Follow';
        followButton.addEventListener('click', async () => {
            const storedState = JSON.parse(sessionStorage.getItem(storageKey)) || [];
            if (followButton.textContent === 'Follow') {
                const newFollows = followingStates.filter(data => !storedState.includes(data.songId));
                await Promise.all(newFollows.map(data => toggleFollowSong(data.songId, 'follow')));
                storedState.push(...newFollows.map(data => data.songId));
                sessionStorage.setItem(storageKey, JSON.stringify(storedState));
                followButton.textContent = 'Following';
            } else {
                await Promise.all(followingStates.map(data => toggleFollowSong(data.songId, 'unfollow')));
                sessionStorage.setItem(storageKey, JSON.stringify([]));
                followButton.textContent = 'Follow';
            }
        });
    }

    async function followButtonAlbumPage(songData, albumId, albumFollow) {
        console.log("Run function followButtonAlbumPage()");

        const { stickyToolbarLeft, smallButton } = getDomElements();
        if (!stickyToolbarLeft || !smallButton) return;

        const existingButton = [...stickyToolbarLeft.querySelectorAll("button")].find(btn => ["Follow", "Following", "Loading…"].includes(btn.textContent.trim()));
        if (existingButton) existingButton.remove();

        const followButton = document.createElement("button");
        followButton.type = "button";
        followButton.className = smallButton.className;
        followButton.textContent = "Loading…";
        stickyToolbarLeft.appendChild(followButton);

        const followingSongStates = songData.map(song => ({ songId: song.id, following: song.current_user_metadata?.interactions?.following }));
        const followingAlbumStates = { songId: albumId, following: albumFollow, isAlbum: true };

        const allFollowStates = [...followingSongStates, followingAlbumStates];
        const initiallyFollowing = allFollowStates.filter(s => s.following);
        let isFollowingAll = initiallyFollowing.length === allFollowStates.length;

        followButton.textContent = isFollowingAll ? "Following" : "Follow";

        followButton.addEventListener("click", async () => {
            followButton.disabled = true;

            if (!isFollowingAll) {
                followButton.textContent = "Following…";
                const toFollow = allFollowStates.filter(s => !s.following);
                await Promise.all(toFollow.map(s => followId(s.songId, s.isAlbum ? "albums" : "songs", "follow")));
                toFollow.forEach(s => s.following = true);
                isFollowingAll = true;
                followButton.textContent = "Following";
            } else {
                followButton.textContent = "Unfollowing…";
                const toUnfollow = allFollowStates.filter(s => s.following);
                await Promise.all(toUnfollow.map(s => followId(s.songId, s.isAlbum ? "albums" : "songs", "unfollow")));
                toUnfollow.forEach(s => s.following = false);
                isFollowingAll = false;
                followButton.textContent = "Follow";
            }

            followButton.disabled = false;
        });
    }




    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                TRACKLIST BUTTON                                //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function addTracklistCheckboxes(userRole, highContrastMode, textColor, primaryColor, secondaryColor) {
        console.log("Run function addTracklistCheckboxes()");

        const observer = new MutationObserver(() => {
            const tracklist = document.querySelector('[data-testid="album-edit-tracklist"]');
            if (!tracklist) return;

            const header = tracklist.querySelector('div[class^="SectionHeader-sc-"]');
            if (!header) return;

            if (tracklist.querySelector('.checkbox-container')) return;

            const containerDiv = document.createElement("div");
            containerDiv.className = "checkbox-container";
            containerDiv.style.display = "flex";
            containerDiv.style.alignItems = "center";
            containerDiv.style.justifyContent = "flex-end";
            containerDiv.style.gap = "1rem";
            containerDiv.style.marginTop = "-0.375rem";
            containerDiv.style.marginBottom = "0.75rem";


            const createToggle = (labelText) => {
                const wrapper = document.createElement("label");
                wrapper.style.display = "flex";
                wrapper.style.alignItems = "center";
                wrapper.style.gap = "0.35rem";
                wrapper.style.cursor = "pointer";

                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";

                Object.assign(checkbox.style, {
                    appearance: "none",
                    border: highContrastMode ? "1px solid rgb(0,0,0)" : `1px solid ${textColor}`,
                    backgroundColor: "transparent",
                    width: "0.75rem",
                    height: "0.75rem",
                    cursor: "pointer"
                });

                const checkSvg = highContrastMode
                    ? "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")"
                    : `url("data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='${encodeURIComponent(secondaryColor)}' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E")`;

                const updateCheckboxStyle = () => {
                    if (checkbox.checked) {
                        checkbox.style.backgroundColor = highContrastMode ? "rgb(0,0,0)" : textColor;
                        checkbox.style.backgroundImage = checkSvg;
                    } else {
                        checkbox.style.backgroundColor = "transparent";
                        checkbox.style.backgroundImage = "none";
                    }
                };


                checkbox.addEventListener("change", () => {
                    updateCheckboxStyle();

                    const targetCheckboxes = Array.from(
                        tracklist.querySelectorAll('label[class^="FilledTrack__CheckboxLabel-sc-"]')
                    )
                        .filter(label => {
                            const span = label.querySelector('span');
                            return span && span.textContent.trim() === labelText;
                        })
                        .map(label => label.querySelector('input[type="checkbox"]'));

                    targetCheckboxes.forEach(cb => {
                        if (cb.checked !== checkbox.checked) {
                            ["pointerdown", "mousedown", "mouseup", "click"].forEach(type => {
                                cb.dispatchEvent(new MouseEvent(type, {
                                    bubbles: true,
                                    cancelable: true,
                                    view: window
                                }));
                            });
                        }
                    });
                });

                const text = document.createElement("span");
                text.textContent = labelText;
                text.style.fontSize = "0.75rem";
                text.style.fontWeight = "100";

                wrapper.appendChild(checkbox);
                wrapper.appendChild(text);

                return wrapper;
            };

            const hideToggle = createToggle("Hide");
            const unreleasedToggle = createToggle("Unreleased");

            const hasHidePermission = userRole === "transcriber" || userRole === "editor" || userRole === "moderator";
            if (hasHidePermission) containerDiv.appendChild(hideToggle);
            containerDiv.appendChild(unreleasedToggle);

            header.insertAdjacentElement("afterend", containerDiv);
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    function expandTracklist(highContrastMode, textColor) {
        const discContainers = Array.from(document.querySelectorAll("[class^='Tracklist__DiscContainer-']"));
        const allCreditButtons = Array.from(document.querySelectorAll("[class*='Track__CreditsToggle-']"));

        const plusSVG = `
        <svg fill="currentColor" viewBox="0 0 14 14">
            <path d="M0 6h13.5v1.5H0z"></path>
            <path d="M6 13.5V0h1.5v13.5z"></path>
        </svg>
    `;

        const minusSVG = `
        <svg fill="currentColor" viewBox="0 0 14 2">
            <path d="M0 0h13.5v1.5H0z"></path>
        </svg>
    `;

        const createExpandButton = (label, buttonsToClick) => {
            if (buttonsToClick.length === 0 || buttonsToClick.length > 50) return null;

            const firstCreditButton = document.querySelector("[class*='Track__CreditsToggle']");
            if (!firstCreditButton) return null;

            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = firstCreditButton.className;
            btn.setAttribute("aria-expanded", "false");
            btn.setAttribute("aria-label", label);
            btn.setAttribute("data-expand-btn", "true");
            btn.innerHTML = plusSVG;

            btn.style.outline = highContrastMode ? "1px solid rgb(0,0,0)" : `1px solid ${textColor}`;
            btn.style.borderRadius = "50%";
            btn.style.outlineOffset = "0.2rem";
            btn.style.width = "0.75rem";
            btn.style.aspectRatio = "1 / 1";

            btn.addEventListener("click", async () => {
                const expanded = btn.getAttribute("aria-expanded") === "true";

                if (!expanded) {
                    for (const b of buttonsToClick) {
                        const isExpanded = b.getAttribute("aria-expanded") === "true";
                        if (!isExpanded) {
                            b.click();
                            await new Promise(r => setTimeout(r, 25));
                        }
                    }
                } else {
                    buttonsToClick.forEach(b => {
                        const isExpanded = b.getAttribute("aria-expanded") === "true";
                        if (isExpanded) b.click();
                    });
                }

                btn.setAttribute("aria-expanded", expanded ? "false" : "true");
                btn.innerHTML = expanded ? plusSVG : minusSVG;
            });

            return btn;
        };

        const discHeaders = discContainers
            .map(d => d.querySelector("[class^='TracklistDiscHeader__Container-']"))
            .filter(Boolean);

        if (discHeaders.length > 1) {
            discHeaders.forEach((discHeader, index) => {
                if (discHeader.querySelector("[data-expand-btn='true']")) return;

                const discButtons = Array.from(
                    discContainers[index].querySelectorAll("[class*='Track__CreditsToggle-']")
                );

                const btn = createExpandButton(`Expand Disc ${index + 1}`, discButtons);
                if (btn) discHeader.appendChild(btn);
            });

            return;
        }

        const headerContainer = document.querySelector("[class^='Tracklist__Header-']");
        if (!headerContainer) return;

        if (headerContainer.querySelector("[data-expand-btn='true']")) return;

        const btnAll = createExpandButton("Expand All", allCreditButtons);
        if (!btnAll) return;

        btnAll.style.marginLeft = "auto";
        headerContainer.appendChild(btnAll);
    }



    function expandAllTracksInTracklist() {
        let expanded = false;
        function expandAll() {
            document.querySelectorAll('.chart_row-expand').forEach(button => {
                button.click();
            });
            expanded = !expanded;
            expandText.textContent = expanded ? "Collapse" : "Expand";
        }
        let expandText = document.createElement("span");
        expandText.textContent = "Expand";
        expandText.className = "expand-text";
        expandText.style.cursor = "pointer";
        expandText.style.textDecoration = "underline";
        expandText.addEventListener("click", expandAll);
        let header = document.querySelector("h2.text_label");
        header.style.display = "flex";
        header.style.justifyContent = "space-between";
        header.style.alignItems = "center";
        header.appendChild(expandText);
    }


    function addTracklistCheckbox() {
        const observer = new MutationObserver(() => {
            const controlsContainer = document.querySelector('div[ng-if="$ctrl.editing"]');
            if (!controlsContainer) return;

            if (!controlsContainer.querySelector("#autoTrackNumberingCheckbox")) {
                controlsContainer.style.display = "flex";
                controlsContainer.style.alignItems = "center";
                controlsContainer.style.justifyContent = "space-between";

                const checkboxContainer = document.createElement('div');
                checkboxContainer.style.cssText = "display: flex; align-items: center; margin-left: auto;";

                function createCheckbox(id, text) {
                    const checkbox = document.createElement('input');
                    checkbox.type = "checkbox";
                    checkbox.id = id;
                    checkbox.className = "styled-checkbox";
                    checkbox.style.cssText = "width: 16px; height: 16px; cursor: pointer; margin-left: 0.5rem; accent-color: #99a7ee;";
                    const label = document.createElement('label');
                    label.htmlFor = id;
                    label.textContent = text;
                    label.className = "styled-label";
                    label.style.cssText = "font-size: 14px; font-weight: bold; cursor: pointer; color: #333; margin-left: 0.5rem;";
                    return { checkbox, label };
                }

                const { checkbox: checkboxAutoTrack, label: labelAutoTrack } = createCheckbox("autoTrackNumberingCheckbox", "Auto Track Numbering");
                const { checkbox: checkboxUnreleased, label: labelUnreleased } = createCheckbox("unreleasedCheckbox", "Unreleased");

                checkboxContainer.append(labelAutoTrack, checkboxAutoTrack, labelUnreleased, checkboxUnreleased);
                controlsContainer.appendChild(checkboxContainer);

                document.addEventListener("click", () => {
                    const checkboxUnreleased = document.querySelector("#unreleasedCheckbox");
                    if (!checkboxUnreleased) return;
                    checkboxUnreleased.addEventListener("change", () => {
                        const shouldActivate = checkboxUnreleased.checked;
                        document.querySelectorAll(".editable_tracklist-row-entry-unreleased_label").forEach((label) => {
                            const checkbox = label.previousElementSibling;
                            if (checkbox && checkbox.type === "checkbox") {
                                if (shouldActivate && !checkbox.checked) {
                                    label.click();
                                } else if (!shouldActivate && checkbox.checked) {
                                    label.click();
                                }
                            }
                        });
                    });
                });
            }
            startTrackListObserver();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    let trackListObserver;
    let processedElements = new Set();
    let observerInitialized = false;

    function startTrackListObserver() {
        if (observerInitialized) return;
        observerInitialized = true;
        const trackListContainer = document.querySelector(".editable_tracklist");
        trackListObserver = new MutationObserver((mutations) => {
            const checkboxAutoTrack = document.querySelector("#autoTrackNumberingCheckbox");
            const checkboxUnreleased = document.querySelector("#unreleasedCheckbox");
            if (!checkboxAutoTrack || !checkboxUnreleased) return;
            if (checkboxAutoTrack.checked) {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.matches?.(".editable_tracklist-row")) {
                            const trackNumberElement = node.querySelector(".editable_tracklist-row-number");
                            if ((!trackNumberElement || !trackNumberElement.innerText.trim()) && !processedElements.has(node)) {
                                processedElements.add(node);
                                addSongAsNext();
                            }
                        }
                    });
                });
            }
            if (checkboxUnreleased.checked) {
                addSongAsUnreleased();
            }
        });

        trackListObserver.observe(trackListContainer, { childList: true, subtree: true });
    }

    function addSongAsNext() {
        const firstPlaceholder = document.querySelector("div[ng-if='!slot.song_id'].editable_tracklist-row-placeholder");
        let songNum;
        if (firstPlaceholder) {
            const numberedSlot = firstPlaceholder.closest(".editable_tracklist-row").querySelector(".editable_tracklist-row-number");
            songNum = numberedSlot.innerText.trim();
        } else {
            const lastEntryContainer = document.querySelectorAll(".editable_tracklist-row-entry-container[ng-if='slot.song_id']");
            const lastEntry = lastEntryContainer[lastEntryContainer.length - 1];
            const lastNumberedSlot = lastEntry.closest(".editable_tracklist-row").querySelector(".editable_tracklist-row-number");
            songNum = parseInt(lastNumberedSlot.innerText.trim(), 10) + 1;
        }
        const unnumberedEntries = document.querySelectorAll(".editable_tracklist-row-entry-container");
        let lastUnnumberedSlot = null;
        for (let i = unnumberedEntries.length - 1; i >= 0; i--) {
            const slot = unnumberedEntries[i].closest(".editable_tracklist-row");
            if (!slot) continue;
            const trackNumberElement = slot.querySelector(".editable_tracklist-row-number");
            if (!trackNumberElement || !trackNumberElement.innerText.trim()) {
                lastUnnumberedSlot = slot;
                break;
            }
        }
        if (!lastUnnumberedSlot) {
            return;
        }
        const editButton = lastUnnumberedSlot.querySelector("button[aria-label='edit']");
        editButton.click();
        const input = lastUnnumberedSlot.querySelector("input.square_input.editable_tracklist-row-number-input");
        input.classList.remove("ng-empty");
        input.classList.add("ng-not-empty");
        input.value = songNum;
        const event = new Event("input", { bubbles: true });
        input.dispatchEvent(event);
        const buttons = document.querySelectorAll(".button--unstyled");
        const button = buttons[buttons.length - 1];
        button.click();
    }

    function addSongAsUnreleased() {
        const checkboxUnreleased = document.querySelector("#unreleasedCheckbox");
        if (!checkboxUnreleased || !checkboxUnreleased.checked) return;
        document.querySelectorAll(
            'div[ng-if="slot.lyrics_state"] input[type="checkbox"], div.editable_tracklist-row-entry-container input[type="checkbox"]'
        ).forEach((checkbox) => {
            if (checkbox.checked) return;
            const label = checkbox.closest("div").querySelector(".editable_tracklist-row-entry-unreleased_label");
            if (label) label.click();
        });
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               ALBUM COVER EDITOR                               //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    async function addAlbumCoverTextfield(albumId) {
        if (document.querySelector(".square_form-container")) return;

        const buttons = document.querySelectorAll(".square_button.square_button--transparent.square_button--gray");
        if (buttons.length > 0) {
            buttons[buttons.length - 1].style.display = "none";
        }

        const response = await geniusFetch(`https://genius.com/api/albums/${albumId}`);
        const json = await response.json();
        const coverArts = json.response.album.cover_arts;

        const container = document.querySelector(".cover_art_form");
        if (container) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
            document.head.appendChild(link);

            const formWrapper = document.createElement("div");
            formWrapper.className = "square_form-container";
            formWrapper.style.paddingLeft = "1.313rem";
            formWrapper.style.alignItems = "start";

            const entriesContainer = document.createElement("div");
            entriesContainer.className = "entries_container";
            entriesContainer.style.display = "flex";
            entriesContainer.style.flexDirection = "column";
            entriesContainer.style.gap = "0.5rem";

            const buttonRow = document.createElement("div");
            buttonRow.style.display = "flex";
            buttonRow.style.gap = "10px";
            buttonRow.style.marginTop = "0.5rem";

            const addButton = document.createElement("button");
            addButton.textContent = "+ Add";
            addButton.className = "square_button square_button--gray";
            addButton.style.width = "65px";
            addButton.style.marginInlineStart = "5px";

            const saveButton = document.createElement("button");
            saveButton.textContent = "Save";
            saveButton.className = "square_button square_button--green";
            saveButton.style.width = "65px";

            buttonRow.appendChild(addButton);
            buttonRow.appendChild(saveButton);
            formWrapper.appendChild(entriesContainer);
            formWrapper.appendChild(buttonRow);
            container.appendChild(formWrapper);

            addButton.addEventListener("click", () => addInputSet());

            const inputSets = [];

            function addInputSet() {
                const inputRow = document.createElement("div");
                inputRow.style.display = "flex";
                inputRow.style.alignItems = "center";

                const checkboxContainer = document.createElement("div");
                checkboxContainer.style.display = "flex";
                checkboxContainer.style.alignItems = "baseline";
                checkboxContainer.style.flexDirection = "column-reverse";

                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.id = "cover_art_checkbox";

                const label = document.createElement("label");
                label.htmlFor = "cover_art_checkbox";
                label.innerHTML = '<i class="fas fa-edit" style="font-size: 14px;"></i>';
                label.style.cursor = "pointer";

                const textInput = document.createElement("input");
                textInput.type = "text";
                textInput.id = "cover_art_text";
                textInput.placeholder = "Nr.";
                textInput.className = "square_input square_form-standard_element_margin";
                textInput.style.margin = "4px 5px 0px";
                textInput.style.width = "45px";

                const fullWidthInput = document.createElement("input");
                fullWidthInput.type = "text";
                fullWidthInput.id = "full_width_text";
                fullWidthInput.placeholder = "Image URL";
                fullWidthInput.className = "square_input square_form-standard_element_margin";
                fullWidthInput.style.margin = "4px 2.5px 0px";
                fullWidthInput.style.width = "325px";

                checkboxContainer.appendChild(checkbox);
                checkboxContainer.appendChild(label);
                inputRow.appendChild(checkboxContainer);
                inputRow.appendChild(textInput);
                inputRow.appendChild(fullWidthInput);

                entriesContainer.appendChild(inputRow);

                inputSets.push({ checkbox, textInput, fullWidthInput });
            }

            addInputSet();

            saveButton.addEventListener("click", async function () {
                saveButton.disabled = true;

                for (const { checkbox, textInput, fullWidthInput } of inputSets) {
                    const position = parseInt(textInput.value.trim(), 10) || null;
                    const imageUrl = fullWidthInput.value.trim();

                    if (!imageUrl) return;

                    if (position === null && checkbox.checked) {
                        await sendCoverArts(imageUrl, albumId);
                        await deleteCoverArts(coverArts[0].id);

                    } else if (position && checkbox.checked) {
                        await sendCoverArts(imageUrl, albumId);
                        if (position <= coverArts.length) {
                            await moveCoverArts(position, coverId, coverArts);
                            await deleteCoverArts(coverArts[position - 1].id);
                        }

                    } else {
                        await sendCoverArts(imageUrl, albumId);
                        if (position <= coverArts.length) {
                            await moveCoverArts(position, coverId, coverArts);
                        }
                    }
                }

                const closeButton = document.querySelector(".modal_window-close_button");
                if (closeButton) {
                    closeButton.click();
                }
            });
        }
    }

    function monitorCover(albumId) {
        if (!albumId) return;

        const observer = new MutationObserver(() => {
            const selectedItemCoverArt = document.querySelector(".toggleable_list_item.toggleable_list_item--selected[ng-class*='cover_art']");

            if (selectedItemCoverArt) {
                addAlbumCoverTextfield(albumId);
                observer.disconnect();

                const removeObserver = new MutationObserver(() => {
                    const newSelectedItemCoverArt = document.querySelector(".toggleable_list_item.toggleable_list_item--selected[ng-class*='cover_art']");

                    if (!newSelectedItemCoverArt) {
                        removeObserver.disconnect();
                        monitorCover(albumId);
                    }
                });

                removeObserver.observe(document.body, { childList: true, subtree: true });
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    function uploadAlbumCover(albumId, coverArts) {
        console.log("Run function uploadAlbumCover()");

        const rows = [];
        // const coverArts = albumData.cover_arts;

        let modalObserver = null;
        let modalCloseObserver = null;

        function createLeftCol() {
            const row = document.createElement("div");
            row.style.display = "flex";
            row.style.flexDirection = "row";
            row.style.alignItems = "center";
            row.style.gap = "1rem";
            row.style.flex = "1 1 auto";

            const checkboxRow = document.createElement("div");
            checkboxRow.style.display = "flex";
            checkboxRow.style.flexDirection = "row";
            checkboxRow.style.alignItems = "center";
            checkboxRow.style.gap = "0.5rem";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.style.appearance = "none";
            checkbox.style.border = "1px solid rgb(0,0,0)";
            checkbox.style.backgroundColor = "white";
            checkbox.style.width = "1rem";
            checkbox.style.height = "1rem";
            checkbox.style.cursor = "pointer";
            checkbox.style.backgroundRepeat = "no-repeat";
            checkbox.style.backgroundPosition = "center";
            checkbox.style.backgroundSize = "contain";

            const checkSvg = "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")";

            checkbox.addEventListener("change", () => {
                checkbox.style.backgroundColor = checkbox.checked ? "rgb(0,0,0)" : "white";
                checkbox.style.backgroundImage = checkbox.checked ? checkSvg : "none";
            });

            const checkboxLabel = document.createElement("label");
            checkboxLabel.style.cursor = "pointer";
            checkboxLabel.style.fontFamily = `Programme, "Programme Pan", Arial, sans-serif`;
            checkboxLabel.style.fontSize = "0.75rem";
            checkboxLabel.style.fontWeight = "100";
            checkboxLabel.style.lineHeight = "1.1";
            checkboxLabel.style.overflowWrap = "normal";

            checkboxLabel.appendChild(document.createTextNode("OVER-"));
            checkboxLabel.appendChild(document.createElement("br"));
            checkboxLabel.appendChild(document.createTextNode("WRITE"));

            checkboxRow.appendChild(checkbox);
            checkboxRow.appendChild(checkboxLabel);

            const input1 = document.createElement("input");
            input1.type = "text";
            input1.placeholder = "Nr.";
            styleTextbox(input1);
            input1.style.flex = "0 0 3rem";

            const input2 = document.createElement("input");
            input2.type = "text";
            input2.placeholder = "Image URL";
            styleTextbox(input2);
            input2.style.flex = "1 1 auto";

            row.appendChild(checkboxRow);
            row.appendChild(input1);
            row.appendChild(input2);

            rows.push({ checkbox, input1, input2 });

            return row;
        }

        function createRow(modal) {
            if (modal.querySelector('[data-ui="album-cover-ui"]')) return;

            const artworkSection = modal.querySelectorAll('section[class^="ScrollableTabsSection__Container-"]')?.[1];
            if (!artworkSection) return;

            const wrapper = document.createElement("div");
            wrapper.dataset.ui = "album-cover-ui";
            wrapper.style.display = "flex";
            wrapper.style.gap = "1rem";
            wrapper.style.marginTop = "1rem";
            wrapper.style.padding = "1rem";
            wrapper.style.border = "1px solid";

            const leftCol = document.createElement("div");
            leftCol.style.display = "flex";
            leftCol.style.flexDirection = "column";
            leftCol.style.gap = "0.75rem";
            leftCol.style.flex = "1 1 auto";

            leftCol.appendChild(createLeftCol());

            const rightCol = document.createElement("div");
            rightCol.style.display = "flex";
            rightCol.style.gap = "0.75rem";
            rightCol.style.flex = "0 0 auto";

            const addBtn = document.createElement("button");
            addBtn.type = "button";
            addBtn.textContent = "+ Add";
            styleButton(addBtn);

            const saveBtn = document.createElement("button");
            saveBtn.type = "button";
            saveBtn.textContent = "Save";
            styleButton(saveBtn);

            rightCol.appendChild(addBtn);
            rightCol.appendChild(saveBtn);

            addBtn.addEventListener("click", () => {
                leftCol.appendChild(createLeftCol());
            });

            saveBtn.addEventListener("click", async () => {
                saveBtn.disabled = true;

                const updatedCoverArts = coverArts.map(ca => ({
                    id: ca.id
                }));

                for (const { checkbox, input1, input2 } of rows) {
                    const inputNumber = input1.value.trim();
                    const imageUrl = input2.value.trim();
                    if (!imageUrl) continue;

                    let position = null;
                    if (/^\d+$/.test(inputNumber)) {
                        position = parseInt(inputNumber, 10);
                    } else if (checkbox.checked) {
                        position = 1;
                    }

                    let newEntry;

                    if (checkbox.checked) {
                        if (position && position > 0 && position <= updatedCoverArts.length) {
                            const existingId = updatedCoverArts[position - 1].id;
                            newEntry = { id: existingId, image_url: imageUrl };
                            updatedCoverArts[position - 1] = newEntry;
                        } else {
                            newEntry = { image_url: imageUrl };
                            updatedCoverArts.push(newEntry);
                        }
                    } else {
                        newEntry = { image_url: imageUrl };

                        if (position && position > 0 && position <= updatedCoverArts.length + 1) {
                            updatedCoverArts.splice(position - 1, 0, newEntry);
                        } else {
                            updatedCoverArts.push(newEntry);
                        }
                    }
                }

                const payload = {
                    cover_arts: updatedCoverArts,
                    text_format: "html,markdown,preview"
                };

                await updateCoverArts(albumId, payload);

                const closeButton = modal.querySelector('[aria-label="Cancel"]');
                if (closeButton) closeButton.click();
            });

            wrapper.appendChild(leftCol);
            wrapper.appendChild(rightCol);
            artworkSection.appendChild(wrapper);
        }

        function styleTextbox(el) {
            el.style.padding = "0.5rem";
            el.style.border = "1px solid rgb(0, 0, 0)";
            el.style.fontFamily = `Programme, "Programme Pan", Arial, sans-serif`;
            el.style.fontSize = "1rem";
            el.style.fontWeight = "100";
            el.style.width = "100%";
        }

        function styleButton(btn) {
            btn.style.padding = "0.5rem 1.313rem";
            btn.style.border = "1px solid rgb(0, 0, 0)";
            btn.style.borderRadius = "1.25rem";
            btn.style.fontFamily = `Programme, "Programme Pan", Arial, sans-serif`;
            btn.style.fontSize = "1rem";
            btn.style.fontWeight = "100";
            btn.style.lineHeight = "1.1";
            btn.style.flex = "0 0 auto";
        }

        function startModalObserver() {
            modalObserver = new MutationObserver(() => {
                const modal = document.getElementById("edit-metadata-overlay");
                if (!modal) return;

                modalObserver.disconnect();
                createRow(modal);
                startModalCloseObserver(modal);
            });

            modalObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        function startModalCloseObserver(modal) {
            modalCloseObserver = new MutationObserver(() => {
                if (!document.body.contains(modal)) {
                    reset();
                }
            });

            modalCloseObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        function reset() {
            if (modalObserver) modalObserver.disconnect();
            if (modalCloseObserver) modalCloseObserver.disconnect();
            modalObserver = null;
            modalCloseObserver = null;

            startModalObserver();
        }

        const existingModal = document.getElementById("edit-metadata-overlay");
        if (existingModal) {
            createRow(existingModal);
            startModalCloseObserver(existingModal);
            return;
        } else {
            startModalObserver();
        }
    }










    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                METADATA EDITOR                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function songCreditsButtonAlbumPageOld(songData) {
        console.log(songData);
        const albumAdminMenu = document.querySelector('album-admin-menu');

        if (!albumAdminMenu) return;
        const SongCreditsButton = document.createElement('button');
        SongCreditsButton.className = 'square_button u-bottom_margin';
        SongCreditsButton.textContent = 'Song Credits';
        SongCreditsButton.setAttribute('ng-click', "$ctrl.songCredits()");
        SongCreditsButton.setAttribute('ng-if', "$ctrl.has_permission('songCredits')");
        SongCreditsButton.setAttribute('bis_skin_checked', '1');
        SongCreditsButton.style.marginRight = "0.25rem";

        albumAdminMenu.parentNode.insertBefore(SongCreditsButton, albumAdminMenu);

        let songIds = [];
        let csrfToken = '';
        let trackNumbers = [];
        let rawTrackNumbers = [];
        let existingSongsData = [];

        songIds = songData.map(data => data.response.song.id);
        csrfToken = getCsrfToken();
        ({ rawTrackNumbers, trackNumbers } = extractTrackNumbers());


        function extractTrackNumbers() {
            const trackContainers = document.querySelectorAll('.chart_row-number_container.chart_row-number_container--align_left');
            let currentTrackNumber = 0;

            trackContainers.forEach((container) => {
                const numberElement = container.querySelector('.chart_row-number_container-number span');
                const trackNumber = numberElement ? numberElement.textContent.trim() : '';
                rawTrackNumbers.push(trackNumber);

                if (trackNumber && !isNaN(trackNumber)) {
                    currentTrackNumber = parseInt(trackNumber, 10);
                } else {
                    currentTrackNumber += 1;
                }
                trackNumbers.push(currentTrackNumber);
            });

            return { rawTrackNumbers, trackNumbers };
        }


        SongCreditsButton.addEventListener('click', async () => {
            openOverlay(trackNumbers, rawTrackNumbers);

            const responses = await Promise.all(
                songIds.map(songId =>
                    geniusFetch(`https://genius.com/api/songs/${songId}`)
                        .then(res => res.json())
                )
            );
            existingSongsData = songIds.map((songId, index) => {
                const songDetails = responses[index]?.response?.song;


                //existingSongsData = songIds.map(songId => {
                //   const songDetails = songData.find(({ response }) => response?.song?.id === songId)?.response?.song;
                return songDetails ? {
                    id: songId,
                    existingPrimaryArtists: songDetails.primary_artists || [],
                    existingPrimaryTag: songDetails.primary_tag || null,
                    existingFeaturedArtists: songDetails.featured_artists || [],
                    existingTags: songDetails.tags || [],
                    existingReleaseDate: songDetails.release_date_components || null,
                    existingYoutubeLink: songDetails.youtube_url || null,
                    existingSoundcloudLink: songDetails.soundcloud_url || null,
                    existingWriters: songDetails.writer_artists || [],
                    existingProducers: songDetails.producer_artists || [],
                    existingRecorded: songDetails.recording_location || [],
                    existingGradient: {
                        primary: songDetails.song_art_primary_color,
                        secondary: songDetails.song_art_secondary_color,
                        text: songDetails.song_art_text_color
                    } || null,
                    existingSongCover: songDetails.custom_song_art_image_url || null,
                    existingCustomPerformances: songDetails.custom_performances || [],
                    existingSongRelationships: songDetails.song_relationships || [],
                } : null;
            });

            console.log('Existing Song Data:', existingSongsData);

            const saveButton = document.getElementById('custom-save-button');
            saveButton.style.display = 'inline-block';
        });


        function openOverlay(trackNumbers, rawTrackNumbers) {

            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
            document.head.appendChild(link);

            const style = document.createElement('style');
            style.textContent = `
                    .styled-checkbox:checked {
                        accent-color: #8e8e8e;
                    }
                    .overwrite-container {
                        accent-color: #99a7ee;
                    }
                `;
            document.head.appendChild(style);

            const overlay = createOverlay();
            document.body.appendChild(overlay);
            const form = createForm();
            overlay.appendChild(form);

            let activeTagsList;
            let roleIndex = 0;
            let primaryArtistsArray = [];
            let featuredArtistsArray = [];
            let tagsArray = [];
            let geniusLinks = [];
            let youtubeLinks = [];
            let soundcloudLinks = [];
            let producersArray = [];
            let writersArray = [];
            let recordedArray = [];
            let primaryColorArray = [];
            let secondaryColorArray = [];
            let textColorArray = [];
            let gradientCheckArray = [];
            let additionalRolesArray = [];
            let artistRolesArray = [];

            /*
            form.appendChild(createTitle('Artwork Extractor for Genius'));
            form.appendChild(createTracklist(trackNumbers, rawTrackNumbers));
            form.appendChild(createLine());
            form.appendChild(createSpacer('1.25rem'));

              form.appendChild(createContainer([
                  () => createRelationships(),
                  () => createInputTextField('Related album', 'related_album', 'Genius Album URL')
              ]));
              form.appendChild(createSpacer('1.00rem'));
              form.appendChild(createContainer([
                  () => createInputTagField('Primary Artists', 'primary_artists', 'artists'),
                  () => createInputPrimaryTag()
              ]));
              form.appendChild(createSpacer('1.00rem'));
              form.appendChild(createContainer([
                  () => createInputTagField('Tags', 'tags', 'tags'),
                  () => createInputReleaseDate()
              ]));
              form.appendChild(createSpacer('1.00rem'));
              form.appendChild(createContainer([
                  () => createInputTextField('YouTube URL', 'youtube_links', 'YouTube Playlist URL'),
                  () => createInputTextField('SoundCloud URL', 'soundcloud_links', 'SoundCloud Playlist URL')
              ]));
              form.appendChild(createSpacer('1.00rem'));
              form.appendChild(createContainer([
                  () => createInputTagField('Producers', 'producers', 'artists'),
                  () => createInputTagField('Writers', 'writers', 'artists')
              ]));
              form.appendChild(createSpacer('1.00rem'));
              form.appendChild(createAdditionalCredits());
              form.appendChild(createSpacer('1.75rem'));
              const { statusDisplay, saveButton, cancelButton } = createStatusSaveCancelButton();
              form.appendChild(statusDisplay);
              form.appendChild(saveButton);
              form.appendChild(cancelButton);
    */

            const order = result.functionOrder || {
                song_relationship: 1,
                related_album: 2,
                language: 3,
                primary_artists: 4,
                featured_artists: 5,
                primary_tag: 6,
                tags: 7,
                release_date: 8,
                recorded_at: 9,
                youtube_url: 10,
                soundcloud_url: 0,
                producers: 12,
                writers: 13,
                gradient: 0,
                additional_credits: 15,
            };
            const functions = [
                //{ key: 'relationship_language', fn: () => createRelationshipLanguageContainer() },
                { key: 'song_relationship', fn: () => createRelationships() },
                { key: 'related_album', fn: () => createInputTextField('Related album', 'related_album', 'Genius Album URL') },
                { key: 'language', fn: () => createLanguage() },
                { key: 'primary_artists', fn: () => createInputTagField('Primary Artists', 'primary_artists', 'artists') },
                { key: 'featured_artists', fn: () => createInputTagField('Featured Artists', 'featured_artists', 'artists') },
                { key: 'primary_tag', fn: () => createInputPrimaryTag() },
                { key: 'tags', fn: () => createInputTagField('Tags', 'tags', 'tags') },
                { key: 'release_date', fn: () => createInputReleaseDate() },
                { key: 'youtube_url', fn: () => createInputTextField('YouTube URL', 'youtube_links', 'YouTube Playlist URL') },
                { key: 'recorded_at', fn: () => createInputTextField('Recorded At', 'recorded_at', 'Add Recording Location') },
                // { key: 'gradient', fn: () => createInputColorFields() },
                { key: 'soundcloud_url', fn: () => createInputTextField('SoundCloud URL', 'soundcloud_links', 'SoundCloud Playlist URL') },
                { key: 'producers', fn: () => createInputTagField('Producers', 'producers', 'artists') },
                { key: 'writers', fn: () => createInputTagField('Writers', 'writers', 'artists') },
                { key: 'additional_credits', fn: () => createAdditionalCredits() }
            ];

            const sortedFunctions = functions
                .filter(f => order[f.key] > 0 && f.key !== 'additional_credits')
                .sort((a, b) => order[a.key] - order[b.key]);

            let groupedFunctions = [];
            const group123 = [1, 2, 3]
                .map(pos => sortedFunctions.find(f => order[f.key] === pos))
                .filter(f => f !== undefined)
                .map(f => f.fn);

            if (group123.length > 0) {
                group123._gap = (group123.length === 3) ? '0.75rem' : null;
                groupedFunctions.push(group123);
            }

            for (let i = 4; i <= 14; i += 2) {
                const group = [];

                const first = sortedFunctions.find(f => order[f.key] === i);
                if (first) group.push(first.fn);
                const second = sortedFunctions.find(f => order[f.key] === i + 1);
                if (second) group.push(second.fn);

                if (group.length > 0) groupedFunctions.push(group);
            }

            form.appendChild(createTitle('Artwork Extractor for Genius'));
            form.appendChild(createTracklist(trackNumbers, rawTrackNumbers));
            form.appendChild(createLine());
            form.appendChild(createSpacer('1.25rem'));

            groupedFunctions.forEach(group => {
                const container = createContainer(group);
                if (group._gap) {
                    container.style.gap = group._gap;
                }
                form.appendChild(container);
                form.appendChild(createSpacer('1.00rem'));
            });

            if (order['additional_credits'] === 15) {
                form.appendChild(createAdditionalCredits());
                form.appendChild(createSpacer('1.75rem'));
            }


            const { statusDisplay, saveButton, cancelButton, autoReopenToggle } = createStatusSaveCancelButton();
            form.appendChild(autoReopenToggle);
            form.appendChild(statusDisplay);
            form.appendChild(saveButton);
            form.appendChild(cancelButton);



            overlay.addEventListener('click', (event) => {
                if (event.target === overlay) document.body.removeChild(overlay);
            });

            saveButton.addEventListener('click', async (event) => {
                event.preventDefault();

                const checkboxStates = {
                    overwriteRelationship: document.querySelector('#overwrite_related_album')?.checked,
                    overwritePrimaryArtists: document.querySelector('#overwrite_primary_artists')?.checked,
                    overwriteFeaturedArtists: document.querySelector('#overwrite_featured_artists')?.checked,
                    overwritePrimaryTag: document.querySelector('#overwrite_primary_tag')?.checked,
                    overwriteTags: document.querySelector('#overwrite_tags')?.checked,
                    overwriteReleaseDate: document.querySelector('#overwrite_release_date')?.checked,
                    overwriteYouTube: document.querySelector('#overwrite_youtube_links')?.checked,
                    overwriteSoundCloud: document.querySelector('#overwrite_soundcloud_links')?.checked,
                    overwriteProducers: document.querySelector('#overwrite_producers')?.checked,
                    overwriteWriters: document.querySelector('#overwrite_writers')?.checked,
                    overwriteRecorded: document.querySelector('#overwrite_recorded_at')?.checked,
                    overwriteGradient: document.querySelector('#overwrite_gradient')?.checked,
                    overwriteCredits: document.querySelector('#overwrite_credits')?.checked,
                    removeRelationship: document.querySelector('#remove_related_album')?.checked,
                    removePrimaryArtists: document.querySelector('#remove_primary_artists')?.checked,
                    removeFeaturedArtists: document.querySelector('#remove_featured_artists')?.checked,
                    removePrimaryTag: document.querySelector('#remove_primary_tag')?.checked,
                    removeTags: document.querySelector('#remove_tags')?.checked,
                    removeReleaseDate: document.querySelector('#remove_release_date')?.checked,
                    removeYouTube: document.querySelector('#remove_youtube_links')?.checked,
                    removeSoundCloud: document.querySelector('#remove_soundcloud_links')?.checked,
                    removeProducers: document.querySelector('#remove_producers')?.checked,
                    removeWriters: document.querySelector('#remove_writers')?.checked,
                    removeRecorded: document.querySelector('#remove_recorded_at')?.checked,
                    removeGradient: document.querySelector('#remove_gradient')?.checked,
                    removeCredits: document.querySelector('#remove_credits')?.checked
                };

                for (let i = 0; i <= roleIndex - 1; i++) {
                    checkboxStates[`overwriteAdditionalRole${i}`] = document.querySelector(`#overwrite_additional_role_${i}`)?.checked;
                    checkboxStates[`removeAdditionalRole${i}`] = document.querySelector(`#remove_additional_role_${i}`)?.checked;
                }

                const primaryTagIds = {
                    'Pop': 16,
                    'Rap': 1434,
                    'Rock': 567,
                    'R&B': 352,
                    'Country': 413,
                    'Electronic': 606,
                    'Non-Music': 1452
                };

                const relationshipType = {
                    'Samples': 'samples',
                    'Interpolates': 'interpolates',
                    'Cover Of': 'cover_of',
                    'Remix Of': 'remix_of',
                    'Live Version Of': 'live_version_of',
                    'Translation Of': 'translation_of',
                };

                const languageType = {
                    'bosanski': 'bs',
                    'crnogorski': 'cnr',
                    'Deutsch': 'de',
                    'Österreichisches Deutsch': 'de-at',
                    'English': 'en',
                    'Español': 'es',
                    'Français': 'fr',
                    'Schweizerdeutsch': 'gsw',
                    'hrvatski': 'hr',
                    'Italiano': 'it',
                    'Kölsch': 'ksh',
                    'Македонски': 'mk',
                    'Nederlands': 'nl',
                    'Norsk': 'no',
                    'Polski': 'pl',
                    'Português': 'pt',
                    'Русский (Russian)': 'ru',
                    'srpski': 'sr',
                    'Svenska': 'sv',
                    'Türkçe': 'tr',
                    'o‘zbekcha': 'uz',
                    'Tiếng Việt': 'vi',
                    '简体中文 (Simplified Chinese)': 'zh',
                    '繁體中文 (Traditional Chinese)': 'zh-Hant',
                };

                // Credits abrufen
                const checkedSongIds = songIds.filter((songId) => {
                    const checkbox = document.querySelector(`#checkbox_${songId}`);
                    return checkbox?.checked;
                });
                const songRelationshipsPayload = geniusLinks.map((songId, index) => ({
                    type: relationshipType[document.querySelector('#relationshipSelect')?.value],
                    song_ids: [songId]
                }));
                const languagePayload = languageType[document.querySelector('#languageSelect')?.value];
                const primaryArtistsPayload = primaryArtistsArray.map(primary_artists => ({ id: primary_artists.id, name: primary_artists.name }));
                const featuredArtistsPayload = featuredArtistsArray.map(featured_artists => ({ id: featured_artists.id, name: featured_artists.name }));
                const primaryTagPayload = primaryTagIds[document.querySelector('#genreSelect')?.value];
                const tagsPayload = tagsArray.map(tag => ({ id: tag.id, name: tag.name }));
                const releaseDatePayload = {
                    month: document.querySelector('#monthSelect').value ? parseInt(document.querySelector('#monthSelect').value, 10) : null,
                    day: document.querySelector('#daySelect').value ? parseInt(document.querySelector('#daySelect').value, 10) : null,
                    year: document.querySelector('#yearSelect').value ? parseInt(document.querySelector('#yearSelect').value, 10) : null
                };
                const youtubePayload = youtubeLinks;
                const producersPayload = producersArray.map(producer => ({ id: producer.id, name: producer.name }));
                const writersPayload = writersArray.map(writer => ({ id: writer.id, name: writer.name }));
                const recordedPayload = recordedArray;
                const gradientPayload = {
                    primary: primaryColorArray,
                    secondary: secondaryColorArray,
                    text: textColorArray,
                    contrast: gradientCheckArray
                };
                const additionalCreditsPayload = additionalRolesArray.map((role, index) => {
                    const label = role[0]?.label;
                    const artists = artistRolesArray[index]?.map(artist => ({ id: artist.id, name: artist.name })) || [];

                    if (label && artists.length > 0) {
                        return { label, artists };
                    }

                    return null;
                }).filter(entry => entry !== null);

                /*
                                const additionalCreditsPayload = additionalRolesArray.map((role, index) => ({
                                    label: role[0]?.label,
                                    artists: artistRolesArray[index]?.map(artist => ({ id: artist.id, name: artist.name })) || []
                                }));

                */
                console.log('Song ID Checkboxes:', checkedSongIds);
                console.log('Checkbox States:', checkboxStates);
                console.log('Song Relationships:', songRelationshipsPayload);
                console.log('Language:', languagePayload);
                console.log('Primary Artists:', primaryArtistsPayload);
                console.log('Featured Artists:', featuredArtistsPayload);
                console.log('Primary Tag:', primaryTagPayload);
                console.log('Tags:', tagsPayload);
                console.log('Release Date:', releaseDatePayload);
                console.log('YouTube-Links:', youtubePayload);
                console.log('Producers:', producersPayload);
                console.log('Writers:', writersPayload);
                console.log('Recorded At:', recordedPayload);
                console.log('Gradient:', gradientPayload);
                console.log('Additional Credits:', additionalCreditsPayload);

                for (let i = 0; i < checkedSongIds.length; i++) {
                    const songId = checkedSongIds[i];
                    const currentIndex = i + 1;
                    await processSong(
                        songId,
                        existingSongsData,
                        checkboxStates,
                        primaryArtistsPayload,
                        featuredArtistsPayload,
                        primaryTagPayload,
                        tagsPayload,
                        releaseDatePayload,
                        youtubePayload,
                        producersPayload,
                        writersPayload,
                        recordedPayload,
                        gradientPayload,
                        additionalCreditsPayload,
                        songRelationshipsPayload,
                        languagePayload,
                        currentIndex,
                        checkedSongIds.length
                    );
                }

                //const promises = checkedSongIds.map(songId => processSong(songId, existingSongsData, checkboxStates,
                //    primaryArtistsPayload, featuredArtistsPayload, primaryTagPayload, tagsPayload, releaseDatePayload, youtubePayload, producersPayload, writersPayload, recordedPayload, gradientPayload, additionalCreditsPayload, songRelationshipsPayload, languagePayload));
                //await Promise.all(promises);

                async function processSong(
                    songId,
                    existingSongsData,
                    checkboxStates,
                    primaryArtistsPayload,
                    featuredArtistsPayload,
                    primaryTagPayload,
                    tagsPayload,
                    releaseDatePayload,
                    youtubePayload,
                    producersPayload,
                    writersPayload,
                    recordedPayload,
                    gradientPayload,
                    additionalCreditsPayload,
                    songRelationshipsPayload,
                    languagePayload,
                    currentIndex,
                    totalCount
                ) {
                    const existingSongData = existingSongsData.find(song => song.id === songId);
                    if (!existingSongData) return;

                    //statusDisplay.innerHTML = `Saving Track <strong>${currentIndex}</strong> of <strong>${totalCount}</strong>...`;
                    statusDisplay.textContent = ""; // Reset
                    const text1 = document.createTextNode("Saving Track ");
                    statusDisplay.appendChild(text1);
                    const strong1 = document.createElement("strong");
                    strong1.textContent = currentIndex;
                    statusDisplay.appendChild(strong1);
                    const text2 = document.createTextNode(" of ");
                    statusDisplay.appendChild(text2);
                    const strong2 = document.createElement("strong");
                    strong2.textContent = totalCount;
                    statusDisplay.appendChild(strong2);
                    const text3 = document.createTextNode("...");
                    statusDisplay.appendChild(text3);


                    let { existingPrimaryArtists, existingFeaturedArtists, existingPrimaryTag, existingTags, existingReleaseDate, existingYoutubeLink, existingSoundcloudLink, existingWriters, existingProducers, existingRecorded, existingGradient, existingSongCover, existingCustomPerformances, existingSongRelationships } = existingSongData;

                    const songIndex = songIds.indexOf(songId);

                    const payload = {
                        text_format: "html,markdown",
                        song: {}
                    };


                    if (primaryArtistsPayload.length != 0 || checkboxStates.overwritePrimaryArtists || checkboxStates.removePrimaryArtists) {
                        if (checkboxStates.overwritePrimaryArtists && primaryArtistsPayload) {
                            payload.song.primary_artists = primaryArtistsPayload;
                        } else if (checkboxStates.removePrimaryArtists && primaryArtistsPayload) {
                            const remainingArtists = existingPrimaryArtists.filter(existingPrimaryArtist => !primaryArtistsPayload.some(removeArtist => removeArtist.id === existingPrimaryArtist.id));
                            payload.song.primary_artists = remainingArtists.length > 0 ? remainingArtists : existingPrimaryArtists.slice(0, 1);
                        } else {
                            payload.song.primary_artists = [
                                ...existingPrimaryArtists,
                                ...primaryArtistsPayload.filter(newPrimaryArtist => !existingPrimaryArtists.some(existingPrimaryArtist => existingPrimaryArtist.id === newPrimaryArtist.id))
                            ];
                        }
                    }

                    if (featuredArtistsPayload.length != 0 || checkboxStates.overwriteFeaturedArtists || checkboxStates.removeFeaturedArtists) {
                        if (checkboxStates.overwriteFeaturedArtists && featuredArtistsPayload) {
                            payload.song.featured_artists = featuredArtistsPayload;
                        } else if (checkboxStates.removeFeaturedArtists && featuredArtistsPayload) {
                            const isMarkedForDeletion = featuredArtistsPayload.length === 1 && featuredArtistsPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.featured_artists = [];
                            } else {
                                payload.song.featured_artists = existingFeaturedArtists.filter(
                                    existingFeaturedArtist => !featuredArtistsPayload.some(removeFeaturedArtist => removeFeaturedArtist.id === existingFeaturedArtist.id)
                                );
                            }
                        } else {
                            payload.song.featured_artists = [
                                ...existingFeaturedArtists,
                                ...featuredArtistsPayload.filter(
                                    newFeaturedArtist => !existingFeaturedArtists.some(existingFeaturedArtist => existingFeaturedArtist.id === newFeaturedArtist.id)
                                )
                            ];
                        }
                    }

                    if (primaryTagPayload || checkboxStates.overwritePrimaryTag || checkboxStates.removePrimaryTag) {
                        if (checkboxStates.overwritePrimaryTag && primaryTagPayload) {
                            existingTags = existingTags.filter(tag => tag.id !== existingPrimaryTag.id);
                            payload.song.primary_tag_id = primaryTagPayload;
                        } else if (checkboxStates.removePrimaryTag && primaryTagPayload) {
                            existingTags = existingTags.filter(tag => !Object.values(primaryTagIds).includes(tag.id));
                            payload.song.primary_tag_id = primaryTagPayload;
                        } else {
                            payload.song.primary_tag_id = primaryTagPayload;
                        }
                    }

                    if (tagsPayload.length != 0 || checkboxStates.overwriteTags || checkboxStates.removeTags || checkboxStates.overwritePrimaryTag || checkboxStates.removePrimaryTag) {
                        if (checkboxStates.overwriteTags && tagsPayload) {
                            payload.song.tags = tagsPayload;
                        } else if (checkboxStates.removeTags && tagsPayload) {
                            payload.song.tags = existingTags.filter(existingTag => !tagsPayload.some(removeTag => removeTag.id === existingTag.id));
                        } else {
                            payload.song.tags = [...existingTags, ...tagsPayload.filter(newTag => !existingTags.some(existingTag => existingTag.id === newTag.id))];
                        }
                    }

                    if (youtubePayload.length != 0 || checkboxStates.overwriteYouTube || checkboxStates.removeYouTube) {
                        if (checkboxStates.overwriteYouTube && youtubePayload) {
                            payload.song.youtube_url = youtubePayload[songIndex];
                        } else if (checkboxStates.removeYouTube && youtubeLinks === "Delete") {
                            payload.song.youtube_url = null;
                        } else if (!existingYoutubeLink) {
                            payload.song.youtube_url = youtubePayload[songIndex];
                        }
                    }

                    if ((releaseDatePayload?.day != null || releaseDatePayload?.month != null || releaseDatePayload?.year != null) || checkboxStates.overwriteReleaseDate || checkboxStates.removeReleaseDate) {
                        if (checkboxStates.overwriteReleaseDate && (releaseDatePayload?.day != null || releaseDatePayload?.month != null || releaseDatePayload?.year != null)) {
                            payload.song.release_date_components = {
                                day: releaseDatePayload?.day || null,
                                month: releaseDatePayload?.month || null,
                                year: releaseDatePayload?.year || null
                            };
                        } else if (checkboxStates.removeReleaseDate) {
                            payload.song.release_date_components = {
                                day: (releaseDatePayload?.day === 31) ? null : existingReleaseDate?.day || null,
                                month: (releaseDatePayload?.month === 12) ? null : existingReleaseDate?.month || null,
                                year: (releaseDatePayload?.year === 1900) ? null : existingReleaseDate?.year || null
                            };
                        } /*else {
                            payload.song.release_date_components = {
                                day: existingReleaseDate?.day || releaseDatePayload?.day || null,
                                month: existingReleaseDate?.month || releaseDatePayload?.month || null,
                                year: existingReleaseDate?.year || releaseDatePayload?.year || null
                            };
                        }*/
                        else {
                            const hasPayloadDay = releaseDatePayload?.day != null;
                            const hasPayloadMonth = releaseDatePayload?.month != null;
                            const hasPayloadYear = releaseDatePayload?.year != null;

                            const hasExistingDay = existingReleaseDate?.day != null;
                            const hasExistingMonth = existingReleaseDate?.month != null;
                            const hasExistingYear = existingReleaseDate?.year != null;

                            if (hasExistingYear && hasExistingMonth && hasExistingDay) {
                                payload.song.release_date_components = {
                                    day: existingReleaseDate.day,
                                    month: existingReleaseDate.month,
                                    year: existingReleaseDate.year
                                };
                            } else if (hasExistingYear && hasExistingMonth) {
                                const sameMonth = releaseDatePayload.month === existingReleaseDate?.month;
                                const sameYear = releaseDatePayload.year === existingReleaseDate?.year;

                                payload.song.release_date_components = {
                                    day: (sameMonth && sameYear) ? releaseDatePayload.day || existingReleaseDate?.day || null : existingReleaseDate?.day || null,
                                    month: existingReleaseDate.month,
                                    year: existingReleaseDate.year
                                };
                            } else if (hasExistingYear) {
                                const sameYear = releaseDatePayload.year === existingReleaseDate?.year;

                                payload.song.release_date_components = {
                                    day: sameYear ? releaseDatePayload.day || existingReleaseDate?.day || null : existingReleaseDate?.day || null,
                                    month: sameYear ? releaseDatePayload.month || existingReleaseDate?.month || null : existingReleaseDate?.month || null,
                                    year: existingReleaseDate.year
                                };
                            } else {
                                payload.song.release_date_components = {
                                    day: releaseDatePayload?.day || null,
                                    month: releaseDatePayload?.month || null,
                                    year: releaseDatePayload?.year || null
                                };
                            }
                        }
                    }

                    if (producersPayload.length != 0 || checkboxStates.overwriteProducers || checkboxStates.removeProducers) {
                        if (checkboxStates.overwriteProducers && producersPayload) {
                            payload.song.producer_artists = producersPayload;
                        } else if (checkboxStates.removeProducers && producersPayload) {
                            const isMarkedForDeletion = producersPayload.length === 1 && producersPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.producer_artists = [];
                            } else {
                                payload.song.producer_artists = existingProducers.filter(
                                    existingProducer => !producersPayload.some(removeProducer => removeProducer.id === existingProducer.id)
                                );
                            }
                        } else {
                            payload.song.producer_artists = [
                                ...existingProducers,
                                ...producersPayload.filter(
                                    newProducer => !existingProducers.some(existingProducer => existingProducer.id === newProducer.id)
                                )
                            ];
                        }
                    }

                    if (writersPayload.length != 0 || checkboxStates.overwriteWriters || checkboxStates.removeWriters) {
                        if (checkboxStates.overwriteWriters && writersPayload) {
                            payload.song.writer_artists = writersPayload;
                        } else if (checkboxStates.removeWriters && writersPayload) {
                            const isMarkedForDeletion = writersPayload.length === 1 && writersPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.writer_artists = [];
                            } else {
                                payload.song.writer_artists = existingWriters.filter(
                                    existingWriter => !writersPayload.some(removeWriter => removeWriter.id === existingWriter.id)
                                );
                            }
                        } else {
                            payload.song.writer_artists = [
                                ...existingWriters,
                                ...writersPayload.filter(
                                    newWriter => !existingWriters.some(existingWriter => existingWriter.id === newWriter.id)
                                )
                            ];
                        }
                    }

                    if (recordedPayload.length != 0 || checkboxStates.overwriteRecorded || checkboxStates.removeRecorded) {
                        if (checkboxStates.overwriteRecorded && recordedPayload) {
                            payload.song.recording_location = recordedPayload;
                        } else if (checkboxStates.removeRecorded && recordedPayload === "Delete") {
                            payload.song.recording_location = null;
                        } else if (existingRecorded.length === 0) {
                            payload.song.recording_location = recordedPayload;
                        }
                    }

                    if (gradientPayload.length != 0) {
                        if (checkboxStates.removeGradient && gradientPayload) {
                            payload.song.song_art_primary_color = gradientPayload.primary;
                            payload.song.song_art_secondary_color = gradientPayload.secondary;
                            payload.song.song_art_text_color = gradientPayload.text;
                            payload.song.valid_song_art_contrast = gradientPayload.contrast;
                        } else if (!existingSongCover && checkboxStates.overwriteGradient && gradientPayload) {
                            payload.song.song_art_primary_color = gradientPayload.primary;
                            payload.song.song_art_secondary_color = gradientPayload.secondary;
                            payload.song.song_art_text_color = gradientPayload.text;
                            payload.song.valid_song_art_contrast = gradientPayload.contrast;
                        } else if (!existingSongCover && gradientPayload &&
                            existingSongsData.some(song => song.existingGradient &&
                                song.existingGradient.primary === gradientPayload.primary &&
                                song.existingGradient.secondary === gradientPayload.secondary &&
                                song.existingGradient.text === gradientPayload.text)) {
                            payload.song.song_art_primary_color = gradientPayload.primary;
                            payload.song.song_art_secondary_color = gradientPayload.secondary;
                            payload.song.song_art_text_color = gradientPayload.text;
                            payload.song.valid_song_art_contrast = gradientPayload.contrast;
                        }
                    }

                    if (additionalCreditsPayload.length !== 0) {
                        let updatedPerformances = [...existingCustomPerformances];

                        additionalCreditsPayload.forEach((newRole, index) => {
                            const label = newRole.label;
                            const overwrite = checkboxStates[`overwriteAdditionalRole${index}`];
                            const remove = checkboxStates[`removeAdditionalRole${index}`];

                            const existingIndex = updatedPerformances.findIndex(role => role.label === label);

                            if (overwrite) {
                                if (existingIndex !== -1) {
                                    updatedPerformances[existingIndex] = {
                                        label,
                                        artists: newRole.artists.map(({ id, name }) => ({ id, name }))
                                    };
                                } else {
                                    updatedPerformances.push({
                                        label,
                                        artists: newRole.artists.map(({ id, name }) => ({ id, name }))
                                    });
                                }

                            } else if (remove) {
                                if (existingIndex !== -1) {
                                    const existingRole = updatedPerformances[existingIndex];
                                    const filteredArtists = existingRole.artists.filter(artist =>
                                        !newRole.artists.some(toRemove => toRemove.id === artist.id)
                                    );

                                    if (filteredArtists.length === 0 || newRole.artists.some(artist => artist.id === 87999)) {
                                        updatedPerformances.splice(existingIndex, 1);
                                    } else {
                                        updatedPerformances[existingIndex] = {
                                            label,
                                            artists: filteredArtists
                                        };
                                    }
                                }

                            } else {
                                if (existingIndex !== -1) {
                                    const combinedArtists = [
                                        ...updatedPerformances[existingIndex].artists,
                                        ...newRole.artists
                                    ].filter((artist, i, self) =>
                                        self.findIndex(a => a.id === artist.id) === i
                                    );

                                    updatedPerformances[existingIndex] = {
                                        label,
                                        artists: combinedArtists
                                    };
                                } else {
                                    updatedPerformances.push({
                                        label,
                                        artists: newRole.artists.map(({ id, name }) => ({ id, name }))
                                    });
                                }
                            }
                        });

                        payload.song.custom_performances = updatedPerformances;
                    }

                    if (songRelationshipsPayload[songIndex] || checkboxStates.overwriteRelationship || checkboxStates.removeRelationship) {
                        if (checkboxStates.overwriteRelationship && songRelationshipsPayload[songIndex]) {
                            const existingRelationships = existingSongsData.find(song => song.id === songIds[songIndex])?.existingSongRelationships || [];

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                song_ids: rel.songs?.map(song => song.id) || [],
                                type: rel.type
                            }));

                            const newRelationship = {
                                song_ids: songRelationshipsPayload[songIndex].song_ids,
                                type: songRelationshipsPayload[songIndex].type
                            };

                            const updatedRelationships = payload.song.song_relationships_by_id.filter(rel => rel.type !== newRelationship.type);
                            payload.song.song_relationships_by_id = [...updatedRelationships, newRelationship];
                        } else if (checkboxStates.removeRelationship && songRelationshipsPayload) {
                            const existingRelationships = existingSongsData.find(song => song.id === songIds[songIndex])?.existingSongRelationships || [];

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                song_ids: rel.songs?.map(song => song.id) || [],
                                type: rel.type
                            }));

                            const relationshipToRemove = songRelationshipsPayload[songIndex];
                            const existingRelationship = payload.song.song_relationships_by_id.find(rel => rel.type === relationshipToRemove.type);

                            if (relationshipToRemove.song_ids.includes("Delete")) {
                                existingRelationship.song_ids = [];
                            } else {
                                existingRelationship.song_ids = existingRelationship.song_ids.filter(id => !relationshipToRemove.song_ids.includes(String(id)));
                            }
                        } else {
                            const existingRelationships = existingSongsData.find(song => song.id === songIds[songIndex])?.existingSongRelationships || [];

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                song_ids: rel.songs?.map(song => song.id) || [],
                                type: rel.type
                            }));

                            const newRelationship = {
                                song_ids: songRelationshipsPayload[songIndex].song_ids,
                                type: songRelationshipsPayload[songIndex].type
                            };

                            const existingRelationship = payload.song.song_relationships_by_id.find(rel => rel.type === newRelationship.type);
                            existingRelationship.song_ids = [...new Set([...existingRelationship.song_ids, ...newRelationship.song_ids])];
                        }
                    }

                    if (languagePayload) {
                        payload.song.language = languagePayload;
                    }

                    console.log(`Payload for Song ID ${songId}:`, payload);

                    sendUpdateRequest(songId, payload);
                    await new Promise(resolve => setTimeout(resolve, 400));
                }

                setTimeout(() => {
                    document.body.removeChild(overlay);

                    const albumButtons = document.querySelectorAll('.square_button.u-bottom_margin');
                    albumButtons.forEach((button, index) => {
                        if (index >= 2) button.remove();
                    });
                    const expandButton = document.querySelector('.expand-text');
                    if (expandButton) {
                        expandButton.remove();
                    }
                    const albumId = document.querySelectorAll('[ng-transclude-slot="secondary"]');
                    if (albumId.length > 1) {
                        albumId[1].remove();
                    }

                    main()

                    if (autoReopenSongCredits) waitForSongCreditsButton();
                }, 1000);

            });

            // ? main() rebuilds the album buttons asynchronously, so wait for the fresh "Song Credits" button before reopening the editor.
            function waitForSongCreditsButton() {
                let attempts = 0;
                const timer = setInterval(() => {
                    const button = [...document.querySelectorAll('button.square_button')].find(btn => btn.textContent.trim() === 'Song Credits');

                    if (button) {
                        clearInterval(timer);
                        button.click();
                    } else if (++attempts >= 50) {
                        clearInterval(timer);
                    }
                }, 100);
            }

            cancelButton.addEventListener('click', (event) => {
                event.preventDefault();
                document.body.removeChild(overlay);
            });

            const closeButtonContainer = createCloseButton();
            form.appendChild(closeButtonContainer);
            closeButtonContainer.addEventListener('click', () => {
                document.body.removeChild(overlay);
            });



            function createLine() {
                const horizontalLine = document.createElement('hr');
                horizontalLine.style.border = 'none';
                horizontalLine.style.borderTop = '0.5rem solid #ccc';
                horizontalLine.style.margin = '1rem 0';
                return horizontalLine;
            }

            function createSpacer(marginHeight) {
                const spacer = document.createElement('div');
                spacer.style.margin = `${marginHeight} 0`;
                return spacer;
            }

            function createOverlay() {
                const overlay = document.createElement('div');
                overlay.className = 'overlay';
                overlay.style.position = 'fixed';
                overlay.style.top = '0';
                overlay.style.left = '0';
                overlay.style.width = '100%';
                overlay.style.height = '100%';
                overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
                overlay.style.display = 'flex';
                overlay.style.justifyContent = 'center';
                overlay.style.alignItems = 'center';
                overlay.style.zIndex = '1000';
                return overlay
            }

            function createForm() {
                const form = document.createElement('form');
                form.className = 'EditMetadataModal__Form-sc-89607f9a-1 ASljL';
                form.style.backgroundColor = '#e9e9e9';
                form.style.padding = '20px';
                form.style.borderRadius = '5px';
                form.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.8)';
                form.style.width = '80%';
                form.style.maxWidth = '800px';
                form.style.height = '96%';
                form.style.overflowY = 'auto';
                form.style.boxSizing = 'border-box';
                return form;
            }

            function createTitle(title) {
                const titleContainer = document.createElement('div');
                titleContainer.style.backgroundColor = '#99a7ee';
                titleContainer.style.color = '#fff';
                titleContainer.style.textAlign = 'center';
                titleContainer.style.marginTop = '-20px';
                titleContainer.style.marginLeft = '-20px';
                titleContainer.style.marginRight = '-20px';
                titleContainer.style.padding = '1px';
                titleContainer.style.fontWeight = 'bold';
                titleContainer.textContent = title;
                return titleContainer;
            }

            function createTracklist(trackNumbers, rawTrackNumbers) {
                const tracklistContainer = document.createElement('div');
                tracklistContainer.style.flexDirection = 'column';
                tracklistContainer.style.paddingTop = '1rem';

                const tracklistLabel = document.createElement('div');
                tracklistLabel.className = 'text_label';
                tracklistLabel.textContent = 'Tracklist';
                tracklistLabel.style.display = 'flex';
                tracklistLabel.style.alignItems = 'center';
                tracklistLabel.style.justifyContent = 'space-between';

                const allTracksContainer = document.createElement('div');
                allTracksContainer.className = 'overwrite-container';
                allTracksContainer.style.display = 'flex';
                allTracksContainer.style.alignItems = 'center';

                const allTracksButton = document.createElement('div');
                allTracksButton.id = 'toggle_all_tracks';
                allTracksButton.textContent = 'All / None';
                allTracksButton.style.cursor = 'pointer';
                allTracksButton.style.textDecoration = 'underline';
                allTracksButton.style.display = 'inline-block';

                allTracksButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    const checkboxes = document.querySelectorAll('.styled-checkbox');
                    const allSelected = Array.from(checkboxes).every(checkbox => checkbox.checked);
                    checkboxes.forEach(checkbox => checkbox.checked = !allSelected);
                });

                allTracksContainer.appendChild(allTracksButton);
                tracklistLabel.appendChild(allTracksContainer);

                const checkboxContainer = document.createElement('div');
                checkboxContainer.style.display = 'grid';

                const itemsPerRow = Math.ceil(trackNumbers.length / Math.ceil(trackNumbers.length / 15));
                checkboxContainer.style.gridTemplateColumns = `repeat(${itemsPerRow}, auto)`;

                tracklistContainer.appendChild(tracklistLabel);
                tracklistContainer.appendChild(checkboxContainer);

                function toRoman(num) {
                    const romanMap = [
                        ['M', 1000],
                        ['CM', 900],
                        ['D', 500],
                        ['CD', 400],
                        ['C', 100],
                        ['XC', 90],
                        ['L', 50],
                        ['XL', 40],
                        ['X', 10],
                        ['IX', 9],
                        ['V', 5],
                        ['IV', 4],
                        ['I', 1],
                    ];
                    let roman = '';
                    romanMap.forEach(([symbol, value]) => {
                        while (num >= value) {
                            roman += symbol;
                            num -= value;
                        }
                    });
                    return roman;
                }

                let autoCounter = 1;
                songIds.forEach((songId, index) => {
                    const checkboxDiv = document.createElement('div');
                    checkboxDiv.style.display = 'flex';
                    checkboxDiv.style.alignItems = 'center';
                    checkboxDiv.style.justifyContent = 'center';

                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.id = `checkbox_${songId}`;
                    checkbox.name = `song_${songId}`;

                    const rawTrackNumber = rawTrackNumbers[index];
                    checkbox.checked = rawTrackNumber !== '';
                    checkbox.className = 'styled-checkbox';
                    checkbox.style.cursor = 'pointer';

                    const label = document.createElement('label');
                    label.htmlFor = `checkbox_${songId}`;
                    label.textContent = rawTrackNumber !== '' ? `${rawTrackNumber}` : toRoman(autoCounter++);
                    label.style.marginLeft = '0.25rem';
                    label.style.textAlign = songIds.length <= 15 ? 'left' : 'right';
                    label.style.width = '0.85rem';
                    label.style.display = 'inline-block';
                    label.style.cursor = 'pointer';

                    checkboxDiv.appendChild(checkbox);
                    checkboxDiv.appendChild(label);
                    checkboxContainer.appendChild(checkboxDiv);
                });

                tracklistContainer.appendChild(tracklistLabel);
                tracklistContainer.appendChild(checkboxContainer);
                return tracklistContainer;
            }

            function createOverwriteContainer(overwriteCheckboxId, removeCheckboxId, parentLabel) {
                const overwriteContainer = document.createElement('div');
                overwriteContainer.className = 'overwrite-container';
                overwriteContainer.style.display = 'flex';
                overwriteContainer.style.alignItems = 'center';

                const overwriteCheckbox = document.createElement('input');
                overwriteCheckbox.type = 'checkbox';
                overwriteCheckbox.id = overwriteCheckboxId;
                overwriteCheckbox.style.marginLeft = '0.6rem';
                overwriteCheckbox.style.cursor = 'pointer';

                const removeCheckbox = document.createElement('input');
                removeCheckbox.type = 'checkbox';
                removeCheckbox.id = removeCheckboxId;
                removeCheckbox.style.marginLeft = '0.6rem';
                removeCheckbox.style.cursor = 'pointer';

                const overwriteLabel = document.createElement('label');
                overwriteLabel.htmlFor = overwriteCheckboxId;
                overwriteLabel.innerHTML = '<i class="fas fa-edit" style="font-size: 14px;"></i>';
                overwriteLabel.style.marginLeft = '0.15rem';
                overwriteLabel.style.cursor = 'pointer';

                const removeLabel = document.createElement('label');
                removeLabel.htmlFor = removeCheckboxId;
                removeLabel.innerHTML = '<i class="fas fa-trash" style="font-size: 14px;"></i>';
                removeLabel.style.marginLeft = '0.15rem';
                removeLabel.style.cursor = 'pointer';

                const warningText = document.createElement('div');
                warningText.textContent = 'Warnung';
                warningText.style.color = 'red';
                warningText.style.marginLeft = '0.6rem';
                warningText.style.fontWeight = 'bold';
                warningText.style.display = 'none';
                warningText.style.fontSize = '10px';

                function toggleCheckbox(checkedBox, otherBox) {
                    if (checkedBox.checked) {
                        otherBox.checked = false;
                    }
                    updateWarningText();
                }

                function updateWarningText() {
                    if (overwriteCheckbox.checked) {
                        warningText.textContent = 'Data will be replaced';
                        warningText.style.display = 'block';
                    } else if (removeCheckbox.checked) {
                        warningText.textContent = 'Data will be removed';
                        warningText.style.display = 'block';
                    } else {
                        warningText.style.display = 'none';
                    }
                }

                overwriteCheckbox.addEventListener('change', () => toggleCheckbox(overwriteCheckbox, removeCheckbox));
                removeCheckbox.addEventListener('change', () => toggleCheckbox(removeCheckbox, overwriteCheckbox));

                overwriteContainer.appendChild(warningText);
                overwriteContainer.appendChild(overwriteCheckbox);
                overwriteContainer.appendChild(overwriteLabel);
                overwriteContainer.appendChild(removeCheckbox);
                overwriteContainer.appendChild(removeLabel);
                parentLabel.appendChild(overwriteContainer);
            }

            function createContainer(inputFunctions) {
                const container = document.createElement('div');
                container.style.display = 'flex';
                container.style.justifyContent = 'space-between';
                inputFunctions.forEach((inputFunction) => {
                    const element = inputFunction();
                    const inputContainer = element.inputContainer ? element.inputContainer : element;
                    container.appendChild(inputContainer);
                    if (element.tagsList) {
                        const inputElement = inputContainer.querySelector('input[type="text"]');
                        if (inputElement) {
                            inputElement.addEventListener('focus', () => { activeTagsList = element.tagsList; });
                        }
                    }
                });
                return container;
            }

            function createRelationships() {
                const relationshipContainer = document.createElement('div');
                relationshipContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const relationshipLabel = document.createElement('div');
                relationshipLabel.className = 'text_label';
                relationshipLabel.style.display = 'flex';
                relationshipLabel.style.alignItems = 'center';
                relationshipLabel.style.justifyContent = 'space-between';
                relationshipLabel.textContent = 'Song Relationship';
                relationshipLabel.style.marginBottom = '0.5rem';

                relationshipContainer.appendChild(relationshipLabel);

                const relationshipInputContainer = document.createElement('div');
                relationshipInputContainer.className = 'u-bottom_margin';
                relationshipInputContainer.style.display = 'flex';
                relationshipInputContainer.style.justifyContent = 'space-between';

                const relationshipSelect = document.createElement('select');
                relationshipSelect.className = 'select_input';
                relationshipSelect.innerHTML = '<option value="" disabled selected>Song Relationship</option>';
                relationshipSelect.id = 'relationshipSelect';

                const relationships = ['Samples', 'Interpolates', 'Cover Of', 'Remix Of', 'Live Version Of', 'Translation Of'];
                relationships.forEach(relationship => {
                    const option = document.createElement('option');
                    option.value = relationship;
                    option.textContent = relationship;
                    relationshipSelect.appendChild(option);
                });

                const relationshipDiv = document.createElement('div');
                relationshipDiv.className = 'square_select_group-single';
                relationshipDiv.style.width = '100%';
                relationshipDiv.appendChild(relationshipSelect);
                relationshipInputContainer.appendChild(relationshipDiv);

                const relationshipSeparator = document.createElement('span');
                relationshipSeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                relationshipSeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                relationshipSeparator.style.marginLeft = '.35rem';
                relationshipSeparator.style.alignContent = 'center';
                relationshipSeparator.addEventListener('click', () => {
                    relationshipSelect.value = '';
                });

                relationshipInputContainer.appendChild(relationshipSeparator);
                relationshipContainer.appendChild(relationshipInputContainer);
                return relationshipContainer;
            }

            function createLanguage() {
                const languageContainer = document.createElement('div');
                languageContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const languageLabel = document.createElement('div');
                languageLabel.className = 'text_label';
                languageLabel.style.display = 'flex';
                languageLabel.style.alignItems = 'center';
                languageLabel.style.justifyContent = 'space-between';
                languageLabel.textContent = 'Language';
                languageLabel.style.marginBottom = '0.5rem';

                languageContainer.appendChild(languageLabel);

                const languageInputContainer = document.createElement('div');
                languageInputContainer.className = 'u-bottom_margin';
                languageInputContainer.style.display = 'flex';
                languageInputContainer.style.justifyContent = 'space-between';

                const languageSelect = document.createElement('select');
                languageSelect.className = 'select_input';
                languageSelect.innerHTML = '<option value="" disabled selected>Language</option>';
                languageSelect.id = 'languageSelect';

                const languages = [
                    'bosanski',
                    'crnogorski',
                    'Deutsch',
                    'Österreichisches Deutsch',
                    'English',
                    'Español',
                    'Français',
                    'Schweizerdeutsch',
                    'hrvatski',
                    'Italiano',
                    'Kölsch',
                    'Македонски',
                    'Nederlands',
                    'Norsk',
                    'Polski',
                    'Português',
                    'Русский (Russian)',
                    'srpski',
                    'Svenska',
                    'Türkçe',
                    'o‘zbekcha',
                    'Tiếng Việt',
                    '简体中文 (Simplified Chinese)',
                    '繁體中文 (Traditional Chinese)'
                ];

                languages.forEach(language => {
                    const option = document.createElement('option');
                    option.value = language;
                    option.textContent = language;
                    languageSelect.appendChild(option);
                });

                const languageDiv = document.createElement('div');
                languageDiv.className = 'square_select_group-single';
                languageDiv.style.width = '100%';
                languageDiv.appendChild(languageSelect);
                languageInputContainer.appendChild(languageDiv);

                const languageSeparator = document.createElement('span');
                languageSeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                languageSeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                languageSeparator.style.marginLeft = '.35rem';
                languageSeparator.style.alignContent = 'center';
                languageSeparator.addEventListener('click', () => {
                    languageSelect.value = '';
                });

                languageInputContainer.appendChild(languageSeparator);
                languageContainer.appendChild(languageInputContainer);
                return languageContainer;
            }

            function createInputPrimaryTag() {
                const primaryTagContainer = document.createElement('div');
                primaryTagContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const primaryTagLabel = document.createElement('div');
                primaryTagLabel.className = 'text_label';
                primaryTagLabel.style.display = 'flex';
                primaryTagLabel.style.alignItems = 'center';
                primaryTagLabel.style.justifyContent = 'space-between';
                primaryTagLabel.textContent = 'Primary Tag';
                primaryTagLabel.style.marginBottom = '0.5rem';

                createOverwriteContainer('overwrite_primary_tag', 'remove_primary_tag', primaryTagLabel);

                primaryTagContainer.appendChild(primaryTagLabel);

                const genreInputContainer = document.createElement('div');
                genreInputContainer.className = 'u-bottom_margin';
                genreInputContainer.style.display = 'flex';
                genreInputContainer.style.justifyContent = 'space-between';

                const genreSelect = document.createElement('select');
                genreSelect.className = 'select_input';
                genreSelect.innerHTML = '<option value="" disabled selected>Primary Tag</option>';
                genreSelect.id = 'genreSelect';

                const genres = ['Rap', 'Pop', 'R&B', 'Rock', 'Country', 'Electronic', 'Non-Music'];
                genres.forEach(genre => {
                    const option = document.createElement('option');
                    option.value = genre;
                    option.textContent = genre;
                    genreSelect.appendChild(option);
                });

                const genreDiv = document.createElement('div');
                genreDiv.className = 'square_select_group-single';
                genreDiv.style.width = '100%';
                genreDiv.appendChild(genreSelect);
                genreInputContainer.appendChild(genreDiv);

                const genreSeparator = document.createElement('span');
                genreSeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                genreSeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                genreSeparator.style.marginLeft = '.35rem';
                genreSeparator.style.alignContent = 'center';
                genreSeparator.addEventListener('click', () => {
                    genreSelect.value = '';
                });

                genreInputContainer.appendChild(genreSeparator);
                primaryTagContainer.appendChild(genreInputContainer);

                return primaryTagContainer;
            }

            function createInputReleaseDate() {
                const releaseDateContainer = document.createElement('div');
                releaseDateContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const releaseDateLabel = document.createElement('div');
                releaseDateLabel.className = 'text_label';
                releaseDateLabel.style.display = 'flex';
                releaseDateLabel.style.alignItems = 'center';
                releaseDateLabel.style.justifyContent = 'space-between';
                releaseDateLabel.textContent = 'Release Date';
                releaseDateLabel.style.marginBottom = '0.5rem';

                createOverwriteContainer('overwrite_release_date', 'remove_release_date', releaseDateLabel);

                releaseDateContainer.appendChild(releaseDateLabel);

                const dateInputContainer = document.createElement('div');
                dateInputContainer.className = 'u-bottom_margin';
                dateInputContainer.style.display = 'flex';
                dateInputContainer.style.justifyContent = 'space-between';

                const monthSelect = document.createElement('select');
                monthSelect.className = 'select_input';
                monthSelect.innerHTML = '<option value="" disabled selected>Month</option>';
                monthSelect.id = 'monthSelect';

                const months = [
                    { number: 1, name: 'January' },
                    { number: 2, name: 'February' },
                    { number: 3, name: 'March' },
                    { number: 4, name: 'April' },
                    { number: 5, name: 'May' },
                    { number: 6, name: 'June' },
                    { number: 7, name: 'July' },
                    { number: 8, name: 'August' },
                    { number: 9, name: 'September' },
                    { number: 10, name: 'October' },
                    { number: 11, name: 'November' },
                    { number: 12, name: 'December' },
                ];

                months.forEach(month => {
                    const option = document.createElement('option');
                    option.value = month.number;
                    option.textContent = month.name;
                    monthSelect.appendChild(option);
                });

                const monthDiv = document.createElement('div');
                monthDiv.className = 'square_select_group-single';
                monthDiv.appendChild(monthSelect);
                dateInputContainer.appendChild(monthDiv);

                const monthSeparator = document.createElement('span');
                monthSeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                monthSeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                monthSeparator.style.marginLeft = '.35rem';
                monthSeparator.style.marginRight = '.95rem';
                monthSeparator.style.alignContent = 'center';
                monthSeparator.addEventListener('click', () => {
                    monthSelect.value = '';
                });
                dateInputContainer.appendChild(monthSeparator);


                const daySelect = document.createElement('select');
                daySelect.className = 'select_input';
                daySelect.innerHTML = '<option value="" disabled selected>Day</option>';
                daySelect.id = 'daySelect';

                const dayDiv = document.createElement('div');
                dayDiv.className = 'square_select_group-single';
                dayDiv.appendChild(daySelect);
                dateInputContainer.appendChild(dayDiv);

                const daySeparator = document.createElement('span');
                daySeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                daySeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                daySeparator.style.marginLeft = '.35rem';
                daySeparator.style.marginRight = '.95rem';
                daySeparator.style.alignContent = 'center';
                daySeparator.addEventListener('click', () => {
                    daySelect.value = '';
                });
                dateInputContainer.appendChild(daySeparator);


                const yearSelect = document.createElement('select');
                yearSelect.className = 'select_input';
                yearSelect.innerHTML = '<option value="" disabled selected>Year</option>';
                yearSelect.id = 'yearSelect';

                const currentYear = new Date().getFullYear();
                for (let year = currentYear + 1; year >= 1900; year--) {
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    yearSelect.appendChild(option);
                }

                const yearDiv = document.createElement('div');
                yearDiv.className = 'square_select_group-single';
                yearDiv.appendChild(yearSelect);
                dateInputContainer.appendChild(yearDiv);

                const yearSeparator = document.createElement('span');
                yearSeparator.className = 'square_select_group-separator u-clickable u-quarter_left_margin';
                yearSeparator.style.marginLeft = '.35rem';
                yearSeparator.style.alignContent = 'center';
                yearSeparator.innerHTML = '<svg src="x.svg" class="inline_icon inline_icon--gray" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>';
                yearSeparator.addEventListener('click', () => {
                    daySelect.value = '';
                });
                dateInputContainer.appendChild(yearSeparator);

                const updateDays = () => {
                    const selectedMonth = parseInt(monthSelect.value, 10);
                    const currentDay = parseInt(daySelect.value, 10);
                    const selectedYear = parseInt(yearSelect.value, 10);
                    const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

                    const isLeapYear = (year) => {
                        return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
                    };
                    if (selectedMonth === 2 && isLeapYear(selectedYear)) {
                        daysInMonth[1] = 29;
                    }

                    const maxDays = selectedMonth ? daysInMonth[selectedMonth - 1] : 31;

                    daySelect.innerHTML = '<option value="" disabled selected>Day</option>';
                    for (let day = 1; day <= maxDays; day++) {
                        const option = document.createElement('option');
                        option.value = day;
                        option.textContent = day;

                        if (day === currentDay) {
                            option.selected = true;
                        }

                        daySelect.appendChild(option);
                    }

                    if (currentDay > maxDays) {
                        daySelect.value = '';
                    }
                };

                monthSelect.addEventListener('change', updateDays);
                daySelect.addEventListener('change', updateDays);
                yearSelect.addEventListener('change', updateDays);
                updateDays();

                releaseDateContainer.appendChild(dateInputContainer);
                return releaseDateContainer;
            }

            function createInputColorFields() {
                const inputContainer = document.createElement('div');
                inputContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const gradientContainer = document.createElement('div');
                gradientContainer.style.display = 'flex';
                gradientContainer.style.gap = '0.75rem';

                const label = document.createElement('div');
                label.className = 'text_label';
                label.textContent = 'Gradient Colors';
                label.style.display = 'flex';
                label.style.alignItems = 'center';
                label.style.justifyContent = 'space-between';

                const primaryColorField = createInputTextField('', 'primary_color', 'Primary Color');
                const secondaryColorField = createInputTextField('', 'secondary_color', 'Secondary Color');
                const textColorField = createInputTextField('', 'text_color', 'Text Color');

                createOverwriteContainer('overwrite_gradient', 'remove_gradient', label);

                gradientContainer.appendChild(primaryColorField);
                gradientContainer.appendChild(secondaryColorField);
                gradientContainer.appendChild(textColorField);
                inputContainer.appendChild(label);
                inputContainer.appendChild(gradientContainer);

                return inputContainer;
            }

            function createInputTextField(labelText, name, placeholder) {
                const inputContainer = document.createElement('div');
                inputContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';

                const label = document.createElement('div');
                label.className = 'text_label';
                label.textContent = labelText;
                label.style.display = 'flex';
                label.style.alignItems = 'center';
                label.style.justifyContent = 'space-between';

                const input = document.createElement('input');
                input.type = 'text';
                input.name = name;
                input.placeholder = placeholder;
                input.className = 'square_input square_form-standard_element_margin';
                input.setAttribute("autocomplete", "off");

                const feedbackLabel = document.createElement('div');
                feedbackLabel.className = 'feedback_label';
                feedbackLabel.style.paddingLeft = '5.905px';
                feedbackLabel.style.marginBottom = '6px';
                feedbackLabel.style.fontSize = '12px';
                feedbackLabel.style.color = '#333';
                feedbackLabel.style.display = 'none';

                let cachedPlaylistLink = null;
                let cachedSongIds = null;
                let cachedAlbumTitle = null;

                input.addEventListener('input', async () => {
                    const link = input.value.trim();
                    const [playlistLink, playlistTracks] = link.split(' ');
                    feedbackLabel.style.display = 'block';
                    input.style.marginBottom = '6px';

                    const checkedSongIds = songIds.filter((songId) => {
                        const checkbox = document.querySelector(`#checkbox_${songId}`);
                        return checkbox?.checked;
                    });

                    if (name === 'youtube_links') {
                        try {
                            if (playlistLink === "Delete") {
                                youtubeLinks = "Delete";
                                feedbackLabel.style.color = '#FF1414';
                                feedbackLabel.textContent = 'Warning: Delete all YouTube links';
                            } else {
                                const playlistData = await getPlaylistVideos(playlistLink);
                                if (typeof playlistData === 'string') {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = `Error: ${playlistData}`;
                                } else {
                                    const totalTracks = playlistData.videoLinks.length;
                                    const selectedTracks = playlistTracks ? parsePlaylistTracks(playlistTracks, totalTracks) : [...Array(totalTracks).keys()];
                                    const filteredLinks = selectedTracks.map(index => playlistData.videoLinks[index]);

                                    const playlistLength = filteredLinks.length;
                                    const songCount = checkedSongIds.length;
                                    const trackLabel = playlistData.playlistLength === 1 ? "Track" : "Tracks";
                                    const linkLabel = playlistData.playlistLength === 1 ? "link" : "links";
                                    const songLabel = songCount === 1 ? "song" : "songs";

                                    /*if (playlistLength === songCount) {
                                        feedbackLabel.style.color = '#007A33';
                                        feedbackLabel.innerHTML = `
                                                <strong>Playlist:</strong> ${playlistData.playlistTitle} [${playlistLength} Tracks]
                                            `;
                                        youtubeLinks = filteredLinks;
                                    } else {
                                        feedbackLabel.style.color = '#FF1414';
                                        feedbackLabel.innerHTML = `
                                            <strong>Playlist:</strong> ${playlistData.playlistTitle} [${playlistLength} ${trackLabel}]<br>
                                            <strong><span style="background-color: #FFEB3B; color: #333; padding: 2px 0px;">Warning:</span></strong>
                                            <span style="color: #333;">The playlist has ${playlistLength} ${linkLabel}, but the album  has ${songCount} ${songLabel}.</span>
                                        `;
                                    }*/
                                    if (playlistLength === songCount) {
                                        feedbackLabel.style.color = '#007A33';
                                        feedbackLabel.textContent = "";

                                        const strong = document.createElement("strong");
                                        strong.textContent = "Playlist:";

                                        const text = document.createTextNode(` ${playlistData.playlistTitle} [${playlistLength} Tracks]`);

                                        feedbackLabel.appendChild(strong);
                                        feedbackLabel.appendChild(text);

                                        youtubeLinks = filteredLinks;

                                    } else {
                                        feedbackLabel.style.color = '#FF1414';
                                        feedbackLabel.textContent = "";

                                        const strong1 = document.createElement("strong");
                                        strong1.textContent = "Playlist:";
                                        feedbackLabel.appendChild(strong1);

                                        const text1 = document.createTextNode(` ${playlistData.playlistTitle} [${playlistLength} ${trackLabel}]`);
                                        feedbackLabel.appendChild(text1);
                                        feedbackLabel.appendChild(document.createElement("br"));

                                        const strong2 = document.createElement("strong");
                                        const warnSpan = document.createElement("span");
                                        warnSpan.style.backgroundColor = "#FFEB3B";
                                        warnSpan.style.color = "#333";
                                        warnSpan.style.padding = "2px 0px";
                                        warnSpan.textContent = "Warning:";
                                        strong2.appendChild(warnSpan);
                                        feedbackLabel.appendChild(strong2);

                                        const warnText = document.createElement("span");
                                        warnText.style.color = "#333";
                                        warnText.textContent = ` The playlist has ${playlistLength} ${linkLabel}, but the album has ${songCount} ${songLabel}.`;
                                        feedbackLabel.appendChild(warnText);
                                    }
                                }
                            }
                        } catch (error) {
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = `Error: ${error.message}`;
                        }
                    } else if (name === 'soundcloud_links') {
                        feedbackLabel.style.color = '#FF1414';
                        feedbackLabel.textContent = "Error: SoundCloud links are not supported";
                    } else if (name === 'related_album') {
                        try {
                            if (playlistLink === "Delete") {
                                geniusLinks = Array(checkedSongIds.length).fill("Delete");
                                feedbackLabel.style.color = '#FF1414';
                                feedbackLabel.textContent = 'Warning: Delete all related songs';
                            } else {
                                if (!playlistLink.startsWith("https://genius.com/albums")) {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = "Error: Invalid playlist link";
                                    return;
                                }
                                if (playlistLink !== cachedPlaylistLink || !cachedSongIds) {
                                    const html = await (await fetch(playlistLink)).text();
                                    const songIdRegex = /&quot;api_path&quot;:&quot;\/songs\/(\d+)&quot;/g;
                                    const albumTitleRegex = /&quot;link_title&quot;:&quot;(.*?)&quot;,&quot;title&quot;:&quot;(.*?)&quot;,&quot;type&quot;:&quot;Album&quot;/;
                                    cachedAlbumTitle = (html.match(albumTitleRegex) || [])[1];
                                    let match;
                                    cachedSongIds = [];
                                    while ((match = songIdRegex.exec(html)) !== null) {
                                        cachedSongIds.push(match[1]);
                                    }
                                    cachedPlaylistLink = playlistLink;
                                }
                                const totalTracks = cachedSongIds.length;
                                const selectedTracks = playlistTracks ? parsePlaylistTracks(playlistTracks, totalTracks) : [...Array(totalTracks).keys()];
                                const filteredSongIds = selectedTracks.map(index => cachedSongIds[index]);

                                const playlistLength = filteredSongIds.length;
                                const songCount = checkedSongIds.length;

                                const trackLabel = playlistLength === 1 ? "Track" : "Tracks";
                                const linkLabel = playlistLength === 1 ? "link" : "links";
                                const songLabel = songCount === 1 ? "song" : "songs";

                                /*if (playlistLength === songCount) {
                                    feedbackLabel.style.color = '#007A33';
                                    feedbackLabel.innerHTML = `
                                        <strong>Playlist:</strong> ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]
                                    `;
                                    geniusLinks = filteredSongIds;
                                } else {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.innerHTML = `
                                        <strong>Playlist:</strong> ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]<br>
                                        <strong><span style="background-color: #FFEB3B; color: #333; padding: 2px 0px;">Warning:</span></strong>
                                        <span style="color: #333;">The playlist has ${playlistLength} ${linkLabel}, but the album only has ${songCount} ${songLabel}.</span>
                                    `;
                                }*/
                                if (playlistLength === songCount) {
                                    feedbackLabel.style.color = '#007A33';
                                    feedbackLabel.textContent = "";

                                    const strong = document.createElement("strong");
                                    strong.textContent = "Playlist:";
                                    feedbackLabel.appendChild(strong);

                                    const text = document.createTextNode(` ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]`);
                                    feedbackLabel.appendChild(text);

                                    geniusLinks = filteredSongIds;
                                } else {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = "";

                                    const strong1 = document.createElement("strong");
                                    strong1.textContent = "Playlist:";
                                    feedbackLabel.appendChild(strong1);

                                    const text1 = document.createTextNode(` ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]`);
                                    feedbackLabel.appendChild(text1);

                                    feedbackLabel.appendChild(document.createElement("br"));

                                    const strong2 = document.createElement("strong");
                                    const warnSpan = document.createElement("span");
                                    warnSpan.style.backgroundColor = "#FFEB3B";
                                    warnSpan.style.color = "#333";
                                    warnSpan.style.padding = "2px 0px";
                                    warnSpan.textContent = "Warning:";
                                    strong2.appendChild(warnSpan);
                                    feedbackLabel.appendChild(strong2);

                                    const warnText = document.createElement("span");
                                    warnText.style.color = "#333";
                                    warnText.textContent = ` The playlist has ${playlistLength} ${linkLabel}, but the album only has ${songCount} ${songLabel}.`; feedbackLabel.appendChild(warnText);
                                }
                            }
                        } catch (error) {
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = `Error: ${error.message}`;
                        }
                    } else if (name === 'recorded_at') {
                        if (link === "Delete") {
                            recordedArray = "Delete";
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = 'Warning: Delete all Recording Locations';
                        } else {
                            recordedArray = link;
                            feedbackLabel.textContent = '';
                            feedbackLabel.style.display = 'none';
                        }
                    } else if (name === 'primary_color') {
                        color = link.trim().toLowerCase();
                        if (!color.startsWith("#")) color = `#${color}`;
                        primaryColorArray = color;
                        checkGradient();
                    } else if (name === 'secondary_color') {
                        color = link.trim().toLowerCase();
                        if (!color.startsWith("#")) color = `#${color}`;
                        secondaryColorArray = color;
                        checkGradient();
                    } else if (name === 'text_color') {
                        color = link.trim().toLowerCase();
                        if (!color.startsWith("#")) color = `#${color}`;
                        textColorArray = color;
                        checkGradient();
                    }
                });

                const checkGradient = () => {
                    if (primaryColorArray && secondaryColorArray && textColorArray) {
                        const hexToRgb = (color) => {
                            let colorVal = color;
                            if (color.length === 4) {
                                colorVal = `#${color[1]}${color[1]}${color[2]}${color[2]}${color[3]}${color[3]}`;
                            }

                            const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(colorVal);
                            return m ? [m[1], m[2], m[3]].map(s => parseInt(s, 16)) : null;
                        };

                        const luminance = (rgbArray) => {
                            const a = rgbArray.map((v) => {
                                v /= 255;
                                return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
                            });
                            return (a[0] * 0.2126) + (a[1] * 0.7152) + (a[2] * 0.0722);
                        };

                        const calculateContrast = (color1, color2) => {
                            if (color1.length == 0 || color2.length == 0) return 1;

                            const isBlackOrWhite = ["#000000", "#000", "#ffffff", "#fff"].includes(color2.toLowerCase());
                            if (!isBlackOrWhite) return 1;

                            const color1RGB = hexToRgb(color1);
                            const color2RGB = hexToRgb(color2);
                            if (!color1RGB || !color2RGB) return 1;

                            const color1Luminance = luminance(color1RGB);
                            const color2Luminance = luminance(color2RGB);
                            return color1Luminance > color2Luminance
                                ? Math.round((color1Luminance + 0.05) / (color2Luminance + 0.05) * 100) / 100
                                : Math.round((color2Luminance + 0.05) / (color1Luminance + 0.05) * 100) / 100;
                        };

                        const isAcceptableContrast = contrast => contrast >= 4.5;

                        const contrastPrimaryText = calculateContrast(primaryColorArray, textColorArray);
                        const contrastSecondaryText = calculateContrast(secondaryColorArray, textColorArray);
                        const isAcceptable = isAcceptableContrast(contrastPrimaryText) && isAcceptableContrast(contrastSecondaryText);

                        gradientCheckArray = isAcceptable;

                        document.querySelector("input[name='primary_color']").nextElementSibling.textContent = `Contrast: ${contrastPrimaryText}`;
                        document.querySelector("input[name='secondary_color']").nextElementSibling.textContent = `Contrast: ${contrastSecondaryText}`;
                        document.querySelector("input[name='text_color']").nextElementSibling.textContent = `Check: ${isAcceptable ? 'True' : 'False'}`;
                        document.querySelector("input[name='primary_color']").nextElementSibling.style.color = contrastPrimaryText > 4.5 ? '#007A33' : '#FF1414';
                        document.querySelector("input[name='secondary_color']").nextElementSibling.style.color = contrastSecondaryText > 4.5 ? '#007A33' : '#FF1414';
                        document.querySelector("input[name='text_color']").nextElementSibling.style.color = isAcceptable ? '#007A33' : '#FF1414';

                        return isAcceptable;
                    }

                    gradientCheckArray = false;

                    return false;
                };


                function parsePlaylistTracks(input, totalTracks) {
                    const selectedTracks = new Set();
                    let isInverted = false;

                    if (input.startsWith('!')) {
                        isInverted = true;
                        input = input.slice(1);
                    }

                    input.split(',').forEach(range => {
                        const [start, end] = range.split('-').map(Number);
                        if (!end) {
                            selectedTracks.add(start - 1);
                        } else {
                            for (let i = start - 1; i < end; i++) {
                                selectedTracks.add(i);
                            }
                        }
                    });

                    if (isInverted) {
                        return [...Array(totalTracks).keys()].filter(i => !selectedTracks.has(i));
                    } else {
                        return [...selectedTracks].sort((a, b) => a - b);
                    }
                }

                async function getPlaylistVideos(playlistLink) {
                    const possibleLinks = ["https://www.youtube.com/playlist", "https://youtube.com/playlist", "https://music.youtube.com/playlist"];
                    if (!possibleLinks.some((link) => playlistLink.startsWith(link))) {
                        return "Invalid playlist link";
                    }

                    const playlistId = new URL(playlistLink).searchParams.get("list");
                    const key = window.secrets.GOOGLE_API_KEY;

                    const metadataResponse = await fetch(`https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=${playlistId}&key=${key}`);
                    if (!metadataResponse.ok) {
                        return "Failed to fetch playlist metadata";
                    }

                    const metadataData = (await metadataResponse.json()).items[0].snippet;
                    console.log(metadataData);

                    let videosData;
                    let videoLinks = [];
                    let nextPageToken = '';

                    do {
                        const videosResponse = await fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&pageToken=${nextPageToken}&playlistId=${playlistId}&key=${key}`);
                        if (!videosResponse.ok) {
                            return "Failed to fetch playlist videos";
                        }

                        videosData = await videosResponse.json();
                        console.log(videosData);
                        videoLinks.push(...videosData.items.map(item => `https://www.youtube.com/watch?v=${item.snippet.resourceId.videoId}`));
                        nextPageToken = videosData.nextPageToken;
                    } while (nextPageToken);


                    return {
                        artistName: metadataData.channelTitle,
                        playlistTitle: metadataData.title.startsWith("Album - ")
                            ? metadataData.title.substring("Album - ".length)
                            : metadataData.title,
                        playlistLength: videoLinks.length,
                        videoLinks
                    };
                }

                if (name === 'youtube_links' || name === 'soundcloud_links' || name === 'related_album' || name === 'recorded_at') {
                    createOverwriteContainer(`overwrite_${name}`, `remove_${name}`, label);
                }

                inputContainer.appendChild(label);
                inputContainer.appendChild(input);
                inputContainer.appendChild(feedbackLabel);
                return inputContainer;
            }

            function createInputTagField(labelText, name, type) {
                const inputContainer = document.createElement('div');
                inputContainer.className = 'square_form-input_and_label square_form-input_and_label--half_width';
                inputContainer.setAttribute('ng-class', "{'square_form-input_and_label--half_width': !full, 'square_form-input_and_label--error': errors.length}");
                inputContainer.setAttribute('label', 'Artists');
                inputContainer.setAttribute('errors', "$ctrl.error.response.validation_errors.primary_artists");
                inputContainer.setAttribute('bis_skin_checked', '1');

                const label = document.createElement('div');
                label.className = 'text_label';
                label.setAttribute('ng-class', "{'text_label--gray': is_disabled}");
                label.setAttribute('bis_skin_checked', '1');
                label.textContent = labelText;

                label.style.display = 'flex';
                label.style.alignItems = 'center';
                label.style.justifyContent = 'space-between';

                if (name === 'primary_artists' || name === 'featured_artists' || name === 'tags' || name === 'writers' || name === 'producers' || name === `additional_role_${roleIndex}`) {
                    createOverwriteContainer(`overwrite_${name}`, `remove_${name}`, label);
                }

                const ngTransclude = document.createElement('ng-transclude');

                const autocompleteTagsInput = document.createElement('autocomplete-tags-input');
                autocompleteTagsInput.setAttribute('bind-to', '$ctrl.album.primary_artists');
                autocompleteTagsInput.setAttribute('name', 'artist');
                autocompleteTagsInput.setAttribute('autocomplete-model', 'artist');
                autocompleteTagsInput.setAttribute('placeholder', 'Artists');
                autocompleteTagsInput.setAttribute('input-classes', 'tags_input square_input square_form-standard_element_margin');

                const tagsInput = document.createElement('tags-input');
                tagsInput.setAttribute('ng-disabled', 'disabled');
                tagsInput.setAttribute('min-length', '1');
                tagsInput.setAttribute('template', 'autocomplete_word.html');
                tagsInput.setAttribute('key-property', 'name');
                tagsInput.setAttribute('display-property', 'name');
                tagsInput.setAttribute('replace-spaces-with-dashes', 'false');
                tagsInput.setAttribute('ng-model', 'bindTo');
                tagsInput.setAttribute('placeholder', '');
                tagsInput.className = 'tags_input square_input square_form-standard_element_margin ng-valid-max-tags ng-valid-min-tags ng-valid-leftover-text ng-touched';
                tagsInput.setAttribute('add-from-autocomplete-only', 'true');
                tagsInput.setAttribute('prevent-default-keydown', '13');

                const hostDiv = document.createElement('div');
                hostDiv.className = 'host';
                hostDiv.setAttribute('tabindex', '-1');
                hostDiv.setAttribute('ng-click', 'eventHandlers.host.click()');

                const tagsDiv = document.createElement('div');
                tagsDiv.className = 'tags';
                tagsDiv.setAttribute('ng-class', '{focused: hasFocus}');

                const tagsList = document.createElement('ul');
                tagsList.className = 'tag-list';

                const inputField = document.createElement('input');
                inputField.type = 'text';
                inputField.placeholder = `Add ${labelText}`;
                inputField.className = 'input ng-pristine ng-valid ng-empty ng-touched';
                inputField.setAttribute('autocomplete', 'off');
                inputField.setAttribute('ng-model', 'newTag.text');
                inputField.setAttribute('ng-model-options', '{getterSetter: true}');
                inputField.setAttribute('ng-keydown', 'eventHandlers.input.keydown($event)');
                inputField.setAttribute('ng-focus', 'eventHandlers.input.focus($event)');
                inputField.setAttribute('ng-blur', 'eventHandlers.input.blur($event)');
                inputField.setAttribute('ng-paste', 'eventHandlers.input.paste($event)');
                inputField.setAttribute('ng-trim', 'false');
                inputField.setAttribute('ng-class', "{'invalid-tag': newTag.invalid}");
                inputField.setAttribute('ng-disabled', 'disabled');
                inputField.setAttribute('ti-bind-attrs', "{type: 'text', placeholder: 'Add a tag', tabindex: options.tabindex, spellcheck: true}");
                inputField.setAttribute('ti-autosize', '');
                inputField.style.width = '100%';

                inputField.addEventListener('input', async (event) => {
                    const query = event.target.value;

                    if (type === 'custom_performance_roles') {
                        if (tagsList.querySelectorAll('.tag-item').length > 0) {
                            console.warn('Only one tag can be added for additionalArtistRoles.');
                            return;
                        }
                    }

                    const existingSuggestions = hostDiv.querySelector('.autocomplete');
                    if (existingSuggestions) {
                        existingSuggestions.remove();
                    }

                    if (query.length > 1) {
                        const suggestions = await fetchSuggestions(type, query);
                        displaySuggestions(suggestions, hostDiv, inputField, name, type, form);
                    }
                });

                inputField.addEventListener('keydown', (event) => {
                    if (event.key === 'Backspace' && inputField.value === '') {
                        const lastTag = tagsList.querySelector('.tag-item:last-child');
                        if (lastTag) {
                            lastTag.querySelector('svg').click();
                        }
                    }
                });

                tagsDiv.appendChild(tagsList);
                hostDiv.appendChild(tagsDiv);
                tagsDiv.appendChild(inputField);
                tagsInput.appendChild(hostDiv);
                autocompleteTagsInput.appendChild(tagsInput);
                autocompleteTagsInput.appendChild(tagsInput);
                ngTransclude.appendChild(autocompleteTagsInput);
                inputContainer.appendChild(label);
                inputContainer.appendChild(ngTransclude);
                return { inputContainer, tagsList };
            }

            function createAdditionalRoles() {
                const subSection = document.createElement('div');
                subSection.className = 'square_form-sub_section';
                subSection.setAttribute('data-index', roleIndex);

                const { inputContainer: additionalRoleDiv, tagsList: additionalRoleTagsList } = createInputTagField(
                    'Additional role',
                    `additional_role_${roleIndex}`,
                    'custom_performance_roles'
                );
                additionalRoleDiv.setAttribute('data-index', roleIndex);
                subSection.appendChild(additionalRoleDiv);


                const additionalRoleInputField = [...additionalRoleDiv.querySelectorAll('input')].pop();
                additionalRoleInputField.addEventListener('focus', () => {
                    activeTagsList = additionalRoleTagsList;
                });


                const { inputContainer: artistRoleDiv, tagsList: artistRoleTagsList } = createInputTagField(
                    'Artists in this role',
                    `artist_role_${roleIndex}`,
                    'artists'
                );
                artistRoleDiv.setAttribute('data-index', roleIndex);
                subSection.appendChild(artistRoleDiv);

                const artistRoleInputField = artistRoleDiv.querySelector('input');
                artistRoleInputField.addEventListener('focus', () => {
                    activeTagsList = artistRoleTagsList;
                });

                const removeButton = document.createElement('div');
                removeButton.className = 'square_form-sub_section-remove';
                removeButton.innerHTML = `
                        <svg class="inline_icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22">
                        <path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>
                    `;
                removeButton.style.cursor = 'pointer';
                removeButton.addEventListener('click', () => {
                    subSection.remove();
                });
                subSection.appendChild(removeButton);

                roleIndex++;
                return subSection;
            }

            function createAdditionalCredits() {
                const additionalContainer = document.createElement('div');
                additionalContainer.style.flexDirection = 'column';

                const creditsLabel = document.createElement('div');
                creditsLabel.className = 'text_label';
                creditsLabel.textContent = 'Credits';
                creditsLabel.style.display = 'flex';
                creditsLabel.style.alignItems = 'center';
                creditsLabel.style.justifyContent = 'space-between';
                //createOverwriteContainer('overwrite_credits', 'remove_credits', creditsLabel);


                additionalContainer.appendChild(creditsLabel);

                const subSectionCreditsContainer = document.createElement('div');
                additionalContainer.appendChild(subSectionCreditsContainer);

                const initialSubSectionCredits = createAdditionalRoles();
                subSectionCreditsContainer.appendChild(initialSubSectionCredits);

                const addCreditsButton = document.createElement('span');
                addCreditsButton.className = 'text_label text_label--button text_label--purple';
                addCreditsButton.textContent = '+ Add Additional Credits';
                addCreditsButton.style.cursor = 'pointer';
                addCreditsButton.addEventListener('click', () => {
                    const newSubSectionCredits = createAdditionalRoles();
                    subSectionCreditsContainer.appendChild(newSubSectionCredits);

                    form.style.paddingBottom = '175px';
                    form.scrollTo({
                        top: form.scrollHeight,
                        behavior: 'smooth'
                    });
                });

                additionalContainer.appendChild(addCreditsButton);

                const formHeight = form.getBoundingClientRect().height;
                if (formHeight < 1125) {
                    let requiredPadding = 1125 - formHeight;
                    requiredPadding = Math.min(requiredPadding, 175);
                    form.style.paddingBottom = `${requiredPadding}px`;
                }

                return additionalContainer;
            }

            function createStatusSaveCancelButton() {
                const statusDisplay = document.createElement('div');
                statusDisplay.style.marginBottom = '1.75rem';
                statusDisplay.style.fontSize = '1rem';
                const saveButton = document.createElement('button');
                saveButton.id = 'custom-save-button';
                saveButton.className = 'square_button square_button--green';
                saveButton.type = 'submit';
                saveButton.textContent = 'Save';
                saveButton.style.display = 'none';
                const cancelButton = document.createElement('button');
                cancelButton.className = 'square_button square_button--transparent square_button--gray';
                cancelButton.textContent = 'Cancel';

                const { field: autoReopenToggle } = createAutoReopenSwitch({
                    orientation: 'row',
                    caption: 'Auto-Reopen after saving',
                    captionColor: '#000',
                    offColor: '#c9c9c9',
                    ringColor: 'rgba(0, 0, 0, 0.5)'
                });
                autoReopenToggle.style.marginBottom = '1.25rem';

                return { statusDisplay, saveButton, cancelButton, autoReopenToggle };
            }

            function createCloseButton() {
                const closeButtonContainer = document.createElement('div');
                closeButtonContainer.setAttribute('ng-if', '!variants.internal_close');
                closeButtonContainer.className = 'modal_window-close_button';
                closeButtonContainer.setAttribute('ng-click', 'close({close_button: true})');
                closeButtonContainer.innerHTML = `
                    <svg src="x.svg" class="modal_window-close_button-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22">
                    <path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>
                `;
                return closeButtonContainer;
            }

            function displaySuggestions(suggestions, container, inputField, name, type, form) {
                const existingSuggestions = container.querySelector('.autocomplete');
                if (existingSuggestions) {
                    existingSuggestions.remove();
                }

                if (suggestions.length > 0) {
                    const autocompleteDiv = document.createElement('div');
                    autocompleteDiv.className = 'autocomplete';
                    autocompleteDiv.setAttribute('ng-if', "suggestionList.visible");
                    autocompleteDiv.setAttribute('bis_skin_checked', "1");

                    const suggestionList = document.createElement('ul');
                    suggestionList.className = 'suggestion-list';

                    let mouseMoved = false;
                    let selectedIndex = 0;

                    suggestions.forEach((item, index) => {
                        const suggestionItem = document.createElement('li');
                        suggestionItem.className = 'suggestion-item';
                        suggestionItem.setAttribute('ng-repeat', "item in suggestionList.items track by track(item)");
                        suggestionItem.setAttribute('ng-class', "{selected: item == suggestionList.selected}");
                        suggestionItem.setAttribute('ng-click', `addSuggestionByIndex(${index})`);
                        suggestionItem.setAttribute('ng-mouseenter', `suggestionList.select(${index})`);
                        suggestionList.appendChild(suggestionItem);

                        const tiAutocompleteMatch = document.createElement('ti-autocomplete-match');

                        let valueToAdd;
                        if (type === 'tags' || type === 'artists') {
                            tiAutocompleteMatch.setAttribute('data', `::${item.name}`);
                            const ngInclude = document.createElement('ng-include');
                            ngInclude.setAttribute('src', '$$template');

                            const artistNameText = document.createTextNode(item.name);
                            ngInclude.appendChild(artistNameText);

                            tiAutocompleteMatch.appendChild(ngInclude);

                            valueToAdd = { id: item.id, name: item.name };
                        } else if (type === 'custom_performance_roles') {
                            tiAutocompleteMatch.setAttribute('data', `::${item.label}`);
                            const ngInclude = document.createElement('ng-include');
                            ngInclude.setAttribute('src', '$$template');

                            const roleLabelText = document.createTextNode(item.label);
                            ngInclude.appendChild(roleLabelText);

                            tiAutocompleteMatch.appendChild(ngInclude);

                            valueToAdd = { id: item.id, label: item.label };
                        }

                        suggestionItem.appendChild(tiAutocompleteMatch);

                        if (index === 0) {
                            suggestionItem.classList.add('selected');
                        }

                        suggestionItem.addEventListener('click', () => {
                            if (valueToAdd) {
                                if (name === 'tags') {
                                    if (!tagsArray.some(tag => tag.id === valueToAdd.id)) {
                                        tagsArray.push(valueToAdd);
                                    }
                                    console.log('Tags Array:', tagsArray);
                                } else if (name === 'primary_artists') {
                                    if (!primaryArtistsArray.some(primary_artist => primary_artist.id === valueToAdd.id)) {
                                        primaryArtistsArray.push(valueToAdd);
                                    }
                                    console.log('Primary Artists Array:', primaryArtistsArray);
                                } else if (name === 'featured_artists') {
                                    if (!featuredArtistsArray.some(featured_artist => featured_artist.id === valueToAdd.id)) {
                                        featuredArtistsArray.push(valueToAdd);
                                    }
                                    console.log('Featured Artists Array:', featuredArtistsArray);
                                } else if (name === 'producers') {
                                    if (!producersArray.some(producer => producer.id === valueToAdd.id)) {
                                        producersArray.push(valueToAdd);
                                    }
                                    console.log('Producers Array:', producersArray);
                                } else if (name === 'writers') {
                                    if (!writersArray.some(writer => writer.id === valueToAdd.id)) {
                                        writersArray.push(valueToAdd);
                                    }
                                    console.log('Writers Array:', writersArray);
                                } else if (name.startsWith('additional_role_')) {
                                    const match = name.match(/_(\d+)$/);
                                    const fieldIndex = match ? parseInt(match[1], 10) : null;

                                    if (fieldIndex !== null) {
                                        if (!additionalRolesArray[fieldIndex]) {
                                            additionalRolesArray[fieldIndex] = [];
                                        }
                                        if (!additionalRolesArray[fieldIndex].some(role => role.id === valueToAdd.id)) {
                                            additionalRolesArray[fieldIndex].push(valueToAdd);
                                        }
                                    }
                                    console.log(additionalRolesArray);
                                } else if (name.startsWith('artist_role_')) {
                                    const match = name.match(/_(\d+)$/);
                                    const fieldIndex = match ? parseInt(match[1], 10) : null;

                                    if (fieldIndex !== null) {
                                        if (!artistRolesArray[fieldIndex]) {
                                            artistRolesArray[fieldIndex] = [];
                                        }
                                        if (!artistRolesArray[fieldIndex].some(artist => artist.id === valueToAdd.id)) {
                                            artistRolesArray[fieldIndex].push(valueToAdd);
                                        }
                                    }
                                }
                                addTag(activeTagsList, valueToAdd, name);
                                inputField.value = '';
                                inputField.focus();
                                autocompleteDiv.remove();
                            }
                        });


                        suggestionItem.addEventListener('mouseenter', () => {
                            if (mouseMoved) {
                                suggestionList.querySelectorAll('.suggestion-item').forEach(item => item.classList.remove('selected'));
                                suggestionItem.classList.add('selected');
                                selectedIndex = index;
                            }
                        });

                        suggestionItem.addEventListener('mouseleave', () => {
                            suggestionItem.classList.remove('selected');
                        });
                    });

                    document.addEventListener('mousemove', () => {
                        mouseMoved = true;
                    });


                    autocompleteDiv.appendChild(suggestionList);
                    container.appendChild(autocompleteDiv);

                    container.scrollIntoView({ behavior: 'smooth', block: 'center' });


                    let keyboardListener;

                    setupKeyboardNavigation();

                    document.addEventListener('mousedown', (event) => {
                        if (!autocompleteDiv.contains(event.target) && event.target !== inputField) {
                            autocompleteDiv.remove();
                        }
                    })

                    function setupKeyboardNavigation() {
                        if (keyboardListener) {
                            document.removeEventListener('keydown', keyboardListener);
                        }

                        keyboardListener = (event) => {
                            const items = document.querySelectorAll('.suggestion-item');
                            if (!items.length) return;

                            if (event.key === 'ArrowDown') {
                                selectedIndex = (selectedIndex + 1) % items.length;
                                items.forEach(item => item.classList.remove('selected'));
                                items[selectedIndex].classList.add('selected');
                                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                                event.preventDefault();
                            } else if (event.key === 'ArrowUp') {
                                selectedIndex = (selectedIndex - 1 + items.length) % items.length;
                                items.forEach(item => item.classList.remove('selected'));
                                items[selectedIndex].classList.add('selected');
                                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                                event.preventDefault();
                            } else if (event.key === 'Enter') {
                                event.preventDefault();
                                const selectedItem = items[selectedIndex];
                                if (selectedItem) {
                                    selectedItem.click();
                                    autocompleteDiv?.remove();
                                    selectedIndex = 0;
                                }
                            }
                        };

                        document.addEventListener('keydown', keyboardListener);
                    }
                }
            }

            function addTag(tagsList, tagObject, name) {
                const existingTags = Array.from(tagsList.querySelectorAll('.tag-item'));
                const isDuplicate = existingTags.some(tag => tag.getAttribute('data-id') === String(tagObject.id));

                if (isDuplicate) return;

                const tagItem = document.createElement('li');
                tagItem.className = 'tag-item';
                tagItem.setAttribute('data-id', tagObject.id);
                tagItem.setAttribute('data-name', tagObject.name || tagObject.label);
                tagItem.setAttribute('ng-repeat', 'tag in tagList.items track by track(tag)');
                tagItem.setAttribute('ng-class', '{ selected: tag == tagList.selected }');
                tagItem.setAttribute('ng-click', 'eventHandlers.tag.click(tag)');

                const tiTagItem = document.createElement('ti-tag-item');
                tiTagItem.setAttribute('data', `::${tagObject.name || tagObject.label}`);

                const ngInclude = document.createElement('ng-include');
                ngInclude.setAttribute('src', '$$template');

                const tagText = document.createElement('span');
                tagText.className = 'autocomplete-word';
                tagText.setAttribute('ng-bind', ':: $getDisplayText()');
                tagText.textContent = tagObject.name || tagObject.label;

                const removeButton = document.createElement('svg');
                removeButton.innerHTML = `
                            <svg src="x.svg" class="tag_item-remove_button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22">
                            <path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path></svg>
                        `;
                removeButton.setAttribute('ng-click', '$removeTag()');

                removeButton.addEventListener('click', (event) => {
                    event.stopPropagation();
                    tagsList.removeChild(tagItem);

                    let arrayToUpdate;

                    const match = name.match(/_(\d+)$/);
                    const fieldIndex = match ? parseInt(match[1], 10) : null;

                    if (name.startsWith('additional_role_') && fieldIndex !== null) {
                        arrayToUpdate = additionalRolesArray[fieldIndex];
                    } else if (name.startsWith('artist_role_') && fieldIndex !== null) {
                        arrayToUpdate = artistRolesArray[fieldIndex];
                    } else if (name === 'primary_artists') {
                        arrayToUpdate = primaryArtistsArray;
                    } else if (name === 'featured_artists') {
                        arrayToUpdate = featuredArtistsArray;
                    } else if (name === 'tags') {
                        arrayToUpdate = tagsArray;
                    } else if (name === 'writers') {
                        arrayToUpdate = writersArray;
                    } else if (name === 'producers') {
                        arrayToUpdate = producersArray;
                    }

                    if (arrayToUpdate) {
                        const tagIndex = arrayToUpdate.findIndex(tag => tag.id === tagObject.id);
                        if (tagIndex !== -1) {
                            arrayToUpdate.splice(tagIndex, 1);
                            console.log(`Updated ${name.charAt(0).toUpperCase() + name.slice(1)} Array:`, arrayToUpdate);
                        }
                    }
                });

                ngInclude.appendChild(tagText);
                ngInclude.appendChild(removeButton);
                tiTagItem.appendChild(ngInclude);
                tagItem.appendChild(tiTagItem);
                tagsList.appendChild(tagItem);

                const existingSuggestions = document.querySelector('.autocomplete');
                if (existingSuggestions) {
                    existingSuggestions.remove();
                }
            }
        }
    }

    function songCreditsButtonAlbumPage(songIds) {
        console.log("Run function songCreditsButtonAlbumPage()");
        const DELAY_BEFORE_REOPEN = 150; // ? milliseconds

        const { stickyToolbarLeft, smallButton } = getDomElements();
        if (!stickyToolbarLeft || !smallButton) return;

        const existingButton = [...stickyToolbarLeft.querySelectorAll("button")].find(btn => ["Song Credits"].includes(btn.textContent.trim()));
        if (existingButton) existingButton.remove();

        function extractTrackNumbers() {
            const trackContainers = document.querySelectorAll('div[class^="Track__Container-"]');

            const rawTrackNumbers = [];
            const trackNumbers = [];

            let currentTrackNumber = 0;

            trackContainers.forEach(container => {
                const numberElement = container.querySelector('div[class*="Track__Number-"]');
                const trackNumber = numberElement ? numberElement.textContent.trim() : '';

                rawTrackNumbers.push(trackNumber);

                if (trackNumber && !isNaN(trackNumber)) {
                    currentTrackNumber = parseInt(trackNumber, 10);
                } else {
                    currentTrackNumber += 1;
                }

                trackNumbers.push(currentTrackNumber);
            });

            return { rawTrackNumbers, trackNumbers };
        }

        const creditsButton = document.createElement("button");
        creditsButton.type = "button";
        creditsButton.className = smallButton.className;
        creditsButton.textContent = "Song Credits";
        stickyToolbarLeft.appendChild(creditsButton);

        let creditsState = {};

        async function openCreditsEditor() {
            creditsState = {
                roleIndex: 0,
                activeTagsList: undefined,
                primaryArtistsArray: [],
                featuredArtistsArray: [],
                producersArray: [],
                writersArray: [],
                youtubeLinks: [],
                soundcloudLinks: [],
                primaryTagsArray: [],
                secondaryTagsArray: [],
                releaseDateArray: [],
                recordedArray: [],
                relationshipArray: [],
                geniusLinks: [],
                languageArray: [],
                additionalCreditsArray: [],
                additionalRolesArray: [],
                artistRolesArray: []
            };

            const optionSets = {
                "Primary Tag": [
                    { label: "Rap", value: 1434 },
                    { label: "Pop", value: 16 },
                    { label: "R&B", value: 352 },
                    { label: "Rock", value: 567 },
                    { label: "Country", value: 413 },
                    { label: "Electronic", value: 606 },
                    { label: "Non-Music", value: 1452 }
                ],
                "Song Relationship": [
                    { label: "Samples", value: "samples" },
                    { label: "Interpolates", value: "interpolates" },
                    { label: "Cover Of", value: "cover_of" },
                    { label: "Remix Of", value: "remix_of" },
                    { label: "Live Version Of", value: "live_version_of" },
                    { label: "Translation Of", value: "translation_of" }
                ],
                "Language": [
                    { label: "bosanski", value: "bs" },
                    { label: "crnogorski", value: "cnr" },
                    { label: "Deutsch", value: "de" },
                    { label: "Österreichisches Deutsch", value: "de-at" },
                    { label: "English", value: "en" },
                    { label: "Español", value: "es" },
                    { label: "Français", value: "fr" },
                    { label: "Schweizerdeutsch", value: "gsw" },
                    { label: "hrvatski", value: "hr" },
                    { label: "Italiano", value: "it" },
                    { label: "Kölsch", value: "ksh" },
                    { label: "Македонски", value: "mk" },
                    { label: "Nederlands", value: "nl" },
                    { label: "Norsk", value: "no" },
                    { label: "Polski", value: "pl" },
                    { label: "Português", value: "pt" },
                    { label: "Русский (Russian)", value: "ru" },
                    { label: "srpski", value: "sr" },
                    { label: "Svenska", value: "sv" },
                    { label: "Türkçe", value: "tr" },
                    { label: "o‘zbekcha", value: "uz" },
                    { label: "Tiếng Việt", value: "vi" },
                    { label: "简体中文 (Simplified Chinese)", value: "zh" },
                    { label: "繁體中文 (Traditional Chinese)", value: "zh-Hant" }
                ]
            };

            const { rawTrackNumbers, trackNumbers } = extractTrackNumbers();

            const modal = createModal(songIds, rawTrackNumbers, trackNumbers, creditsState, optionSets);

            /*const songDataAlbum = await Promise.all(
                songIds.map(async songId => {
                    const { song: songData } = await getApiData(songId, "songs");
                    return songData;
                })
            );
            if (!songDataAlbum) return;*/

            modal.saveButton.disabled = false;
            modal.saveButton.style.backgroundColor = "#24c609";
            modal.saveButton.style.cursor = "pointer";

            modal.cancelButton.addEventListener("click", () => {
                modal.stopObservers();
                modal.overlay.remove();
                document.body.style.overflow = "";
            });


            modal.saveButton.addEventListener('click', async (event) => {
                modal.status.textContent = "Loading...";

                const checkboxStates = {
                    tracklistIndividual: document.querySelector('#tracklist_individual')?._checked,
                    overwritePrimaryArtists: document.querySelector('#overwrite_primary_artists')?.checked,
                    overwriteFeaturedArtists: document.querySelector('#overwrite_featured_artists')?.checked,
                    overwriteProducers: document.querySelector('#overwrite_producers')?.checked,
                    overwriteWriters: document.querySelector('#overwrite_writers')?.checked,
                    overwriteYouTube: document.querySelector('#overwrite_youtube_links')?.checked,
                    overwriteSoundCloud: document.querySelector('#overwrite_soundcloud_links')?.checked,
                    overwritePrimaryTag: document.querySelector('#overwrite_primary_tag')?.checked,
                    overwriteTags: document.querySelector('#overwrite_tags')?.checked,
                    overwriteReleaseDate: document.querySelector('#overwrite_release_date')?.checked,
                    overwriteRecorded: document.querySelector('#overwrite_recorded_at')?.checked,
                    overwriteRelationship: document.querySelector('#overwrite_related_album')?.checked,
                    removePrimaryArtists: document.querySelector('#remove_primary_artists')?.checked,
                    removeFeaturedArtists: document.querySelector('#remove_featured_artists')?.checked,
                    removeProducers: document.querySelector('#remove_producers')?.checked,
                    removeWriters: document.querySelector('#remove_writers')?.checked,
                    removeYouTube: document.querySelector('#remove_youtube_links')?.checked,
                    removeSoundCloud: document.querySelector('#remove_soundcloud_links')?.checked,
                    removePrimaryTag: document.querySelector('#remove_primary_tag')?.checked,
                    removeTags: document.querySelector('#remove_tags')?.checked,
                    removeReleaseDate: document.querySelector('#remove_release_date')?.checked,
                    removeRecorded: document.querySelector('#remove_recorded_at')?.checked,
                    removeRelationship: document.querySelector('#remove_related_album')?.checked
                };

                for (let i = 0; i <= creditsState.roleIndex - 1; i++) {
                    checkboxStates[`overwriteAdditionalRole${i}`] = document.querySelector(`#overwrite_additional_role_${i}`)?.checked;
                    checkboxStates[`removeAdditionalRole${i}`] = document.querySelector(`#remove_additional_role_${i}`)?.checked;
                }

                const mainSongIds = songIds.filter((songId) => {
                    const checkbox = document.querySelector(`#checkbox_${songId}`);
                    return checkbox?.checked;
                });
                const additionalSongIds = creditsState.additionalCreditsArray.map(index => {
                    const songs = songIds.filter(songId => {
                        const checkbox = document.querySelector(`#checkbox_${index}_${songId}`);
                        return checkbox?.checked;
                    });
                    return { index, songIds: songs };
                });

                const allSongIds = checkboxStates.tracklistIndividual ? [...new Set([...mainSongIds, ...additionalSongIds.flatMap(e => e.songIds)])] : [...new Set(mainSongIds)];

                /*const songDataAlbum = await Promise.all(
                    allSongIds.map(async songId => {
                        const { song: songData } = await getApiData(songId, "songs");
                        return songData;
                    })
                );*/

                // * Queued through the shared rate limiter instead of firing every selected track at once.
                const songDataAlbum = (await getApiDataBatch(allSongIds, "songs")).map(data => data?.song).filter(Boolean);

                // ! Payloads are merged into the song's current data, so a missing song could wipe its metadata. Save nothing instead.
                if (songDataAlbum.length !== allSongIds.length) {
                    modal.status.textContent = `Could not load ${allSongIds.length - songDataAlbum.length} of ${allSongIds.length} selected songs. Nothing was saved, please try again.`;
                    return;
                }

                if (!songDataAlbum.length) return;

                const primaryArtistsPayload = creditsState.primaryArtistsArray.map(primary_artists => ({ id: primary_artists.id, name: primary_artists.name }));
                const featuredArtistsPayload = creditsState.featuredArtistsArray.map(featured_artists => ({ id: featured_artists.id, name: featured_artists.name }));
                const producersPayload = creditsState.producersArray.map(producer => ({ id: producer.id, name: producer.name }));
                const writersPayload = creditsState.writersArray.map(writer => ({ id: writer.id, name: writer.name }));
                const youtubePayload = creditsState.youtubeLinks;
                //const soundcloudPayload = creditsState.soundcloudLinks;
                const primaryTagPayload = creditsState.primaryTagsArray[0];
                const secondaryTagsPayload = creditsState.secondaryTagsArray.map(tag => ({ id: tag.id, name: tag.name }));
                const releaseDatePayload = creditsState.releaseDateArray[0];
                const recordedPayload = creditsState.recordedArray;
                const songRelationshipsPayload = creditsState.geniusLinks.map((songId, index) => ({
                    type: creditsState.relationshipArray[0],
                    song_ids: [songId]
                }));
                const languagePayload = creditsState.languageArray[0];
                const additionalCreditsPayload = creditsState.additionalCreditsArray.flatMap(roleIndex => {
                    const roles = creditsState.additionalRolesArray[roleIndex] || [];
                    const artists = creditsState.artistRolesArray[roleIndex]?.map(a => ({ id: a.id, name: a.name })) || [];
                    return roles.filter(r => r?.label && artists.length > 0).map(r => ({ index: roleIndex, label: r.label, artists }));
                });

                console.log('Existing SongData:', songDataAlbum);
                console.log('Checkbox States:', checkboxStates);
                console.log('Primary Artists:', primaryArtistsPayload);
                console.log('Featured Artists:', featuredArtistsPayload);
                console.log('Producers:', producersPayload);
                console.log('Writers:', writersPayload);
                console.log('YouTube-Links:', youtubePayload);
                console.log('Primary Tag:', primaryTagPayload);
                console.log('Secondary Tags:', secondaryTagsPayload);
                console.log('Release Date:', releaseDatePayload);
                console.log('Recorded At:', recordedPayload);
                console.log('Song Relationships:', songRelationshipsPayload);
                console.log('Language:', languagePayload);
                console.log('Additional Credits:', additionalCreditsPayload);

                const mainPayload = {};
                const additionalPayload = {};
                const finalPayload = {};

                for (let i = 0; i < mainSongIds.length; i++) {
                    const songId = mainSongIds[i];
                    const existingSongData = songDataAlbum.find(song => song.id === songId);

                    const payload = await processMainPayload(
                        songId,
                        existingSongData,
                        i + 1,
                        mainSongIds.length,
                        checkboxStates,
                        primaryArtistsPayload,
                        featuredArtistsPayload,
                        producersPayload,
                        writersPayload,
                        youtubePayload[i],
                        primaryTagPayload,
                        secondaryTagsPayload,
                        releaseDatePayload,
                        recordedPayload,
                        songRelationshipsPayload[i],
                        languagePayload
                    );

                    if (!mainPayload[songId]) mainPayload[songId] = [];
                    mainPayload[songId].push(payload);
                }

                if (checkboxStates.tracklistIndividual) {
                    for (const entry of additionalSongIds) {
                        const { index, songIds } = entry;

                        for (let i = 0; i < songIds.length; i++) {
                            const songId = songIds[i];
                            const existingSongData = songDataAlbum.find(song => song.id === songId);

                            const payload = await processAdditionalPayload(
                                songId,
                                existingSongData,
                                i + 1,
                                songIds.length,
                                checkboxStates,
                                additionalCreditsPayload.filter(r => r.index === index)
                            );

                            if (!additionalPayload[songId]) additionalPayload[songId] = [];
                            additionalPayload[songId].push(payload);
                        }
                    }
                } else {
                    for (let i = 0; i < mainSongIds.length; i++) {
                        const songId = mainSongIds[i];
                        const existingSongData = songDataAlbum.find(song => song.id === songId);

                        const payload = await processAdditionalPayload(
                            songId,
                            existingSongData,
                            i + 1,
                            mainSongIds.length,
                            checkboxStates,
                            additionalCreditsPayload
                        );

                        if (!additionalPayload[songId]) additionalPayload[songId] = [];
                        additionalPayload[songId].push(payload);
                    }
                }


                for (const songId of songIds) {
                    const merged = { text_format: "html,markdown", song: {} };

                    if (mainPayload[songId]) {
                        mainPayload[songId].forEach(p => {
                            Object.assign(merged.song, p.song);
                        });
                    }

                    const existing = songDataAlbum.find(s => s.id === Number(songId))?.custom_performances || [];
                    let finalPerformances = [...existing];

                    if (additionalPayload[songId]) {

                        const rolesFlat = additionalPayload[songId].flatMap(p => p.song.custom_performances || []);

                        // 1) REMOVE
                        rolesFlat.forEach(role => {
                            if (role.remove) {
                                const idx = finalPerformances.findIndex(r => r.label === role.label);
                                if (idx !== -1) {
                                    const existingRole = finalPerformances[idx];
                                    const filteredArtists = existingRole.artists.filter(artist => !role.artists.some(rem => rem.id === artist.id));
                                    const shouldDelete = filteredArtists.length === 0 || role.artists.some(a => a.id === 87999);

                                    if (shouldDelete) {
                                        finalPerformances.splice(idx, 1);
                                    } else {
                                        finalPerformances[idx] = {
                                            label: role.label,
                                            artists: filteredArtists
                                        };
                                    }
                                }
                            }
                        });

                        // 2) OVERWRITE
                        rolesFlat.forEach(role => {
                            if (role.overwrite) {
                                const idx = finalPerformances.findIndex(r => r.label === role.label);

                                const newRole = {
                                    label: role.label,
                                    artists: role.artists.map(({ id, name }) => ({ id, name }))
                                };

                                if (idx !== -1) {
                                    finalPerformances[idx] = newRole;
                                } else {
                                    finalPerformances.push(newRole);
                                }
                            }
                        });

                        // 3) ADD
                        rolesFlat.forEach(role => {
                            if (!role.overwrite && !role.remove) {
                                const idx = finalPerformances.findIndex(r => r.label === role.label);

                                if (idx !== -1) {
                                    const existingRole = finalPerformances[idx];
                                    const combinedArtists = [...existingRole.artists, ...role.artists].filter((artist, i, self) => self.findIndex(a => a.id === artist.id) === i);

                                    finalPerformances[idx] = {
                                        label: role.label,
                                        artists: combinedArtists
                                    };

                                } else {
                                    finalPerformances.push({
                                        label: role.label,
                                        artists: role.artists.map(({ id, name }) => ({ id, name }))
                                    });
                                }
                            }
                        });
                    }

                    const changed = JSON.stringify(finalPerformances) !== JSON.stringify(existing);
                    if (changed) {
                        merged.song.custom_performances = finalPerformances;
                    }

                    if (Object.keys(merged.song).length > 0) {
                        finalPayload[songId] = merged;

                        console.log("Song ID: ", songId);
                        console.log("1. Main Payload :", mainPayload[songId] || {});
                        console.log("2. Additional Payload: ", additionalPayload[songId] || {});
                        console.log("3. Final Payload: ", merged);
                    }
                }



                async function processMainPayload(
                    songId,
                    existingSongData,
                    currentIndex,
                    totalCount,
                    checkboxStates,
                    primaryArtistsPayload,
                    featuredArtistsPayload,
                    producersPayload,
                    writersPayload,
                    youtubePayload,
                    primaryTagPayload,
                    secondaryTagsPayload,
                    releaseDatePayload,
                    recordedPayload,
                    songRelationshipPayload,
                    languagePayload
                ) {

                    let existingId = existingSongData.id;
                    let existingPrimaryArtists = existingSongData.primary_artists;
                    let existingFeaturedArtists = existingSongData.featured_artists;
                    let existingProducers = existingSongData.producer_artists;
                    let existingWriters = existingSongData.writer_artists;
                    let existingYoutubeLink = existingSongData.youtube_url;
                    let existingSoundcloudLink = existingSongData.soundcloud_url;
                    let existingPrimaryTag = existingSongData.primary_tag;
                    let existingSecondaryTags = existingSongData.tags;
                    let existingReleaseDate = existingSongData.release_date_components;
                    let existingRecorded = existingSongData.recording_location;
                    let existingSongRelationships = existingSongData.song_relationships;
                    let existingLanguage = existingSongData.language;
                    let existingCustomPerformances = existingSongData.custom_performances;

                    console.log(`Existing Credits for Song ID ${existingId}:`, { existingPrimaryArtists, existingFeaturedArtists, existingProducers, existingWriters, existingYoutubeLink, existingSoundcloudLink, existingPrimaryTag, existingSecondaryTags, existingReleaseDate, existingRecorded, existingSongRelationships, existingLanguage, existingCustomPerformances });

                    const songIndex = songIds.indexOf(songId);

                    const payload = {
                        text_format: "html,markdown",
                        song: {}
                    };


                    if (primaryArtistsPayload.length != 0 || checkboxStates.overwritePrimaryArtists || checkboxStates.removePrimaryArtists) {
                        if (checkboxStates.overwritePrimaryArtists && primaryArtistsPayload) {
                            payload.song.primary_artists = primaryArtistsPayload;
                        } else if (checkboxStates.removePrimaryArtists && primaryArtistsPayload) {
                            const remainingArtists = existingPrimaryArtists.filter(existingPrimaryArtist => !primaryArtistsPayload.some(removeArtist => removeArtist.id === existingPrimaryArtist.id));
                            payload.song.primary_artists = remainingArtists.length > 0 ? remainingArtists : existingPrimaryArtists.slice(0, 1);
                        } else {
                            payload.song.primary_artists = [
                                ...existingPrimaryArtists,
                                ...primaryArtistsPayload.filter(newPrimaryArtist => !existingPrimaryArtists.some(existingPrimaryArtist => existingPrimaryArtist.id === newPrimaryArtist.id))
                            ];
                        }
                    }

                    if (featuredArtistsPayload.length != 0 || checkboxStates.overwriteFeaturedArtists || checkboxStates.removeFeaturedArtists) {
                        if (checkboxStates.overwriteFeaturedArtists && featuredArtistsPayload) {
                            payload.song.featured_artists = featuredArtistsPayload;
                        } else if (checkboxStates.removeFeaturedArtists && featuredArtistsPayload) {
                            const isMarkedForDeletion = featuredArtistsPayload.length === 1 && featuredArtistsPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.featured_artists = [];
                            } else {
                                payload.song.featured_artists = existingFeaturedArtists.filter(
                                    existingFeaturedArtist => !featuredArtistsPayload.some(removeFeaturedArtist => removeFeaturedArtist.id === existingFeaturedArtist.id)
                                );
                            }
                        } else {
                            payload.song.featured_artists = [
                                ...existingFeaturedArtists,
                                ...featuredArtistsPayload.filter(
                                    newFeaturedArtist => !existingFeaturedArtists.some(existingFeaturedArtist => existingFeaturedArtist.id === newFeaturedArtist.id)
                                )
                            ];
                        }
                    }

                    if (producersPayload.length != 0 || checkboxStates.overwriteProducers || checkboxStates.removeProducers) {
                        if (checkboxStates.overwriteProducers && producersPayload) {
                            payload.song.producer_artists = producersPayload;
                        } else if (checkboxStates.removeProducers && producersPayload) {
                            const isMarkedForDeletion = producersPayload.length === 1 && producersPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.producer_artists = [];
                            } else {
                                payload.song.producer_artists = existingProducers.filter(
                                    existingProducer => !producersPayload.some(removeProducer => removeProducer.id === existingProducer.id)
                                );
                            }
                        } else {
                            payload.song.producer_artists = [
                                ...existingProducers,
                                ...producersPayload.filter(
                                    newProducer => !existingProducers.some(existingProducer => existingProducer.id === newProducer.id)
                                )
                            ];
                        }
                    }

                    if (writersPayload.length != 0 || checkboxStates.overwriteWriters || checkboxStates.removeWriters) {
                        if (checkboxStates.overwriteWriters && writersPayload) {
                            payload.song.writer_artists = writersPayload;
                        } else if (checkboxStates.removeWriters && writersPayload) {
                            const isMarkedForDeletion = writersPayload.length === 1 && writersPayload[0].id === 87999;
                            if (isMarkedForDeletion) {
                                payload.song.writer_artists = [];
                            } else {
                                payload.song.writer_artists = existingWriters.filter(
                                    existingWriter => !writersPayload.some(removeWriter => removeWriter.id === existingWriter.id)
                                );
                            }
                        } else {
                            payload.song.writer_artists = [
                                ...existingWriters,
                                ...writersPayload.filter(
                                    newWriter => !existingWriters.some(existingWriter => existingWriter.id === newWriter.id)
                                )
                            ];
                        }
                    }

                    if (youtubePayload || checkboxStates.overwriteYouTube || checkboxStates.removeYouTube) {
                        if (checkboxStates.overwriteYouTube && youtubePayload) {
                            payload.song.youtube_url = youtubePayload;
                        } else if (checkboxStates.removeYouTube && creditsState.youtubeLinks === "Delete") {
                            payload.song.youtube_url = null;
                        } else if (!existingYoutubeLink) {
                            payload.song.youtube_url = youtubePayload;
                        }
                    }

                    if (primaryTagPayload || checkboxStates.overwritePrimaryTag || checkboxStates.removePrimaryTag) {
                        const primaryTagIds = optionSets["Primary Tag"].map(o => String(o.value));
                        if (checkboxStates.overwritePrimaryTag && primaryTagPayload) {
                            existingSecondaryTags = existingSecondaryTags.filter(tag => tag.id !== existingPrimaryTag.id);
                            payload.song.primary_tag_id = primaryTagPayload;
                        } else if (checkboxStates.removePrimaryTag && primaryTagPayload) {
                            existingSecondaryTags = existingSecondaryTags.filter(tag => !primaryTagIds.includes(String(tag.id)) || String(tag.id) === primaryTagPayload);
                            payload.song.primary_tag_id = primaryTagPayload;
                        } else {
                            payload.song.primary_tag_id = primaryTagPayload;
                        }
                    }

                    if (secondaryTagsPayload.length != 0 || checkboxStates.overwriteTags || checkboxStates.removeTags || checkboxStates.overwritePrimaryTag || checkboxStates.removePrimaryTag) {
                        if (checkboxStates.overwriteTags && secondaryTagsPayload) {
                            payload.song.tags = secondaryTagsPayload;
                        } else if (checkboxStates.removeTags && secondaryTagsPayload) {
                            payload.song.tags = existingSecondaryTags.filter(existingSecondaryTag => !secondaryTagsPayload.some(removeTag => removeTag.id === existingSecondaryTag.id));
                        } else {
                            payload.song.tags = [...existingSecondaryTags, ...secondaryTagsPayload.filter(newTag => !existingSecondaryTags.some(existingSecondaryTag => existingSecondaryTag.id === newTag.id))];
                        }
                    }

                    if ((releaseDatePayload?.day != null || releaseDatePayload?.month != null || releaseDatePayload?.year != null) || checkboxStates.overwriteReleaseDate || checkboxStates.removeReleaseDate) {
                        if (checkboxStates.overwriteReleaseDate && (releaseDatePayload?.day != null || releaseDatePayload?.month != null || releaseDatePayload?.year != null)) {
                            payload.song.release_date_components = {
                                day: releaseDatePayload?.day || null,
                                month: releaseDatePayload?.month || null,
                                year: releaseDatePayload?.year || null
                            };
                        } else if (checkboxStates.removeReleaseDate) {
                            payload.song.release_date_components = {
                                day: (releaseDatePayload?.day === 31) ? null : existingReleaseDate?.day || null,
                                month: (releaseDatePayload?.month === 12) ? null : existingReleaseDate?.month || null,
                                year: (releaseDatePayload?.year === 1900) ? null : existingReleaseDate?.year || null
                            };
                        } else {
                            const hasPayloadDay = releaseDatePayload?.day != null;
                            const hasPayloadMonth = releaseDatePayload?.month != null;
                            const hasPayloadYear = releaseDatePayload?.year != null;

                            const hasExistingDay = existingReleaseDate?.day != null;
                            const hasExistingMonth = existingReleaseDate?.month != null;
                            const hasExistingYear = existingReleaseDate?.year != null;

                            if (hasExistingYear && hasExistingMonth && hasExistingDay) {
                                payload.song.release_date_components = {
                                    day: existingReleaseDate.day,
                                    month: existingReleaseDate.month,
                                    year: existingReleaseDate.year
                                };
                            } else if (hasExistingYear && hasExistingMonth) {
                                const sameMonth = releaseDatePayload.month === existingReleaseDate?.month;
                                const sameYear = releaseDatePayload.year === existingReleaseDate?.year;

                                payload.song.release_date_components = {
                                    day: (sameMonth && sameYear) ? releaseDatePayload.day || existingReleaseDate?.day || null : existingReleaseDate?.day || null,
                                    month: existingReleaseDate.month,
                                    year: existingReleaseDate.year
                                };
                            } else if (hasExistingYear) {
                                const sameYear = releaseDatePayload.year === existingReleaseDate?.year;

                                payload.song.release_date_components = {
                                    day: sameYear ? releaseDatePayload.day || existingReleaseDate?.day || null : existingReleaseDate?.day || null,
                                    month: sameYear ? releaseDatePayload.month || existingReleaseDate?.month || null : existingReleaseDate?.month || null,
                                    year: existingReleaseDate.year
                                };
                            } else {
                                payload.song.release_date_components = {
                                    day: releaseDatePayload?.day || null,
                                    month: releaseDatePayload?.month || null,
                                    year: releaseDatePayload?.year || null
                                };
                            }
                        }
                    }

                    if (recordedPayload.length != 0 || checkboxStates.overwriteRecorded || checkboxStates.removeRecorded) {
                        if (checkboxStates.overwriteRecorded && recordedPayload) {
                            payload.song.recording_location = recordedPayload;
                        } else if (checkboxStates.removeRecorded && recordedPayload === "Delete") {
                            payload.song.recording_location = null;
                        } else if (!existingRecorded) {
                            payload.song.recording_location = recordedPayload;
                        }
                    }

                    if (songRelationshipPayload || checkboxStates.overwriteRelationship || checkboxStates.removeRelationship) {
                        if (checkboxStates.overwriteRelationship && songRelationshipPayload) {
                            const existingRelationships = existingSongRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: rel.songs?.map(song => song.id) || []
                            }));

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: [...rel.song_ids]
                            }));

                            const newRelationship = {
                                type: songRelationshipPayload.type,
                                song_ids: songRelationshipPayload.song_ids
                            };

                            const relationship = payload.song.song_relationships_by_id.find(rel => rel.type === newRelationship.type);
                            relationship.song_ids = [...newRelationship.song_ids];
                        } else if (checkboxStates.removeRelationship && songRelationshipPayload) {

                            const existingRelationships = existingSongRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: rel.songs?.map(song => song.id) || []
                            }));

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: [...rel.song_ids]
                            }));

                            const removeRelationship = {
                                type: songRelationshipPayload.type,
                                song_ids: songRelationshipPayload.song_ids
                            };

                            const relationship = payload.song.song_relationships_by_id.find(rel => rel.type === removeRelationship.type);

                            if (removeRelationship.song_ids.includes("Delete")) {
                                relationship.song_ids = [];
                            } else {
                                relationship.song_ids = relationship.song_ids.filter(id => !removeRelationship.song_ids.includes(id));
                            }
                        } else {
                            const existingRelationships = existingSongRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: rel.songs?.map(song => song.id) || []
                            }));

                            payload.song.song_relationships_by_id = existingRelationships.map(rel => ({
                                type: rel.type,
                                song_ids: [...rel.song_ids]
                            }));

                            const newRelationship = {
                                type: songRelationshipPayload.type,
                                song_ids: songRelationshipPayload.song_ids
                            };

                            const relationship = payload.song.song_relationships_by_id.find(rel => rel.type === newRelationship.type);
                            relationship.song_ids = [...new Set([...relationship.song_ids, ...newRelationship.song_ids])];
                        }

                    }

                    if (languagePayload) {
                        payload.song.language = languagePayload;
                    }

                    return payload;
                }

                async function processAdditionalPayload(
                    songId,
                    existingSongData,
                    currentIndex,
                    totalCount,
                    checkboxStates,
                    additionalCreditsPayload
                ) {
                    const payload = {
                        text_format: "html,markdown",
                        song: { custom_performances: [] }
                    };

                    additionalCreditsPayload.forEach(role => {
                        const rowIndex = role.index;

                        payload.song.custom_performances.push({
                            label: role.label,
                            artists: role.artists.map(a => ({ id: a.id, name: a.name })),
                            overwrite: checkboxStates[`overwriteAdditionalRole${rowIndex}`],
                            remove: checkboxStates[`removeAdditionalRole${rowIndex}`]
                        });
                    });

                    return payload;
                }


                /* let totalToSave = songIds.length;
                 let currentIndex = 1;

                for (const songId of songIds) {
                    const payload = finalPayload[songId];
                    const song = songDataAlbum.find(s => s.id === Number(songId));

                    modal.status.textContent = "";
                    modal.status.appendChild(document.createTextNode("Saving Track "));

                    const strong1 = document.createElement("strong");
                    strong1.textContent = currentIndex;
                    modal.status.appendChild(strong1);

                    modal.status.appendChild(document.createTextNode(" of "));

                    const strong2 = document.createElement("strong");
                    strong2.textContent = totalToSave;
                    modal.status.appendChild(strong2);

                    modal.status.appendChild(document.createTextNode("..."));

                    if (payload) {
                        await updateSongMetadata(song.id, payload.song);
                    }

                    currentIndex++;
                }*/


                const totalToSave = songIds.length;
                let displayIndex = 1;
                const concurrency = 3;

                async function processSong(songId) {
                    const payload = finalPayload[songId];
                    const song = songDataAlbum.find(s => s.id === Number(songId));

                    if (payload) {
                        await updateSongMetadata(song.id, payload.song);
                    } else {
                        await new Promise(resolve => setTimeout(resolve, 50));
                    }
                }

                function updateStatus(index) {
                    modal.status.textContent = "";
                    modal.status.appendChild(document.createTextNode("Saving Track "));

                    const strong1 = document.createElement("strong");
                    strong1.textContent = index;
                    modal.status.appendChild(strong1);

                    modal.status.appendChild(document.createTextNode(" of "));

                    const strong2 = document.createElement("strong");
                    strong2.textContent = totalToSave;
                    modal.status.appendChild(strong2);

                    modal.status.appendChild(document.createTextNode("..."));
                }

                async function runInParallel() {
                    const queue = [...songIds];
                    const workers = [];

                    for (let w = 0; w < concurrency; w++) {
                        workers.push((async function worker() {
                            while (queue.length > 0) {
                                const songId = queue.shift();
                                await processSong(songId);
                                updateStatus(displayIndex++);
                            }
                        })());
                    }

                    await Promise.all(workers);
                }

                await runInParallel();

                modal.status.textContent = autoReopenSongCredits ? "Done! Reopening editor..." : "Done!";

                setTimeout(async () => {
                    modal.stopObservers();
                    document.body.removeChild(modal.overlay);
                    document.body.style.overflow = "";
                    setTimeout(() => {
                        if (autoReopenSongCredits) openCreditsEditor();
                    }, DELAY_BEFORE_REOPEN);
                }, DELAY_BEFORE_CLEANUP);

            });
        }

        creditsButton.addEventListener("click", openCreditsEditor);

        function createModal(songIds, rawTrackNumbers, trackNumbers, creditsState, optionSets) {
            function createForm() {
                document.body.style.overflow = "hidden";

                const overlay = document.createElement('div');
                Object.assign(overlay.style, {
                    position: 'fixed',
                    inset: '0',
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    zIndex: '1000'
                });

                const form = document.createElement('form');
                Object.assign(form.style, {
                    backgroundColor: '#fff',
                    width: '80%',
                    maxWidth: '800px',
                    height: '93%',
                    boxSizing: 'border-box',
                    display: 'flex',
                    flexDirection: 'column'
                });

                overlay.appendChild(form);
                return { overlay, form };
            }

            function createControls(overlay) {
                const controls = document.createElement('div');
                Object.assign(controls.style, {
                    position: 'absolute',
                    top: '2.25rem',
                    left: 'calc(50% + 400px + 0.75rem)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1rem',
                    pointerEvents: 'auto'
                });

                function createButtonField({ aria, label, color, svgPath, viewBox }) {
                    const field = document.createElement('label');
                    Object.assign(field.style, {
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        cursor: 'pointer',
                        userSelect: 'none'
                    });

                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.ariaLabel = aria;
                    Object.assign(btn.style, {
                        width: '2.25rem',
                        height: '2.25rem',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: color
                    });

                    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                    svg.setAttribute('viewBox', viewBox);
                    Object.assign(svg.style, {
                        width: '0.75rem',
                        height: '0.75rem'
                    });

                    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                    path.setAttribute('d', svgPath);
                    path.style.fill = 'white';

                    svg.appendChild(path);
                    btn.appendChild(svg);

                    const text = document.createElement('div');
                    Object.assign(text.style, {
                        marginTop: '9px',
                        fontSize: '0.75rem',
                        color: '#fff',
                        textAlign: 'center'
                    });
                    text.textContent = label;

                    field.appendChild(btn);
                    field.appendChild(text);

                    return { field, btn };
                }

                const save = createButtonField({
                    aria: 'Save',
                    label: 'Save',
                    color: '#999',
                    svgPath: 'M8.83 16.2L0 7.97l2.06-2.21 6.62 6.17L19.79 0 22 2.06 8.83 16.2',
                    viewBox: "0 0 22 16.2"
                });

                const cancel = createButtonField({
                    aria: 'Cancel',
                    label: 'Cancel',
                    color: '#ff3b30',
                    svgPath: 'M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39',
                    viewBox: "0 0 22 22"
                });

                const reopen = createAutoReopenSwitch();

                const separator = document.createElement('div');
                Object.assign(separator.style, {
                    width: '2.25rem',
                    height: '1px',
                    backgroundColor: 'rgba(255, 255, 255, 0.3)'
                });

                save.btn.disabled = true;
                save.btn.style.cursor = "not-allowed";

                controls.appendChild(save.field);
                controls.appendChild(cancel.field);
                controls.appendChild(separator);
                controls.appendChild(reopen.field);
                overlay.appendChild(controls);

                return { controls, saveButton: save.btn, cancelButton: cancel.btn, reopenToggle: reopen.input };
            }

            function createContent(form) {
                form.style.overflowX = "hidden";

                function createNavbar(form) {
                    const navbar = document.createElement("div");
                    Object.assign(navbar.style, {
                        background: "black",
                        color: "white",
                        padding: "0.5rem 1rem",
                        zIndex: "9",
                        display: "grid",
                        gridTemplateColumns: "25px 350px auto 350px 25px",
                        placeItems: "center"
                    });

                    function createArrow(pathD) {
                        const wrapper = document.createElement("div");
                        Object.assign(wrapper.style, {
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center"
                        });

                        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                        svg.setAttribute("viewBox", "0 0 24 24");

                        Object.assign(svg.style, {
                            width: "22px",
                            height: "22px",
                            display: "block"
                        });

                        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                        path.setAttribute("d", pathD);

                        Object.assign(path.style, {
                            fill: "white",
                            stroke: "white",
                            strokeLinejoin: "round"
                        });

                        svg.appendChild(path);
                        wrapper.appendChild(svg);
                        return wrapper;
                    }

                    const leftArrow = createArrow("M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z");
                    const rightArrow = createArrow("M8.59 16.59L10 18l6-6-6-6-1.41 1.41L13.17 12z");

                    const divider = document.createElement("div");
                    Object.assign(divider.style, {
                        width: "2px",
                        height: "1.25rem",
                        background: "white",
                        opacity: "0.6"
                    });

                    const tabMain = document.createElement("div");
                    tabMain.textContent = "Main Credits";
                    Object.assign(tabMain.style, {
                        padding: "0.25rem 0.5rem",
                        cursor: "pointer"
                    });

                    const tabAdditional = document.createElement("div");
                    tabAdditional.textContent = "Additional Credits";
                    Object.assign(tabAdditional.style, {
                        padding: "0.25rem 0.5rem",
                        cursor: "pointer"
                    });

                    navbar.appendChild(leftArrow);
                    navbar.appendChild(tabMain);
                    navbar.appendChild(divider);
                    navbar.appendChild(tabAdditional);
                    navbar.appendChild(rightArrow);

                    form.appendChild(navbar);
                    return { leftArrow, rightArrow, tabMain, tabAdditional };
                }

                function createPages(form) {
                    const contentWrapper = document.createElement("div");
                    Object.assign(contentWrapper.style, {
                        display: "flex",
                        width: "200%",
                        transition: "transform 0.25s ease",
                        overflowY: "hidden"
                    });

                    const pageStyle = {
                        width: "50%",
                        padding: "2.25rem",
                        boxSizing: "border-box",
                        overflowY: "auto"
                    };

                    const page1 = document.createElement("div");
                    Object.assign(page1.style, pageStyle);
                    const page2 = document.createElement("div");
                    Object.assign(page2.style, pageStyle);

                    contentWrapper.appendChild(page1);
                    contentWrapper.appendChild(page2);

                    form.appendChild(contentWrapper);
                    return { contentWrapper, page1, page2 };
                }

                function createStatus(form) {
                    const status = document.createElement("div");
                    Object.assign(status.style, {
                        padding: "1rem 2.25rem",
                        zIndex: "9",
                        marginTop: "auto"
                    });

                    form.appendChild(status);
                    return { status };
                }

                function activate(tab) {
                    const isMain = tab === "main";
                    contentWrapper.style.transform = isMain ? "translateX(0%)" : "translateX(-50%)";
                    tabMain.style.borderBottom = isMain ? "2px solid white" : "none";
                    tabAdditional.style.borderBottom = isMain ? "none" : "2px solid white";
                    tabMain.style.opacity = isMain ? "1" : "0.6";
                    tabAdditional.style.opacity = isMain ? "0.6" : "1";
                    leftArrow.style.opacity = isMain ? "0.4" : "1";
                    rightArrow.style.opacity = isMain ? "1" : "0.4";
                }

                const { leftArrow, rightArrow, tabMain, tabAdditional } = createNavbar(form);
                const { contentWrapper, page1, page2 } = createPages(form);
                const { status } = createStatus(form);

                tabMain.addEventListener("click", () => activate("main"));
                tabAdditional.addEventListener("click", () => activate("additional"));
                leftArrow.addEventListener("click", () => activate("main"));
                rightArrow.addEventListener("click", () => activate("additional"));

                activate("main");

                return { page1, page2, status };
            }

            function createTracklist(songIds, trackNumbers, rawTrackNumbers, isPage2) {
                const tracklistContainer = document.createElement('div');
                tracklistContainer.className = 'tracklist_container'

                const tracklistLabel = document.createElement('div');
                tracklistLabel.className = 'text_label';
                tracklistLabel.textContent = 'Tracklist';
                Object.assign(tracklistLabel.style, {
                    display: "flex",
                    justifyContent: "space-between",
                    marginBottom: "0.35rem"
                });

                if (isPage2) {
                    const individualTracklistButton = document.createElement("div");
                    individualTracklistButton.id = "tracklist_individual";
                    individualTracklistButton.textContent = "Individual Tracklist";
                    Object.assign(individualTracklistButton.style, {
                        cursor: "pointer",
                        textDecoration: "underline",
                        display: "inline-block"
                    });

                    individualTracklistButton._checked = false;

                    individualTracklistButton.addEventListener("click", () => {
                        individualTracklistButton._checked = !individualTracklistButton._checked;

                        const isIndividualMode = individualTracklistButton._checked;

                        allTracksButton.style.visibility = isIndividualMode ? "hidden" : "visible";
                        checkboxContainer.style.display = isIndividualMode ? "none" : "grid";

                        document.querySelectorAll(".miniTracklist").forEach(mini => {
                            mini.style.display = isIndividualMode ? "block" : "none";
                        });

                        individualTracklistButton.textContent = isIndividualMode ? "Combined Tracklist" : "Individual Tracklist";
                    });

                    tracklistLabel.appendChild(individualTracklistButton);
                }


                const allTracksButton = document.createElement('div');
                allTracksButton.id = 'toggle_all_tracks';
                allTracksButton.textContent = 'All / None';
                Object.assign(allTracksButton.style, {
                    cursor: "pointer",
                    textDecoration: "underline",
                    display: "inline-block"
                });

                allTracksButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    const checkboxes = tracklistContainer.querySelectorAll('.styled-checkbox');
                    const allSelected = Array.from(checkboxes).every(checkbox => checkbox.checked);
                    checkboxes.forEach(checkbox => {
                        checkbox.checked = !allSelected;
                        checkbox.dispatchEvent(new Event("change"));
                    });
                });

                tracklistLabel.appendChild(allTracksButton);

                const checkboxContainer = document.createElement('div');
                Object.assign(checkboxContainer.style, {
                    display: "grid",
                    gridTemplateColumns: `repeat(${Math.ceil(trackNumbers.length / Math.ceil(trackNumbers.length / 15))}, auto)`
                });

                const line = document.createElement('hr');
                Object.assign(line.style, {
                    border: "none",
                    borderTop: "0.5rem solid black"
                });

                function toRoman(num) {
                    const romanMap = [['M', 1000], ['CM', 900], ['D', 500], ['CD', 400], ['C', 100], ['XC', 90], ['L', 50], ['XL', 40], ['X', 10], ['IX', 9], ['V', 5], ['IV', 4], ['I', 1],];
                    let roman = '';
                    romanMap.forEach(([symbol, value]) => {
                        while (num >= value) {
                            roman += symbol;
                            num -= value;
                        }
                    });
                    return roman;
                }

                let autoCounter = 1;
                songIds.forEach((songId, index) => {
                    const checkboxDiv = document.createElement('div');
                    Object.assign(checkboxDiv.style, {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center"
                    });

                    const checkbox = document.createElement("input");
                    checkbox.type = "checkbox";
                    checkbox.id = `checkbox_${songId}`;
                    checkbox.name = `song_${songId}`;

                    Object.assign(checkbox.style, {
                        appearance: "none",
                        border: "1px solid rgb(0,0,0)",
                        width: "0.85rem",
                        height: "0.85rem",
                        backgroundColor: "white",
                        cursor: "pointer",
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "center",
                        backgroundSize: "contain"
                    });

                    const checkSvg = "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")";
                    const rawTrackNumber = rawTrackNumbers[index];
                    checkbox.checked = rawTrackNumber !== "";
                    checkbox.className = 'styled-checkbox';

                    const updateCheckboxStyle = () => {
                        if (checkbox.checked) {
                            checkbox.style.backgroundColor = "rgb(0,0,0)";
                            checkbox.style.backgroundImage = checkSvg;
                        } else {
                            checkbox.style.backgroundColor = "white";
                            checkbox.style.backgroundImage = "none";
                        }
                    };

                    updateCheckboxStyle();
                    checkbox.addEventListener("change", updateCheckboxStyle);

                    const label = document.createElement('label');
                    label.htmlFor = `checkbox_${songId}`;
                    label.textContent = rawTrackNumber !== '' ? `${rawTrackNumber}` : toRoman(autoCounter++);
                    Object.assign(label.style, {
                        marginLeft: "0.25rem",
                        textAlign: songIds.length <= 15 ? "left" : "right",
                        width: "0.85rem",
                        display: "inline-block",
                        cursor: "pointer",
                        overflowWrap: "normal"
                    });

                    checkboxDiv.appendChild(checkbox);
                    checkboxDiv.appendChild(label);
                    checkboxContainer.appendChild(checkboxDiv);
                });

                tracklistContainer.appendChild(tracklistLabel);
                tracklistContainer.appendChild(checkboxContainer);
                tracklistContainer.appendChild(line);

                return tracklistContainer;
            }

            function createMiniTracklist(songIds, roleIndex, trackNumbers, rawTrackNumbers) {
                const tracklistContainer = document.createElement('div');
                tracklistContainer.className = 'tracklist_container';
                Object.assign(tracklistContainer.style, {
                    marginBottom: "0.25rem"
                });

                const tracklistLabel = document.createElement('div');
                tracklistLabel.className = 'text_label';
                tracklistLabel.textContent = 'Tracklist';
                Object.assign(tracklistLabel.style, {
                    display: "flex",
                    justifyContent: "space-between"
                });

                const allTracksContainer = document.createElement('div');
                Object.assign(allTracksContainer.style, {
                    display: "flex",
                    alignItems: "center"
                });

                const allTracksButton = document.createElement('div');
                allTracksButton.textContent = 'All / None';
                Object.assign(allTracksButton.style, {
                    cursor: "pointer",
                    textDecoration: "underline",
                    display: "inline-block"
                });

                allTracksButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    const checkboxes = tracklistContainer.querySelectorAll('.styled-checkbox');
                    const allSelected = Array.from(checkboxes).every(cb => cb.checked);
                    checkboxes.forEach(cb => {
                        cb.checked = !allSelected;
                        cb.dispatchEvent(new Event("change"));
                    });
                });

                allTracksContainer.appendChild(allTracksButton);
                tracklistLabel.appendChild(allTracksContainer);

                const checkboxContainer = document.createElement('div');
                Object.assign(checkboxContainer.style, {
                    display: "grid",
                    gridTemplateColumns: `repeat(${Math.ceil(trackNumbers.length / Math.ceil(trackNumbers.length / 20))}, auto)`
                });

                function toRoman(num) {
                    const romanMap = [['M', 1000], ['CM', 900], ['D', 500], ['CD', 400], ['C', 100], ['XC', 90], ['L', 50], ['XL', 40], ['X', 10], ['IX', 9], ['V', 5], ['IV', 4], ['I', 1],];
                    let roman = '';
                    romanMap.forEach(([symbol, value]) => {
                        while (num >= value) {
                            roman += symbol;
                            num -= value;
                        }
                    });
                    return roman;
                }

                let autoCounter = 1;

                songIds.forEach((songId, index) => {
                    const checkboxDiv = document.createElement('div');
                    Object.assign(checkboxDiv.style, {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "0.85rem",
                    });

                    const checkbox = document.createElement("input");

                    checkbox.type = "checkbox";
                    checkbox.id = `checkbox_${roleIndex}_${songId}`;
                    checkbox.name = `song_${roleIndex}_${songId}`;

                    Object.assign(checkbox.style, {
                        appearance: "none",
                        border: "1px solid rgb(0,0,0)",
                        width: "0.75rem",
                        height: "0.75rem",
                        backgroundColor: "white",
                        cursor: "pointer",
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "center",
                        backgroundSize: "contain"
                    });

                    const checkSvg = "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")";

                    const rawTrackNumber = rawTrackNumbers[index];
                    checkbox.checked = rawTrackNumber !== "";
                    checkbox.className = 'styled-checkbox';


                    const updateCheckboxStyle = () => {
                        if (checkbox.checked) {
                            checkbox.style.backgroundColor = "rgb(0,0,0)";
                            checkbox.style.backgroundImage = checkSvg;
                        } else {
                            checkbox.style.backgroundColor = "white";
                            checkbox.style.backgroundImage = "none";
                        }
                    };

                    updateCheckboxStyle();
                    checkbox.addEventListener("change", updateCheckboxStyle);

                    const label = document.createElement('label');
                    label.htmlFor = checkbox.id;
                    label.textContent = rawTrackNumber !== '' ? `${rawTrackNumber}` : toRoman(autoCounter++);
                    Object.assign(label.style, {
                        marginLeft: "0.15rem",
                        width: "0.5rem",
                        display: "inline-block",
                        cursor: "pointer"
                    });

                    checkboxDiv.appendChild(checkbox);
                    checkboxDiv.appendChild(label);
                    checkboxContainer.appendChild(checkboxDiv);
                });

                tracklistContainer.appendChild(tracklistLabel);
                tracklistContainer.appendChild(checkboxContainer);

                return tracklistContainer;
            }

            function createCheckboxContainer(overwriteCheckboxId, removeCheckboxId, parentLabel) {
                const overwriteContainer = document.createElement('div');
                overwriteContainer.className = 'overwrite-container';
                overwriteContainer.style.display = 'flex';
                overwriteContainer.style.alignItems = 'center';

                function styleCheckbox(checkbox) {
                    Object.assign(checkbox.style, {
                        appearance: "none",
                        border: "1px solid rgb(0,0,0)",
                        width: "0.85rem",
                        height: "0.85rem",
                        backgroundColor: "white",
                        cursor: "pointer",
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "center",
                        backgroundSize: "contain",
                        marginLeft: "0.6rem"
                    });
                }

                const checkSvg = "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 18 18' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23fff' d='m15.5 4.9-7.9 10-5-5L4 8.3l3.4 3.4L14 3.6 15.5 5Z'/%3E%3C/svg%3E\")";

                function updateCheckboxStyle(checkbox) {
                    if (checkbox.checked) {
                        checkbox.style.backgroundColor = "rgb(0,0,0)";
                        checkbox.style.backgroundImage = checkSvg;
                    } else {
                        checkbox.style.backgroundColor = "white";
                        checkbox.style.backgroundImage = "none";
                    }
                }

                const overwriteCheckbox = document.createElement('input');
                overwriteCheckbox.type = 'checkbox';
                overwriteCheckbox.id = overwriteCheckboxId;
                styleCheckbox(overwriteCheckbox);

                const removeCheckbox = document.createElement('input');
                removeCheckbox.type = 'checkbox';
                removeCheckbox.id = removeCheckboxId;
                styleCheckbox(removeCheckbox);

                const overwriteLabel = document.createElement('label');
                overwriteLabel.htmlFor = overwriteCheckboxId;
                overwriteLabel.textContent = "OVERWRITE";
                Object.assign(overwriteLabel.style, {
                    marginLeft: "0.35rem",
                    cursor: "pointer",
                    fontSize: "0.65rem",
                    fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                    letterSpacing: "0.5px",
                    color: "black"
                });

                const removeLabel = document.createElement('label');
                removeLabel.htmlFor = removeCheckboxId;
                removeLabel.textContent = "REMOVE";
                Object.assign(removeLabel.style, {
                    marginLeft: "0.35rem",
                    cursor: "pointer",
                    fontSize: "0.65rem",
                    fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                    letterSpacing: "0.5px",
                    color: "black"
                });

                function toggleCheckbox(checkedBox, otherBox) {
                    if (checkedBox.checked) {
                        otherBox.checked = false;
                    }
                    updateCheckboxStyle(checkedBox);
                    updateCheckboxStyle(otherBox);
                    updateLabelColors();
                }

                function updateLabelColors() {
                    if (overwriteCheckbox.checked) {
                        overwriteLabel.style.color = "red";
                        removeLabel.style.color = "black";
                    } else if (removeCheckbox.checked) {
                        removeLabel.style.color = "red";
                        overwriteLabel.style.color = "black";
                    } else {
                        overwriteLabel.style.color = "black";
                        removeLabel.style.color = "black";
                    }
                }

                overwriteCheckbox.addEventListener('change', () => toggleCheckbox(overwriteCheckbox, removeCheckbox));
                removeCheckbox.addEventListener('change', () => toggleCheckbox(removeCheckbox, overwriteCheckbox));

                updateCheckboxStyle(overwriteCheckbox);
                updateCheckboxStyle(removeCheckbox);
                updateLabelColors();

                overwriteContainer.appendChild(overwriteCheckbox);
                overwriteContainer.appendChild(overwriteLabel);
                overwriteContainer.appendChild(removeCheckbox);
                overwriteContainer.appendChild(removeLabel);
                parentLabel.appendChild(overwriteContainer);
            }

            function createRemoveContainer(removeButtonId, parentLabel) {
                const removeContainer = document.createElement('div');
                removeContainer.className = 'remove-container';
                Object.assign(removeContainer.style, {
                    display: 'flex',
                    alignItems: 'center',
                    cursor: 'pointer'
                });

                const removeButton = document.createElement("span");
                removeButton.id = removeButtonId;

                Object.assign(removeButton.style, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    width: "fit-content"
                });

                const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                svg.setAttribute("viewBox", "0 0 22 22");
                svg.style.width = "0.75rem";
                svg.style.height = "0.75rem";

                const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                path.setAttribute(
                    "d",
                    "M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"
                );
                path.style.fill = "black";

                svg.appendChild(path);
                removeButton.appendChild(svg);

                removeButton.addEventListener("click", () => {
                    const inner = removeButton.closest("[data-index]");
                    const outer = inner?.parentElement?.closest("[data-index]");
                    const target = outer || inner;
                    if (!target) return;

                    const idx = parseInt(target.getAttribute("data-index"), 10);
                    const pos = creditsState.additionalCreditsArray.indexOf(idx);
                    if (pos !== -1) creditsState.additionalCreditsArray.splice(pos, 1);
                    target.remove();
                });


                removeContainer.appendChild(removeButton);
                parentLabel.appendChild(removeContainer);
            }

            function createRow(...fields) {
                const row = document.createElement("div");

                Object.assign(row.style, {
                    display: "flex",
                    gap: "1.5rem",
                    width: "100%",
                    margin: "1.75rem 0rem"
                });

                const count = fields.length;
                let widths = [];

                if (count === 1) {
                    widths = ["50%", "50%"];

                    const dummy = document.createElement("div");
                    Object.assign(dummy.style, {
                        width: "100%",
                        height: "100%"
                    });

                    fields.push({ inputContainer: dummy });
                }

                if (count === 2) {
                    widths = ["50%", "50%"];
                }

                if (count === 3) {
                    widths = ["27.5%", "45%", "27.5%"];
                }

                fields.forEach((field, i) => {
                    field.inputContainer.style.width = widths[i];
                    row.appendChild(field.inputContainer);
                });

                return row;
            }

            function createInputSelectField(labelText, placeholderText) {
                const inputContainer = document.createElement('div');
                Object.assign(inputContainer.style, {
                    display: "flex",
                    flexDirection: "column",
                    width: "100%"
                });

                const label = document.createElement('div');
                label.textContent = labelText;
                Object.assign(label.style, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    fontWeight: "600",
                    marginBottom: "0.35rem"
                });

                if (placeholderText === "Primary Tag") {
                    createCheckboxContainer("overwrite_primary_tag", "remove_primary_tag", label);
                } else if (placeholderText === "Release Date") {
                    createCheckboxContainer("overwrite_release_date", "remove_release_date", label);
                }

                inputContainer.appendChild(label);

                function createClearButton(select, field) {
                    const btn = document.createElement("span");
                    Object.assign(btn.style, {
                        display: "flex",
                        alignItems: "center",
                        cursor: "pointer",
                        padding: "8px",
                        flexShrink: "0"
                    });

                    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    svg.setAttribute("viewBox", "0 0 22 22");
                    svg.style.width = "0.75rem";
                    svg.style.height = "0.75rem";

                    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                    path.setAttribute(
                        "d",
                        "M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"
                    );

                    svg.appendChild(path);
                    btn.appendChild(svg);

                    btn.addEventListener("click", () => {
                        select.value = "";

                        if (placeholderText === "Primary Tag") creditsState.primaryTagsArray = [];
                        if (placeholderText === "Song Relationship") creditsState.relationshipArray = [];
                        if (placeholderText === "Language") creditsState.languageArray = [];
                        if (placeholderText === "Release Date") {
                            if (field === "month") creditsState.releaseDateArray[0].month = null;
                            if (field === "day") creditsState.releaseDateArray[0].day = null;
                            if (field === "year") creditsState.releaseDateArray[0].year = null;
                        }

                    });

                    return btn;
                }

                function createSelect(placeholder) {
                    const select = document.createElement("select");

                    Object.assign(select.style, {
                        appearance: "none",
                        background: "inherit",
                        margin: "0px 2px",
                        padding: "8px",
                        color: "rgb(0, 0, 0)",
                        fontSize: "0.85rem",
                        fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                        fontWeight: "100",
                        overflowY: "auto",
                        resize: "vertical",
                        flexGrow: "1",
                        minWidth: "0",
                        boxSizing: "border-box",
                        border: "none",
                        outline: "none"
                    });

                    const ph = document.createElement("option");
                    ph.value = "";
                    ph.disabled = true;
                    ph.selected = true;
                    ph.textContent = placeholder;
                    select.appendChild(ph);

                    return select;
                }

                if (placeholderText === "Release Date") {
                    const wrapperRelease = document.createElement("div");
                    Object.assign(wrapperRelease.style, {
                        display: "flex",
                        justifyContent: "space-between"
                    });

                    const wrapperStyle = {
                        display: "flex",
                        flexWrap: "wrap",
                        gap: "0.35rem",
                        alignItems: "center",
                        minHeight: "42px",
                        border: "1px solid",
                        position: "relative",
                        padding: "4px"
                    };

                    const wrapperMonth = document.createElement("div");
                    const wrapperDay = document.createElement("div");
                    const wrapperYear = document.createElement("div");

                    Object.assign(wrapperMonth.style, wrapperStyle);
                    Object.assign(wrapperDay.style, wrapperStyle);
                    Object.assign(wrapperYear.style, wrapperStyle);

                    const monthSelect = createSelect("Month");
                    [
                        "January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"
                    ].forEach((name, i) => {
                        const opt = document.createElement("option");
                        opt.value = i + 1;
                        opt.textContent = name;
                        monthSelect.appendChild(opt);
                    });

                    const daySelect = createSelect("Day");

                    const yearSelect = createSelect("Year");
                    const currentYear = new Date().getFullYear();
                    for (let y = currentYear + 1; y >= 1900; y--) {
                        const opt = document.createElement("option");
                        opt.value = y;
                        opt.textContent = y;
                        yearSelect.appendChild(opt);
                    }

                    const updateDays = () => {
                        const m = parseInt(monthSelect.value, 10);
                        const d = parseInt(daySelect.value, 10);
                        const y = parseInt(yearSelect.value, 10);

                        const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

                        const isLeap = y =>
                            (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;

                        if (m === 2 && isLeap(y)) daysInMonth[1] = 29;

                        const max = m ? daysInMonth[m - 1] : 31;

                        daySelect.replaceChildren();

                        const ph = document.createElement("option");
                        ph.value = "";
                        ph.disabled = true;
                        ph.selected = true;
                        ph.textContent = "Day";
                        daySelect.appendChild(ph);

                        for (let i = 1; i <= max; i++) {
                            const opt = document.createElement("option");
                            opt.value = i;
                            opt.textContent = i;
                            if (i === d) opt.selected = true;
                            daySelect.appendChild(opt);
                        }

                        if (d > max) daySelect.value = "";
                    };

                    function updateReleaseDateArray() {
                        creditsState.releaseDateArray = [{
                            month: monthSelect.value ? parseInt(monthSelect.value, 10) : null,
                            day: daySelect.value ? parseInt(daySelect.value, 10) : null,
                            year: yearSelect.value ? parseInt(yearSelect.value, 10) : null
                        }];
                    }

                    monthSelect.addEventListener("change", () => {
                        updateDays();
                        updateReleaseDateArray();
                    });

                    daySelect.addEventListener("change", () => {
                        updateDays();
                        updateReleaseDateArray();
                    });

                    yearSelect.addEventListener("change", () => {
                        updateDays();
                        updateReleaseDateArray();
                    });

                    updateDays();
                    updateReleaseDateArray();

                    wrapperMonth.appendChild(monthSelect);
                    wrapperMonth.appendChild(createClearButton(monthSelect, "month"));

                    wrapperDay.appendChild(daySelect);
                    wrapperDay.appendChild(createClearButton(daySelect, "day"));

                    wrapperYear.appendChild(yearSelect);
                    wrapperYear.appendChild(createClearButton(yearSelect, "year"));

                    wrapperRelease.appendChild(wrapperMonth);
                    wrapperRelease.appendChild(wrapperDay);
                    wrapperRelease.appendChild(wrapperYear);

                    inputContainer.appendChild(wrapperRelease);

                    return { inputContainer, monthSelect, daySelect, yearSelect };
                }

                const wrapper = document.createElement("div");
                Object.assign(wrapper.style, {
                    display: "flex",
                    alignItems: "center",
                    border: "1px solid",
                    padding: "4px",
                    minHeight: "2rem",
                    gap: "0.35rem"
                });

                const select = createSelect(placeholderText);

                const optionsArray = optionSets[placeholderText] || [];

                optionsArray.forEach(entry => {
                    const opt = document.createElement("option");
                    opt.value = entry.value;
                    opt.textContent = entry.label;
                    select.appendChild(opt);
                });

                if (placeholderText === "Primary Tag") {
                    select.addEventListener("change", () => {
                        creditsState.primaryTagsArray = [select.value];
                    });
                }

                if (placeholderText === "Song Relationship") {
                    select.addEventListener("change", () => {
                        creditsState.relationshipArray = [select.value];
                    });
                }

                if (placeholderText === "Language") {
                    select.addEventListener("change", () => {
                        creditsState.languageArray = [select.value];
                    });
                }

                wrapper.appendChild(select);
                wrapper.appendChild(createClearButton(select));
                inputContainer.appendChild(wrapper);

                return { inputContainer, select };
            }

            function createInputTextField(labelText, name, placeholder) {
                const inputContainer = document.createElement('div');
                Object.assign(inputContainer.style, {
                    display: "flex",
                    flexDirection: "column",
                    width: "100%"
                });

                const label = document.createElement('div');
                label.textContent = labelText;
                Object.assign(label.style, {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    fontWeight: "600",
                    marginBottom: "0.35rem"
                });

                if (name === 'youtube_links' || name === 'soundcloud_links' || name === 'related_album' || name === 'recorded_at') {
                    createCheckboxContainer(`overwrite_${name}`, `remove_${name}`, label);
                }

                const wrapper = document.createElement("div");
                Object.assign(wrapper.style, {
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "0.35rem",
                    minHeight: "2rem",
                    border: "1px solid",
                    padding: "4px",
                    alignItems: "center",
                    boxSizing: "border-box"
                });

                const input = document.createElement('input');
                input.type = 'text';
                input.name = name;
                input.placeholder = placeholder;
                Object.assign(input.style, {
                    appearance: "none",
                    background: "inherit",
                    margin: "0px 2px",
                    padding: "8px",
                    color: "rgb(0, 0, 0)",
                    fontSize: "0.85rem",
                    fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                    fontWeight: "100",
                    overflowY: "auto",
                    resize: "vertical",
                    display: "block",
                    width: "100%",
                    boxSizing: "border-box"
                });

                const feedbackLabel = document.createElement('div');
                Object.assign(feedbackLabel.style, {
                    paddingLeft: '8px',
                    fontSize: '0.75rem',
                    color: '#333',
                    display: 'none'
                });

                let cachedPlaylistLink = null;
                let cachedSongIds = null;
                let cachedAlbumTitle = null;

                input.addEventListener('input', async () => {
                    const link = input.value.trim();
                    const [playlistLink, playlistTracks] = link.split(' ');
                    feedbackLabel.style.display = 'block';

                    const checkedSongIds = songIds.filter((songId) => {
                        const checkbox = document.querySelector(`#checkbox_${songId}`);
                        return checkbox?.checked;
                    });

                    if (name === 'youtube_links') {
                        try {
                            if (playlistLink === "Delete") {
                                creditsState.youtubeLinks = "Delete";
                                feedbackLabel.style.color = '#FF1414';
                                feedbackLabel.textContent = 'Warning: Delete all YouTube links';
                            } else {
                                const playlistData = await getPlaylistVideos(playlistLink);
                                if (typeof playlistData === 'string') {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = `Error: ${playlistData}`;
                                } else {
                                    const totalTracks = playlistData.videoLinks.length;
                                    const selectedTracks = playlistTracks ? parsePlaylistTracks(playlistTracks, totalTracks) : [...Array(totalTracks).keys()];
                                    const filteredLinks = selectedTracks.map(index => playlistData.videoLinks[index]);

                                    const playlistLength = filteredLinks.length;
                                    const songCount = checkedSongIds.length;
                                    const trackLabel = playlistData.playlistLength === 1 ? "Track" : "Tracks";
                                    const linkLabel = playlistData.playlistLength === 1 ? "link" : "links";
                                    const songLabel = songCount === 1 ? "song" : "songs";

                                    if (playlistLength === songCount) {
                                        feedbackLabel.style.color = '#007A33';
                                        feedbackLabel.textContent = "";

                                        const strong = document.createElement("strong");
                                        strong.textContent = "Playlist:";

                                        const text = document.createTextNode(` ${playlistData.playlistTitle} [${playlistLength} Tracks]`);

                                        feedbackLabel.appendChild(strong);
                                        feedbackLabel.appendChild(text);

                                        creditsState.youtubeLinks = filteredLinks;
                                    } else {
                                        feedbackLabel.style.color = '#FF1414';
                                        feedbackLabel.textContent = "";

                                        const strong1 = document.createElement("strong");
                                        strong1.textContent = "Playlist:";
                                        feedbackLabel.appendChild(strong1);

                                        const text1 = document.createTextNode(` ${playlistData.playlistTitle} [${playlistLength} ${trackLabel}]`);
                                        feedbackLabel.appendChild(text1);
                                        feedbackLabel.appendChild(document.createElement("br"));

                                        const strong2 = document.createElement("strong");
                                        const warnSpan = document.createElement("span");
                                        warnSpan.style.backgroundColor = "#FFEB3B";
                                        warnSpan.style.color = "#333";
                                        warnSpan.style.padding = "2px 0px";
                                        warnSpan.textContent = "Warning:";
                                        strong2.appendChild(warnSpan);
                                        feedbackLabel.appendChild(strong2);

                                        const warnText = document.createElement("span");
                                        warnText.style.color = "#333";
                                        warnText.textContent = ` The playlist has ${playlistLength} ${linkLabel}, but the album has ${songCount} ${songLabel}.`;
                                        feedbackLabel.appendChild(warnText);
                                    }
                                }
                            }
                        } catch (error) {
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = `Error: ${error.message}`;
                        }
                    } else if (name === 'soundcloud_links') {
                        feedbackLabel.style.color = '#FF1414';
                        feedbackLabel.textContent = "Error: SoundCloud links are not supported";
                    } else if (name === 'related_album') {
                        try {
                            if (playlistLink === "Delete") {
                                creditsState.geniusLinks = Array(checkedSongIds.length).fill("Delete");
                                feedbackLabel.style.color = '#FF1414';
                                feedbackLabel.textContent = 'Warning: Delete all related songs';
                            } else {
                                if (!playlistLink.startsWith("https://genius.com/albums")) {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = "Error: Invalid playlist link";
                                    return;
                                }
                                if (playlistLink !== cachedPlaylistLink || !cachedSongIds) {
                                    const html = await (await fetch(playlistLink)).text();
                                    console.log(html);

                                    cachedAlbumTitle = (html.match(/\\\"nameWithArtist\\\":\\\"(.*?)\\\",\\"name\\\":\\\"(.*?)\\\"/) || [])[2];
                                    cachedSongIds = [];
                                    const appearancesMatch = html.match(/\\"albumAppearances\\":\{([\s\S]*?)\}(?=,\\"[a-zA-Z])/);

                                    if (appearancesMatch) {
                                        const cleaned = appearancesMatch[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\');
                                        const albumAppearances = JSON.parse("{" + cleaned + "}");

                                        cachedSongIds = Object.values(albumAppearances)
                                            .sort((a, b) => a.trackNumber - b.trackNumber)
                                            .map(entry => entry.song);
                                    }
                                    cachedPlaylistLink = playlistLink;
                                }
                                const totalTracks = cachedSongIds.length;
                                const selectedTracks = playlistTracks ? parsePlaylistTracks(playlistTracks, totalTracks) : [...Array(totalTracks).keys()];
                                const filteredSongIds = selectedTracks.map(index => cachedSongIds[index]);

                                const playlistLength = filteredSongIds.length;
                                const songCount = checkedSongIds.length;

                                const trackLabel = playlistLength === 1 ? "Track" : "Tracks";
                                const linkLabel = playlistLength === 1 ? "link" : "links";
                                const songLabel = songCount === 1 ? "song" : "songs";

                                if (playlistLength === songCount) {
                                    feedbackLabel.style.color = '#007A33';
                                    feedbackLabel.textContent = "";

                                    const strong = document.createElement("strong");
                                    strong.textContent = "Playlist:";
                                    feedbackLabel.appendChild(strong);

                                    const text = document.createTextNode(` ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]`);
                                    feedbackLabel.appendChild(text);

                                    creditsState.geniusLinks = filteredSongIds;
                                } else {
                                    feedbackLabel.style.color = '#FF1414';
                                    feedbackLabel.textContent = "";

                                    const strong1 = document.createElement("strong");
                                    strong1.textContent = "Playlist:";
                                    feedbackLabel.appendChild(strong1);

                                    const text1 = document.createTextNode(` ${cachedAlbumTitle} [${playlistLength} ${trackLabel}]`);
                                    feedbackLabel.appendChild(text1);

                                    feedbackLabel.appendChild(document.createElement("br"));

                                    const strong2 = document.createElement("strong");
                                    const warnSpan = document.createElement("span");
                                    warnSpan.style.backgroundColor = "#FFEB3B";
                                    warnSpan.style.color = "#333";
                                    warnSpan.style.padding = "2px 0px";
                                    warnSpan.textContent = "Warning:";
                                    strong2.appendChild(warnSpan);
                                    feedbackLabel.appendChild(strong2);

                                    const warnText = document.createElement("span");
                                    warnText.style.color = "#333";
                                    warnText.textContent = ` The playlist has ${playlistLength} ${linkLabel}, but the album only has ${songCount} ${songLabel}.`; feedbackLabel.appendChild(warnText);
                                }
                            }
                        } catch (error) {
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = `Error: ${error.message}`;
                        }
                    } else if (name === 'recorded_at') {
                        if (link === "Delete") {
                            creditsState.recordedArray = "Delete";
                            feedbackLabel.style.color = '#FF1414';
                            feedbackLabel.textContent = 'Warning: Delete all Recording Locations';
                        } else {
                            creditsState.recordedArray = link;
                            feedbackLabel.textContent = '';
                            feedbackLabel.style.display = 'none';
                        }
                    }
                });


                function parsePlaylistTracks(input, totalTracks) {
                    const selectedTracks = new Set();
                    let isInverted = false;

                    if (input.startsWith('!')) {
                        isInverted = true;
                        input = input.slice(1);
                    }

                    input.split(',').forEach(range => {
                        const [start, end] = range.split('-').map(Number);
                        if (!end) {
                            selectedTracks.add(start - 1);
                        } else {
                            for (let i = start - 1; i < end; i++) {
                                selectedTracks.add(i);
                            }
                        }
                    });

                    if (isInverted) {
                        return [...Array(totalTracks).keys()].filter(i => !selectedTracks.has(i));
                    } else {
                        return [...selectedTracks].sort((a, b) => a - b);
                    }
                }

                async function getPlaylistVideos(playlistLink) {
                    const possibleLinks = ["https://www.youtube.com/playlist", "https://youtube.com/playlist", "https://music.youtube.com/playlist"];
                    if (!possibleLinks.some((link) => playlistLink.startsWith(link))) {
                        return "Invalid playlist link";
                    }

                    const playlistId = new URL(playlistLink).searchParams.get("list");
                    const key = window.secrets.GOOGLE_API_KEY;

                    const metadataResponse = await fetch(`https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=${playlistId}&key=${key}`);
                    if (!metadataResponse.ok) {
                        return "Failed to fetch playlist metadata";
                    }

                    const metadataData = (await metadataResponse.json()).items[0].snippet;

                    let videosData;
                    let videoLinks = [];
                    let nextPageToken = '';

                    do {
                        const videosResponse = await fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&pageToken=${nextPageToken}&playlistId=${playlistId}&key=${key}`);
                        if (!videosResponse.ok) {
                            return "Failed to fetch playlist videos";
                        }

                        videosData = await videosResponse.json();
                        videoLinks.push(...videosData.items.map(item => `https://www.youtube.com/watch?v=${item.snippet.resourceId.videoId}`));
                        nextPageToken = videosData.nextPageToken;
                    } while (nextPageToken);


                    return {
                        artistName: metadataData.channelTitle,
                        playlistTitle: metadataData.title.startsWith("Album - ")
                            ? metadataData.title.substring("Album - ".length)
                            : metadataData.title,
                        playlistLength: videoLinks.length,
                        videoLinks
                    };
                }

                wrapper.appendChild(input);

                inputContainer.appendChild(label);
                inputContainer.appendChild(wrapper);
                inputContainer.appendChild(feedbackLabel);

                return { inputContainer };
            }

            function createInputTagField(labelText, name, type) {
                const inputContainer = document.createElement('div');
                Object.assign(inputContainer.style, {
                    display: "flex",
                    flexDirection: "column",
                    width: "100%"
                });

                const label = document.createElement('div');
                label.textContent = labelText;
                Object.assign(label.style, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    fontWeight: "600",
                    marginBottom: "0.35rem"
                });

                if (name === 'primary_artists' || name === 'featured_artists' || name === 'tags' || name === 'writers' || name === 'producers' || name.startsWith("additional_role_")) {
                    createCheckboxContainer(`overwrite_${name}`, `remove_${name}`, label);
                } else if (name.startsWith("artist_role_")) {
                    createRemoveContainer(`remove_${name}`, label);
                }

                const wrapper = document.createElement("div");
                Object.assign(wrapper.style, {
                    display: "flex",
                    flexWrap: "wrap",
                    minHeight: "2rem",
                    cursor: "text",
                    border: "1px solid",
                    padding: "4px"
                });

                const tagsList = document.createElement("div");
                Object.assign(tagsList.style, {
                    display: "contents"
                });

                const inputField = document.createElement('input');
                inputField.type = 'text';
                inputField.placeholder = `Add ${labelText}`;
                Object.assign(inputField.style, {
                    appearance: "none",
                    background: "inherit",
                    margin: "0px 2px",
                    padding: "8px",
                    color: "rgb(0, 0, 0)",
                    fontSize: "0.85rem",
                    fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                    fontWeight: "100",
                    overflowY: "auto",
                    resize: "vertical",
                    display: "block",
                    width: "100%",
                    boxSizing: "border-box"
                });

                function addTag(text) {
                    const tag = document.createElement("div");
                    Object.assign(tag.style, {
                        display: "flex",
                        alignItems: "center",
                        background: "#eee",
                        padding: "0.15rem 0.35rem",
                        borderRadius: "3px",
                        fontSize: "0.85rem"
                    });

                    const span = document.createElement("span");
                    span.textContent = text;

                    const remove = document.createElement("div");
                    remove.textContent = "×";
                    Object.assign(remove.style, {
                        marginLeft: "0.35rem",
                        cursor: "pointer",
                        fontWeight: "bold"
                    });

                    remove.addEventListener("click", () => tag.remove());

                    tag.appendChild(span);
                    tag.appendChild(remove);
                    tagsList.appendChild(tag);
                }

                inputField.addEventListener("keydown", (e) => {
                    if (e.key === "Backspace" && inputField.value === "") {
                        const lastTag = tagsList.lastElementChild;
                        if (!lastTag) return;

                        tagsList.removeChild(lastTag);

                        const tagId = Number(lastTag.getAttribute("data-id"));
                        let arrayToUpdate;

                        const match = name.match(/_(\d+)$/);
                        const fieldIndex = match ? parseInt(match[1], 10) : null;

                        if (name.startsWith('additional_role_') && fieldIndex !== null) {
                            arrayToUpdate = creditsState.additionalRolesArray[fieldIndex];
                        } else if (name.startsWith('artist_role_') && fieldIndex !== null) {
                            arrayToUpdate = creditsState.artistRolesArray[fieldIndex];
                        } else if (name === 'primary_artists') {
                            arrayToUpdate = creditsState.primaryArtistsArray;
                        } else if (name === 'featured_artists') {
                            arrayToUpdate = creditsState.featuredArtistsArray;
                        } else if (name === 'tags') {
                            arrayToUpdate = creditsState.secondaryTagsArray;
                        } else if (name === 'writers') {
                            arrayToUpdate = creditsState.writersArray;
                        } else if (name === 'producers') {
                            arrayToUpdate = creditsState.producersArray;
                        }

                        if (arrayToUpdate) {
                            const tagIndex = arrayToUpdate.findIndex(tag => tag.id === tagId);
                            if (tagIndex !== -1) {
                                arrayToUpdate.splice(tagIndex, 1);
                            }
                        }
                    }
                });


                inputField.addEventListener("input", async () => {
                    const query = inputField.value.trim();
                    const existing = wrapper.querySelector(".autocomplete");
                    if (existing) existing.remove();

                    if (query.length < 2) return;

                    const suggestions = await fetchSuggestions(type, query);
                    displaySuggestions(suggestions, wrapper, inputField, name, type, tagsList);
                });

                wrapper.appendChild(tagsList);
                wrapper.appendChild(inputField);

                inputContainer.appendChild(label);
                inputContainer.appendChild(wrapper);

                return { inputContainer, tagsList };
            }

            function displaySuggestions(suggestions, container, inputField, name, type, tagsList) {
                const existingSuggestions = container.querySelector('.autocomplete');
                if (existingSuggestions) existingSuggestions.remove();

                if (suggestions.length === 0) return;

                const autocompleteDiv = document.createElement('div');
                autocompleteDiv.className = 'autocomplete';

                Object.assign(container.style, {
                    position: "relative"
                });

                Object.assign(autocompleteDiv.style, {
                    position: "absolute",
                    top: "102%",
                    left: "0",
                    width: "100%",
                    background: "white",
                    border: "1px solid #ccc",
                    zIndex: "9999",
                    boxSizing: "border-box"
                });

                const suggestionList = document.createElement('ul');
                suggestionList.className = 'suggestion-list';

                let mouseMoved = false;
                let selectedIndex = 0;

                function highlight(item) {
                    item.style.backgroundColor = "rgb(233, 233, 233)";
                }

                function unhighlight(item) {
                    item.style.backgroundColor = "transparent";
                }

                suggestions.forEach((item, index) => {
                    const suggestionItem = document.createElement('li');
                    suggestionItem.className = 'suggestion-item';

                    Object.assign(suggestionItem.style, {
                        padding: "0rem 0.5rem",
                        margin: "0px 2px",
                        cursor: "pointer"
                    });

                    const text = document.createElement('span');
                    text.textContent = item.name || item.label;
                    suggestionItem.appendChild(text);

                    const valueToAdd = type === 'custom_performance_roles' ? { id: item.id, label: item.label } : { id: item.id, name: item.name };

                    suggestionItem.addEventListener('click', () => {
                        if (!valueToAdd) return;

                        let arrayToUpdate;

                        const match = name.match(/_(\d+)$/);
                        const fieldIndex = match ? parseInt(match[1], 10) : null;

                        if (name === 'tags') {
                            arrayToUpdate = creditsState.secondaryTagsArray;
                        } else if (name === 'primary_artists') {
                            arrayToUpdate = creditsState.primaryArtistsArray;
                        } else if (name === 'featured_artists') {
                            arrayToUpdate = creditsState.featuredArtistsArray;
                        } else if (name === 'producers') {
                            arrayToUpdate = creditsState.producersArray;
                        } else if (name === 'writers') {
                            arrayToUpdate = creditsState.writersArray;
                        } else if (name.startsWith('additional_role_') && fieldIndex !== null) {
                            if (!creditsState.additionalRolesArray[fieldIndex]) creditsState.additionalRolesArray[fieldIndex] = [];
                            arrayToUpdate = creditsState.additionalRolesArray[fieldIndex];
                        } else if (name.startsWith('artist_role_') && fieldIndex !== null) {
                            if (!creditsState.artistRolesArray[fieldIndex]) creditsState.artistRolesArray[fieldIndex] = [];
                            arrayToUpdate = creditsState.artistRolesArray[fieldIndex];
                        }

                        if (arrayToUpdate && !arrayToUpdate.some(x => x.id === valueToAdd.id)) {
                            arrayToUpdate.push(valueToAdd);
                        }

                        addTag(tagsList, valueToAdd, name);

                        inputField.value = '';
                        inputField.focus();
                        autocompleteDiv.remove();
                        document.removeEventListener('keydown', keyboardListener);
                    });

                    suggestionItem.addEventListener('mouseenter', () => {
                        if (!mouseMoved) return;
                        suggestionList.querySelectorAll('.suggestion-item').forEach(i => unhighlight(i));
                        highlight(suggestionItem);
                        selectedIndex = index;
                    });

                    suggestionList.appendChild(suggestionItem);

                    if (index === 0) {
                        highlight(suggestionItem);
                        selectedIndex = 0;
                    }
                });

                suggestionList.addEventListener('mousemove', () => {
                    mouseMoved = true;
                });

                autocompleteDiv.appendChild(suggestionList);
                container.appendChild(autocompleteDiv);

                let keyboardListener;

                setupKeyboardNavigation();

                document.addEventListener('mousedown', (event) => {
                    if (!autocompleteDiv.contains(event.target) && event.target !== inputField) {
                        autocompleteDiv.remove();
                        document.removeEventListener('keydown', keyboardListener);
                    }
                });

                function setupKeyboardNavigation() {
                    if (keyboardListener) {
                        document.removeEventListener('keydown', keyboardListener);
                    }

                    keyboardListener = (event) => {
                        const items = document.querySelectorAll('.suggestion-item');
                        if (!items.length) return;

                        if (event.key === 'ArrowDown') {
                            mouseMoved = false;
                            selectedIndex = (selectedIndex + 1) % items.length;
                            items.forEach(i => unhighlight(i));
                            highlight(items[selectedIndex]);
                            event.preventDefault();
                        } else if (event.key === 'ArrowUp') {
                            mouseMoved = false;
                            selectedIndex = (selectedIndex - 1 + items.length) % items.length;
                            items.forEach(i => unhighlight(i));
                            highlight(items[selectedIndex]);
                            event.preventDefault();
                        } else if (event.key === 'Enter') {
                            event.preventDefault();
                            const selectedItem = items[selectedIndex];
                            if (selectedItem) {
                                selectedItem.click();
                                autocompleteDiv?.remove();
                                selectedIndex = 0
                            }
                        }
                    };

                    document.addEventListener('keydown', keyboardListener);
                }
            }

            function addTag(tagsList, tagObject, name) {
                const existingTags = Array.from(tagsList.querySelectorAll('.tag-item'));
                const isDuplicate = existingTags.some(tag => tag.getAttribute('data-id') === String(tagObject.id));
                if (isDuplicate) return;

                const tagItem = document.createElement('li');
                tagItem.className = 'tag-item';
                tagItem.setAttribute('data-id', tagObject.id);
                tagItem.setAttribute('data-name', tagObject.name || tagObject.label);

                Object.assign(tagItem.style, {
                    backgroundColor: "rgb(233, 233, 233)",
                    borderRadius: "0px",
                    display: "flex",
                    alignItems: "center",
                    margin: "2px",
                    minWidth: "0px",
                    border: "1px solid rgb(0, 0, 0)",
                    padding: "0.125rem 0.5rem",
                    gap: "0.35rem",
                    fontSize: "0.85rem",
                    fontWeight: "100"
                });

                const tagText = document.createElement('span');
                tagText.textContent = tagObject.name || tagObject.label;

                const removeButton = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                removeButton.setAttribute("viewBox", "0 0 22 22");
                removeButton.style.width = "0.5rem";
                removeButton.style.height = "0.5rem";
                removeButton.style.cursor = "pointer";

                const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                path.setAttribute("d", "M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39");
                path.style.fill = "black";

                removeButton.appendChild(path);

                removeButton.addEventListener('click', (event) => {
                    event.stopPropagation();
                    tagsList.removeChild(tagItem);

                    let arrayToUpdate;

                    const match = name.match(/_(\d+)$/);
                    const fieldIndex = match ? parseInt(match[1], 10) : null;

                    if (name.startsWith('additional_role_') && fieldIndex !== null) {
                        arrayToUpdate = creditsState.additionalRolesArray[fieldIndex];
                    } else if (name.startsWith('artist_role_') && fieldIndex !== null) {
                        arrayToUpdate = creditsState.artistRolesArray[fieldIndex];
                    } else if (name === 'primary_artists') {
                        arrayToUpdate = creditsState.primaryArtistsArray;
                    } else if (name === 'featured_artists') {
                        arrayToUpdate = creditsState.featuredArtistsArray;
                    } else if (name === 'tags') {
                        arrayToUpdate = creditsState.secondaryTagsArray;
                    } else if (name === 'writers') {
                        arrayToUpdate = creditsState.writersArray;
                    } else if (name === 'producers') {
                        arrayToUpdate = creditsState.producersArray;
                    }

                    if (arrayToUpdate) {
                        const tagIndex = arrayToUpdate.findIndex(tag => tag.id === tagObject.id);
                        if (tagIndex !== -1) {
                            arrayToUpdate.splice(tagIndex, 1);
                        }
                    }
                });

                tagItem.appendChild(tagText);
                tagItem.appendChild(removeButton);
                tagsList.appendChild(tagItem);
            }

            function createAdditionalCreditsField() {
                const additionalContainer = document.createElement('div');
                Object.assign(additionalContainer.style, {
                    display: "flex",
                    flexDirection: "column",
                    width: "100%",
                    margin: "1.75rem 0rem"
                });

                const subSectionCreditsContainer = document.createElement('div');
                Object.assign(subSectionCreditsContainer.style, {
                    display: "flex",
                    flexDirection: "column",
                    gap: "1.25rem"
                });

                additionalContainer.appendChild(subSectionCreditsContainer);

                const initialSubSectionCredits = createAdditionalRoles();
                subSectionCreditsContainer.appendChild(initialSubSectionCredits);

                const addCreditsButton = document.createElement('span');
                addCreditsButton.textContent = '+ Add Additional Credits';

                Object.assign(addCreditsButton.style, {
                    display: "flex",
                    borderRadius: "1.25rem",
                    padding: "0.5rem 1.25rem",
                    border: "1px solid rgb(0, 0, 0)",
                    fontFamily: `Programme, "Programme Pan", Arial, sans-serif`,
                    fontSize: "0.85rem",
                    fontWeight: "100",
                    color: "rgb(0, 0, 0)",
                    cursor: "pointer",
                    margin: "1.25rem 0rem 140px 0px",
                    alignSelf: "flex-start"
                });

                addCreditsButton.addEventListener('click', () => {
                    const newSubSectionCredits = createAdditionalRoles();
                    subSectionCreditsContainer.appendChild(newSubSectionCredits);
                    newSubSectionCredits.scrollIntoView({ behavior: "smooth", block: "start" });
                });

                additionalContainer.appendChild(addCreditsButton);

                return additionalContainer;
            }

            function createAdditionalRoles() {
                const subSection = document.createElement('div');
                subSection.setAttribute('data-index', creditsState.roleIndex);

                const tracklist = createMiniTracklist(songIds, creditsState.roleIndex, trackNumbers, rawTrackNumbers);
                tracklist.classList.add("miniTracklist");
                const toggleButton = document.querySelector("#tracklist_individual");
                const isIndividualMode = toggleButton ? toggleButton._checked : false;
                tracklist.style.display = isIndividualMode ? "block" : "none";
                subSection.appendChild(tracklist);

                const row = document.createElement("div");
                Object.assign(row.style, {
                    display: "flex",
                    gap: "1.5rem",
                    width: "100%"
                });
                subSection.appendChild(row);

                const { inputContainer: additionalRoleDiv, tagsList: additionalRoleTagsList } =
                    createInputTagField(
                        'Additional role',
                        `additional_role_${creditsState.roleIndex}`,
                        'custom_performance_roles'
                    );

                additionalRoleDiv.setAttribute('data-index', creditsState.roleIndex);
                row.appendChild(additionalRoleDiv);

                const additionalRoleInputField = [...additionalRoleDiv.querySelectorAll('input')].pop();
                additionalRoleInputField.addEventListener('focus', () => {
                    creditsState.activeTagsList = additionalRoleTagsList;
                });

                const { inputContainer: artistRoleDiv, tagsList: artistRoleTagsList } =
                    createInputTagField(
                        'Artists in this role',
                        `artist_role_${creditsState.roleIndex}`,
                        'artists'
                    );

                artistRoleDiv.setAttribute('data-index', creditsState.roleIndex);
                row.appendChild(artistRoleDiv);

                const artistRoleInputField = artistRoleDiv.querySelector('input');
                artistRoleInputField.addEventListener('focus', () => {
                    creditsState.activeTagsList = artistRoleTagsList;
                });

                creditsState.additionalCreditsArray.push(creditsState.roleIndex);
                creditsState.roleIndex++;
                return subSection;
            }


            function syncTracklists(listA, listB) {
                const boxesA = listA.querySelectorAll(".styled-checkbox");
                const boxesB = listB.querySelectorAll(".styled-checkbox");

                let isSyncing = false;

                boxesA.forEach((boxA, i) => {
                    const boxB = boxesB[i];

                    boxA.addEventListener("change", () => {
                        if (isSyncing) return;
                        isSyncing = true;

                        boxB.checked = boxA.checked;
                        boxB.dispatchEvent(new Event("change"));

                        isSyncing = false;
                    });

                    boxB.addEventListener("change", () => {
                        if (isSyncing) return;
                        isSyncing = true;

                        boxA.checked = boxB.checked;
                        boxA.dispatchEvent(new Event("change"));

                        isSyncing = false;
                    });
                });
            }

            function observeFormWidth(form, controls) {
                const apply = () => {
                    if (window.innerWidth >= 1526) {
                        form.style.maxWidth = "900px";
                        controls.style.left = "calc(50% + 450px + 0.75rem)";

                    } else {
                        form.style.maxWidth = "800px";
                        controls.style.left = "calc(50% + 400px + 0.75rem)";

                    }
                };

                apply();

                window.addEventListener("resize", apply);

                const observer = new MutationObserver(apply);
                observer.observe(form, {
                    attributes: true,
                    attributeFilter: ["style"]
                });

                return {
                    stop: () => {
                        observer.disconnect();
                        window.removeEventListener("resize", apply);
                    }
                };
            }


            function createMainCredits(page1, trackNumbers, rawTrackNumbers) {
                const tracklist1 = createTracklist(songIds, trackNumbers, rawTrackNumbers, false);

                const primaryArtistField = createInputTagField("Primary Artists", "primary_artists", "artists");
                const featuredArtistField = createInputTagField("Featured Artists", "featured_artists", "artists");
                const producerField = createInputTagField("Producers", "producers", "artists");
                const writerField = createInputTagField("Writers", "writers", "artists");
                const youtubeField = createInputTextField('YouTube URL', 'youtube_links', 'YouTube Playlist URL');
                const soundcloudField = createInputTextField('SoundCloud URL', 'soundcloud_links', 'SoundCloud Playlist URL');
                const primaryTagField = createInputSelectField("Primary Tag", "Primary Tag");
                const secondaryTagField = createInputTagField('Tags', 'tags', 'tags');
                const releaseDateField = createInputSelectField("Release Date", "Release Date");
                const recordedAtField = createInputTextField('Recorded At', 'recorded_at', 'Add Recording Location');
                const songRelationshipField = createInputSelectField("Song Relationship", "Song Relationship");
                const relatedAlbumField = createInputTextField('Related album', 'related_album', 'Genius Album URL');
                const languageField = createInputSelectField("Language", "Language");

                const row1 = createRow(primaryArtistField, featuredArtistField);
                const row2 = createRow(producerField, writerField);
                const row3 = createRow(youtubeField);
                const row4 = createRow(primaryTagField, secondaryTagField);
                const row5 = createRow(releaseDateField, recordedAtField);
                const row6 = createRow(songRelationshipField, relatedAlbumField, languageField);

                page1.appendChild(tracklist1);
                page1.appendChild(row1);
                page1.appendChild(row2);
                page1.appendChild(row3);
                page1.appendChild(row4);
                page1.appendChild(row5);
                page1.appendChild(row6);

                return tracklist1
            }

            function createAdditionalCredits(page2, trackNumbers, rawTrackNumbers) {
                const tracklist2 = createTracklist(songIds, trackNumbers, rawTrackNumbers, true);

                const additionalCreditField = createAdditionalCreditsField();

                page2.appendChild(tracklist2);
                page2.appendChild(additionalCreditField);

                return tracklist2
            }


            const { overlay, form } = createForm();
            const { controls, saveButton, cancelButton } = createControls(overlay);
            const { page1, page2, status } = createContent(form);

            const tracklist1 = createMainCredits(page1, trackNumbers, rawTrackNumbers);
            const tracklist2 = createAdditionalCredits(page2, trackNumbers, rawTrackNumbers);

            syncTracklists(tracklist1, tracklist2);

            const formWidth = observeFormWidth(form, controls);

            document.body.appendChild(overlay);

            return { overlay, form, saveButton, cancelButton, status, stopObservers: formWidth.stop };
        }

    }




    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                             TRACKLIST LYRIC STATE                              //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function lyricStateTracklistOld(userRoles, songDataArray) {
        if (!Array.isArray(songDataArray)) return;

        songDataArray.forEach(entry => {
            const songData = entry?.response?.song;
            if (!songData || !songData.url) return;

            const linkElement = document.querySelector(`a[href="${songData.url}"]`);
            if (!linkElement) return;

            const chartRow = linkElement.closest('.chart_row.chart_row--light_border.chart_row--full_bleed_left.chart_row--align_baseline.chart_row--no_hover');
            if (!chartRow) return;

            const metadataElement = chartRow.querySelector('.chart_row-metadata_element.chart_row-metadata_element--large.drop-target');
            const expandElement = chartRow.querySelector('.chart_row-expand.u-increase_tap_area_full_space');
            if (!expandElement) return;

            if (chartRow.querySelector('.lyric-status-box')) return;

            // Lyrics are marked complete, staff approved, or verified
            const lyricsAreValidated = songData.lyrics_marked_complete_by || songData.lyrics_marked_staff_approved_by || songData.lyrics_verified === true;

            let color = '#ff7878';
            if (userRoles.includes('transcriber') || userRoles.includes('editor') || userRoles.includes('moderator')) {
                if (lyricsAreValidated && songData.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {
                    color = '#99f2a5';
                } else if (songData.lyrics_state === 'complete' && songData.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {
                    color = '#ffff64';
                } else if (songData.lyrics_state === 'complete' && songData.current_user_metadata?.permissions?.includes("award_transcription_iq")) {
                    color = '#ffa335';
                }
            } else {
                if (lyricsAreValidated) {
                    color = '#99f2a5';
                } else if (songData.lyrics_state === 'complete') {
                    color = '#ffff64';
                }
            }

            const box = document.createElement('div');
            box.className = 'lyric-status-box';
            box.style.width = '1rem';
            box.style.backgroundColor = color;
            box.style.marginLeft = '0.75rem';
            box.style.marginRight = '-1.00rem';
            box.style.flexShrink = '0';
            box.style.alignSelf = 'center';

            chartRow.style.display = 'flex';
            chartRow.style.alignItems = 'center';

            if (metadataElement && metadataElement.nextSibling === expandElement) {
                chartRow.insertBefore(box, expandElement);
            } else {
                chartRow.insertBefore(box, expandElement);
            }

            const contentContainer = chartRow.querySelector('.chart_row-content');
            if (contentContainer) {
                const contentHeight = contentContainer.getBoundingClientRect().height;
                box.style.height = `${contentHeight}px`;
            }
        });
    }

    function lyricStateTracklist(songData, userRole) {
        console.log("Run function lyricStateTracklist()");

        songData.forEach(song => {
            const trackContainer = document.querySelector(
                `a[href="${song.url}"]`
            )?.closest('div[class^="Track__Container-"]');
            if (!trackContainer) return;

            const creditsButton = trackContainer.querySelector(
                'button[class*="Track__CreditsToggle"]'
            );
            if (!creditsButton) return;

            creditsButton.style.marginLeft = "0.55rem";

            const lyricsAreValidated = song.lyrics_marked_complete_by || song.lyrics_marked_staff_approved_by || song.lyrics_verified === true;

            let color = '#ff7878';
            if (userRole === 'transcriber' || userRole === 'editor' || userRole === 'moderator') {
                if (lyricsAreValidated &&
                    song.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {
                    color = '#99f2a5';
                } else if (song.lyrics_state === 'complete' &&
                    song.current_user_metadata?.excluded_permissions?.includes("award_transcription_iq")) {
                    color = '#ffff64';
                } else if (song.lyrics_state === 'complete' &&
                    song.current_user_metadata?.permissions?.includes("award_transcription_iq")) {
                    color = '#ffa335';
                }
            } else {
                if (lyricsAreValidated) {
                    color = '#99f2a5';
                } else if (song.lyrics_state === 'complete') {
                    color = '#ffff64';
                }
            }

            const applyCircle = () => {
                const svg = creditsButton.querySelector('svg');
                if (!svg) return;

                svg.style.display = 'inline-block';
                svg.style.backgroundColor = color;
                svg.style.borderRadius = '50%';
                svg.style.padding = '0.375rem';
                svg.style.boxSizing = 'content-box';

                if (song.pending_lyrics_edits_count > 0) {
                    svg.style.filter = 'drop-shadow(0 0 6px #000)';
                } else {
                    svg.style.filter = '';
                }

                const expandAllBtn = document.querySelector('button[data-expand-btn="true"]');
                if (expandAllBtn) {
                    expandAllBtn.style.marginRight = "0.375rem";
                }
            };

            applyCircle();

            const observer = new MutationObserver(() => applyCircle());
            observer.observe(creditsButton, { childList: true, subtree: true });
        });
    }





    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                CLEANUP METADATA                                //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function cleanupMetadataOld(userId, userRoles, songList) {
        let songsWithZeroWidthSpace = [];
        let songsWithRenamedLabels = [];
        let songsWithWriterArtists = [];
        let songsWithDuplicateCoverArt = [];

        const coverArtUsageMap = new Map();

        songList.forEach(json => {
            const song = json.response.song;

            if (checkZeroWidthSpaces(song)) songsWithZeroWidthSpace.push(song);
            const needsLabelRename = checkLabelRenames(song);
            const needsWritersAdd = checkWriterArtists(song);


            if (needsLabelRename) {
                songsWithRenamedLabels.push(needsLabelRename);
            }
            if (needsWritersAdd) {
                songsWithWriterArtists.push(needsWritersAdd);
            }

            const coverUrl = song.custom_song_art_image_url;
            if (coverUrl) {
                if (!coverArtUsageMap.has(coverUrl)) {
                    coverArtUsageMap.set(coverUrl, []);
                }
                coverArtUsageMap.get(coverUrl).push(song);
            }
        });

        for (const [coverUrl, songs] of coverArtUsageMap.entries()) {
            if (songs.length > 1) {
                const singleAlbumSongs = songs.filter(song => song.albums?.length === 1);
                if (singleAlbumSongs.length > 0) {
                    console.log(`Cover URL: ${coverUrl}`);
                    singleAlbumSongs.forEach(song => {
                        console.log(`- ${song.title} (ID: ${song.id})`);
                        songsWithDuplicateCoverArt.push(song);
                    });
                }
            }
        }

        addCleanupButtonOld(songsWithZeroWidthSpace, "ZWSP", "Remove ZWSP", { title: "remove_zwsp" });
        addCleanupButtonOld(songsWithRenamedLabels, "LabelRenames", "Fix Metadata", { renameLabels: true });
        addCleanupButtonOld(songsWithWriterArtists, "Writers", "Add Writers", { writerArtists: true });
        if (userRoles.includes('transcriber') || userRoles.includes('editor') || userRoles.includes('moderator')) {
            addCleanupButtonOld(songsWithDuplicateCoverArt, "CoverArt", "Remove Cover Art", { coverArt: true });
        }
    }





    function cleanupMetadata(songData, userRole) {
        console.log("Run function cleanupMetadata()");

        let songsWithRenamedLabels = [];
        let songsWithWriterArtists = [];
        let songsWithDuplicateCoverArt = [];

        const coverArtUsageMap = new Map();

        songData.forEach(song => {
            const needsLabelRename = checkLabelRenames(song);
            const needsWritersAdd = checkWriterArtists(song);

            if (needsLabelRename) {
                songsWithRenamedLabels.push(needsLabelRename);
            }
            if (needsWritersAdd) {
                songsWithWriterArtists.push(needsWritersAdd);
            }

            const coverUrl = song.custom_song_art_image_url;
            if (coverUrl) {
                if (!coverArtUsageMap.has(coverUrl)) {
                    coverArtUsageMap.set(coverUrl, []);
                }
                coverArtUsageMap.get(coverUrl).push(song);
            }
        });

        for (const [coverUrl, songs] of coverArtUsageMap.entries()) {
            if (songs.length > 1) {
                const singleAlbumSongs = songs.filter(song => song.albums?.length === 1);
                if (singleAlbumSongs.length > 0) {
                    console.log(`Cover URL: ${coverUrl}`);
                    singleAlbumSongs.forEach(song => {
                        console.log(`- ${song.title} (ID: ${song.id})`);
                        songsWithDuplicateCoverArt.push(song);
                    });
                }
            }
        }

        addCleanupButton(songsWithRenamedLabels, "LabelRenames", "Fix Metadata", { renameLabels: true });
        addCleanupButton(songsWithWriterArtists, "Writers", "Add Writers", { writerArtists: true });
        if (userRole === 'transcriber' || userRole === 'editor' || userRole === 'moderator') {
            addCleanupButton(songsWithDuplicateCoverArt, "CoverArt", "Remove Cover Art", { coverArt: true });
        }
    }



    function checkZeroWidthSpaces(song) {
        let updatedTitle = song.title;

        updatedTitle = updatedTitle.replace(/\u200B{2,}/g, '\u200B');
        updatedTitle = updatedTitle.replace(/^\u200B|(?<=[\p{L}\p{N}\p{P}])\u200B|(?=[\p{L}\p{N}\p{P}])\u200B/gu, '');

        //        updatedTitle = updatedTitle.replace(/(?<=[\p{L}\p{N}\p{P}])\u200B|(?=[\p{L}\p{N}\p{P}])\u200B/gu, '');

        if (/\u200B/.test(updatedTitle)) {
            console.info(`Remaining ZWSP: "${updatedTitle}"`);
        }

        return song.title !== updatedTitle;
    }

    function checkLabelRenames(song) {
        const labelRenames = {
            //"Wrong": "Correct",
        };

        const customPerformances = song.custom_performances || [];
        const needsUpdate = customPerformances.some(perf => labelRenames[perf.label]);

        if (needsUpdate) {
            const updatedSong = Object.assign({}, song);
            updatedSong._updated_custom_performances = customPerformances.map(perf =>
                labelRenames[perf.label] ? { ...perf, label: labelRenames[perf.label] } : perf
            );
            return updatedSong;
        }
        return null;
    }

    function checkWriterArtists(song) {
        const writerArtists = song.writer_artists || [];
        const customPerformances = song.custom_performances || [];

        const getUniqueArtists = (performances, label) => {
            return performances
                .filter(p => p.label.toLowerCase() === label)
                .flatMap(p => p.artists || [])
                .filter((artist, index, self) =>
                    index === self.findIndex(a => a.id === artist.id)
                );
        };

        const lyricists = getUniqueArtists(customPerformances, "lyricist");
        const composers = getUniqueArtists(customPerformances, "composer");
        const lyricistsAndComposers = [...lyricists, ...composers].filter((artist, index, self) =>
            index === self.findIndex(a => a.id === artist.id)
        );

        const onlyWriters = writerArtists.filter(writer =>
            !lyricistsAndComposers.some(ac => ac.id === writer.id)
        );

        const lyricistsAndComposersAndWriters = [...lyricists, ...composers, ...onlyWriters].filter((artist, index, self) =>
            index === self.findIndex(a => a.id === artist.id)
        );

        if (lyricistsAndComposersAndWriters.length > writerArtists.length) {
            const updatedWriterArtists = lyricistsAndComposersAndWriters.filter(
                (artist, index, self) =>
                    index === self.findIndex(a => a.id === artist.id)
            );

            const updatedSong = Object.assign({}, song);
            updatedSong._updated_writer_artists = updatedWriterArtists;

            return updatedSong;
        }
        return false;
    }



    function addCleanupButtonOld(songs, actionType, label, metadataUpdate) {
        if (songs.length === 0) return;

        const albumAdminMenu = document.querySelector('album-admin-menu');
        if (!albumAdminMenu) return;

        const actionButton = document.createElement('button');
        actionButton.className = 'square_button u-bottom_margin';
        actionButton.textContent = label;
        actionButton.setAttribute('ng-click', "$ctrl.removeZWSP()");
        actionButton.setAttribute('ng-if', "$ctrl.has_permission('removeZWSP')");
        actionButton.setAttribute('bis_skin_checked', '1');
        actionButton.style.marginRight = "0.25rem";

        function showCoverArtPopup(songs, metadataUpdate, delay) {
            const coverUrlMap = new Map();
            songs.forEach(song => {
                const url = song.custom_song_art_image_url;
                if (!url) return;
                if (!coverUrlMap.has(url)) {
                    coverUrlMap.set(url, []);
                }
                coverUrlMap.get(url).push(song);
            });

            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100vw';
            overlay.style.height = '100vh';
            overlay.style.backgroundColor = 'rgba(0,0,0,0.6)';
            overlay.style.zIndex = '9999';
            overlay.style.display = 'flex';
            overlay.style.flexDirection = 'column';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.padding = '2rem';

            const popup = document.createElement('div');
            popup.style.backgroundColor = '#fff';
            popup.style.borderRadius = '0.5rem';
            popup.style.padding = '20px';
            popup.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
            popup.style.width = '80%';
            popup.style.maxWidth = '800px';
            popup.style.height = 'auto';
            popup.style.maxHeight = '96%';
            popup.style.overflowY = 'auto';

            const titleContainer = document.createElement('div');
            titleContainer.style.backgroundColor = '#99a7ee';
            titleContainer.style.color = '#fff';
            titleContainer.style.textAlign = 'center';
            titleContainer.style.marginTop = '-20px';
            titleContainer.style.marginLeft = '-20px';
            titleContainer.style.marginRight = '-20px';
            titleContainer.style.marginBottom = '0.5rem';
            titleContainer.style.padding = '1px';
            titleContainer.style.fontWeight = 'bold';
            titleContainer.style.fontSize = '16px';
            titleContainer.textContent = 'Artwork Extractor for Genius';
            popup.insertBefore(titleContainer, popup.firstChild);

            const sectionHeading = document.createElement('div');
            sectionHeading.textContent = 'Select Cover Art to Remove';
            sectionHeading.style.fontWeight = 'bold';
            sectionHeading.style.textAlign = 'center';
            sectionHeading.style.marginTop = '0.75rem';
            popup.appendChild(sectionHeading);

            const coverGrid = document.createElement('div');
            coverGrid.style.display = 'flex';
            coverGrid.style.flexWrap = 'wrap';
            coverGrid.style.justifyContent = 'space-between';
            coverGrid.style.gap = '0.5rem';
            coverGrid.style.marginTop = '0.5rem';
            coverGrid.style.marginBottom = '1rem';
            popup.appendChild(coverGrid);

            const selectedUrls = new Set();

            for (const [url, songGroup] of coverUrlMap.entries()) {
                const wrapper = document.createElement('div');
                wrapper.style.border = '5px solid transparent';
                wrapper.style.borderRadius = '0.5rem';
                wrapper.style.cursor = 'pointer';
                wrapper.style.width = '49%';

                const img = document.createElement('img');
                img.src = url;
                img.alt = songGroup[0].title || 'Cover';
                img.style.objectFit = 'cover';
                img.style.borderRadius = '0.25rem';

                const countLabel = document.createElement('div');
                countLabel.textContent = `${songGroup.length} Track${songGroup.length === 1 ? '' : 's'}`;
                countLabel.style.fontSize = '0.85rem';
                countLabel.style.textAlign = 'center';

                wrapper.appendChild(img);
                wrapper.appendChild(countLabel);
                coverGrid.appendChild(wrapper);

                wrapper.addEventListener('click', () => {
                    if (selectedUrls.has(url)) {
                        selectedUrls.delete(url);
                        wrapper.style.border = '5px solid transparent';
                        wrapper.style.borderRadius = '0.5rem';
                    } else {
                        selectedUrls.add(url);
                        wrapper.style.border = '5px solid #99a7ee';
                    }
                });
            }


            const buttonRow = document.createElement('div');
            buttonRow.style.marginTop = '0.5rem';

            const cancelButton = document.createElement('button');
            cancelButton.className = 'square_button square_button--transparent square_button--gray';
            cancelButton.textContent = 'Cancel';
            cancelButton.addEventListener('click', () => {
                document.body.removeChild(overlay);
            });

            const saveButton = document.createElement('button');
            saveButton.className = 'square_button square_button--green';
            saveButton.type = 'submit';
            saveButton.textContent = 'Save';
            saveButton.addEventListener('click', async () => {
                const affectedSongs = songs.filter(song => selectedUrls.has(song.custom_song_art_image_url));

                affectedSongs.forEach((song, index) => {
                    setTimeout(async () => {
                        let updateData = {};

                        if (metadataUpdate.coverArt) {
                            console.log('Removing cover art for song:', song);
                            updateData.custom_song_art_image_url = null;
                        }

                        await updateSongMetadata2(song, updateData);
                    }, index * delay);
                });

                document.body.removeChild(overlay);

                actionButton.style.display = 'none';

                const albumButtons = document.querySelectorAll('.square_button.u-bottom_margin');
                albumButtons.forEach((button, index) => {
                    if (index >= 2) button.remove();
                });

                const expandText = document.querySelector('span.expand-text');
                if (expandText) expandText.remove();

                setTimeout(() => {
                    main();
                }, 1000);

            });

            buttonRow.appendChild(saveButton);
            buttonRow.appendChild(cancelButton);
            popup.appendChild(buttonRow);
            overlay.appendChild(popup);
            document.body.appendChild(overlay);
        }

        actionButton.addEventListener('click', async () => {
            const delay = 50;

            if (actionType === "CoverArt") {
                showCoverArtPopup(songs, metadataUpdate, delay);
                return;
            }

            songs.forEach((song, index) => {
                setTimeout(async () => {
                    let updateData = {};

                    if (metadataUpdate.title === "remove_zwsp") {
                        updateData.title = song.title
                            .replace(/\u200B{2,}/g, '\u200B')
                            .replace(/^\u200B|(?<=[\p{L}\p{N}\p{P}])\u200B|(?=[\p{L}\p{N}\p{P}])\u200B/gu, '');
                    }

                    if (metadataUpdate.renameLabels && song._updated_custom_performances) {
                        updateData.custom_performances = song._updated_custom_performances;
                    }

                    if (metadataUpdate.writerArtists && song._updated_writer_artists) {
                        updateData.writer_artists = song._updated_writer_artists;
                    }

                    await updateSongMetadata2(song, updateData);
                }, index * delay);
            });

            actionButton.style.display = 'none';

            const albumButtons = document.querySelectorAll('.square_button.u-bottom_margin');
            albumButtons.forEach((button, index) => {
                if (index >= 2) button.remove();
            });

            const expandText = document.querySelector('span.expand-text');
            if (expandText) expandText.remove();

            setTimeout(() => {
                main();
            }, 1000);
        });
        albumAdminMenu.parentNode.insertBefore(actionButton, albumAdminMenu);
    }


    function addCleanupButton(songs, actionType, label, metadataUpdate) {
        if (songs.length === 0) return;

        console.log(songs, actionType, label, metadataUpdate)

        const { stickyToolbarLeft, smallButton } = getDomElements();
        if (!stickyToolbarLeft || !smallButton) return;

        const existingButton = [...stickyToolbarLeft.querySelectorAll("button")].find(btn => btn.textContent.trim() === label);
        if (existingButton) existingButton.remove();

        const cleanupButton = document.createElement("button");
        cleanupButton.type = "button";
        cleanupButton.className = smallButton.className;
        cleanupButton.textContent = label;
        stickyToolbarLeft.appendChild(cleanupButton);


        function showCoverArtPopup(songs, metadataUpdate, delay) {
            const coverUrlMap = new Map();
            songs.forEach(song => {
                const url = song.custom_song_art_image_url;
                if (!url) return;
                if (!coverUrlMap.has(url)) {
                    coverUrlMap.set(url, []);
                }
                coverUrlMap.get(url).push(song);
            });

            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100vw';
            overlay.style.height = '100vh';
            overlay.style.backgroundColor = 'rgba(0,0,0,0.6)';
            overlay.style.zIndex = '9999';
            overlay.style.display = 'flex';
            overlay.style.flexDirection = 'column';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.padding = '2rem';

            const popup = document.createElement('div');
            popup.style.backgroundColor = '#fff';
            popup.style.padding = '2.25rem';
            popup.style.width = '80%';
            popup.style.maxWidth = '800px';
            popup.style.height = 'auto';
            popup.style.maxHeight = '96%';
            popup.style.overflowY = 'auto';

            const titleContainer = document.createElement('div');
            titleContainer.style.backgroundColor = '#99a7ee';
            titleContainer.style.color = '#fff';
            titleContainer.style.textAlign = 'center';
            titleContainer.style.marginTop = '-2.25rem';
            titleContainer.style.marginLeft = '-2.25rem';
            titleContainer.style.marginRight = '-2.25rem';
            titleContainer.style.marginBottom = '1.0rem';
            titleContainer.style.padding = '0.75rem';
            titleContainer.style.fontWeight = 'bold';
            titleContainer.style.fontSize = '16px';
            titleContainer.textContent = 'Artwork Extractor for Genius';
            popup.insertBefore(titleContainer, popup.firstChild);

            const sectionHeading = document.createElement('div');
            sectionHeading.textContent = 'Select Cover Art to Remove';
            sectionHeading.style.fontWeight = 'bold';
            sectionHeading.style.textAlign = 'center';
            sectionHeading.style.marginBottom = '1.0rem';
            popup.appendChild(sectionHeading);

            const coverGrid = document.createElement('div');
            coverGrid.style.display = 'flex';
            coverGrid.style.flexWrap = 'wrap';
            coverGrid.style.justifyContent = 'space-between';
            coverGrid.style.gap = '0.5rem';
            coverGrid.style.marginTop = '0.5rem';
            coverGrid.style.marginBottom = '1rem';
            popup.appendChild(coverGrid);

            const selectedUrls = new Set();

            for (const [url, songGroup] of coverUrlMap.entries()) {
                const wrapper = document.createElement('div');
                wrapper.style.border = '5px solid transparent';
                wrapper.style.cursor = 'pointer';
                wrapper.style.width = '49%';

                const img = document.createElement('img');
                img.src = url;
                img.alt = songGroup[0].title || 'Cover';
                img.style.objectFit = 'cover';

                const countLabel = document.createElement('div');
                countLabel.textContent = `${songGroup.length} Track${songGroup.length === 1 ? '' : 's'}`;
                countLabel.style.fontSize = '0.85rem';
                countLabel.style.textAlign = 'center';

                wrapper.appendChild(img);
                wrapper.appendChild(countLabel);
                coverGrid.appendChild(wrapper);

                wrapper.addEventListener('click', () => {
                    if (selectedUrls.has(url)) {
                        selectedUrls.delete(url);
                        wrapper.style.border = '5px solid transparent';
                    } else {
                        selectedUrls.add(url);
                        wrapper.style.border = '5px solid #99a7ee';
                    }
                });
            }

            const buttonRow = document.createElement('div');
            buttonRow.style.display = 'flex';
            buttonRow.style.gap = '0.5rem';
            buttonRow.style.marginTop = '0.5rem';

            const cancelButton = document.createElement('button');
            cancelButton.className = smallButton.className;
            cancelButton.textContent = 'Cancel';
            cancelButton.addEventListener('click', () => {
                document.body.removeChild(overlay);
            });

            const saveButton = document.createElement('button');
            saveButton.className = smallButton.className;
            saveButton.type = 'submit';
            saveButton.textContent = 'Save';
            saveButton.addEventListener('click', async () => {
                const affectedSongs = songs.filter(song => selectedUrls.has(song.custom_song_art_image_url));

                affectedSongs.forEach((song, index) => {
                    setTimeout(async () => {
                        let updateData = {};

                        if (metadataUpdate.coverArt) {
                            console.log('Removing cover art for song:', song);
                            updateData.custom_song_art_image_url = null;
                        }

                        await updateSongMetadata2(song, updateData);
                    }, index * delay);
                });

                document.body.removeChild(overlay);

                cleanupButton.style.display = 'none';

                const albumButtons = document.querySelectorAll('.square_button.u-bottom_margin');
                albumButtons.forEach((button, index) => {
                    if (index >= 2) button.remove();
                });

                const expandText = document.querySelector('span.expand-text');
                if (expandText) expandText.remove();

                setTimeout(() => {
                    main();
                }, 1000);

            });

            buttonRow.appendChild(saveButton);
            buttonRow.appendChild(cancelButton);
            popup.appendChild(buttonRow);
            overlay.appendChild(popup);
            document.body.appendChild(overlay);
        }

        cleanupButton.addEventListener('click', async () => {
            const delay = 50;

            if (actionType === "CoverArt") {
                showCoverArtPopup(songs, metadataUpdate, delay);
                return;
            }

            songs.forEach((song, index) => {
                setTimeout(async () => {
                    let updateData = {};

                    if (metadataUpdate.renameLabels && song._updated_custom_performances) {
                        updateData.custom_performances = song._updated_custom_performances;
                    }

                    if (metadataUpdate.writerArtists && song._updated_writer_artists) {
                        updateData.writer_artists = song._updated_writer_artists;
                    }

                    console.log("Updating song with data:", song.id, updateData);
                    await updateSongMetadata(song.id, updateData);
                }, index * delay);
            });

            cleanupButton.style.display = 'none';

            setTimeout(() => {
                main();
            }, 1000);
        });
        stickyToolbarLeft.appendChild(cleanupButton);
    }




    function cleanupAlbumType(albumId, albumType, albumTitle) {
        const cleanupTypes = [
            "EP",
            "Single",
            "Doppelsingle",
            "Compilation",
            "Soundtrack",
            "Live Album",
            "DJ Mix"
        ];

        const typeMap = {
            "EP": "ep",
            "Single": "single",
            "Doppelsingle": "single",
            "Compilation": "compilation",
            "Soundtrack": "soundtrack",
            "Live Album": "live",
            "DJ Mix": "dj_mix"
        };

        const matchedType = cleanupTypes.find(type => albumTitle.endsWith(` (${type})`) || albumTitle.endsWith(` [${type}]`) || albumTitle.endsWith(` - ${type}`));
        if (!matchedType) return;

        const typeAlreadyCorrect = albumType === typeMap[matchedType];
        const label = typeAlreadyCorrect ? "Fix Album Name" : "Fix Album Type & Name";

        const { stickyToolbarLeft, smallButton } = getDomElements();
        if (!stickyToolbarLeft || !smallButton) return;

        const existingButton = [...stickyToolbarLeft.querySelectorAll("button")].find(btn => btn.textContent.trim() === label);
        if (existingButton) existingButton.remove();

        const cleanupButton = document.createElement("button");
        cleanupButton.type = "button";
        cleanupButton.className = smallButton.className;
        cleanupButton.textContent = label;

        stickyToolbarLeft.appendChild(cleanupButton);

        cleanupButton.addEventListener("click", async () => {
            const apiAlbumType = typeMap[matchedType];

            let cleanedName = albumTitle
                .replace(` (${matchedType})`, "")
                .replace(` - ${matchedType}`, "")
                .replace(` [${matchedType}]`, "")
                .trim();

            const payload = typeAlreadyCorrect
                ? {
                    text_format: "html,markdown",
                    name: cleanedName
                }
                : {
                    text_format: "html,markdown",
                    album_type: apiType,
                    name: cleanedName
                };

            await updateAlbumMetadata(albumId, payload);

            cleanupButton.style.display = "none";
        });
    }


});
