chrome.storage.local.get([
    'Services/genius_song.js',
    'isGeniusSongSongPage',
    'isGeniusSongSongPageZwsp',
    'isGeniusSongSongPageInfo',
    'isGeniusSongSongId',
    'isGeniusSongCheckIndex',
    'isGeniusSongFollowButton',
    'isGeniusSongRecreateButton',
    'isGeniusSongTranslationButton',
    'isGeniusSongShellyButton',
    'isGeniusSongCleanupMetadataButton',
    'isGeniusSongLanguageButton',
    'isGeniusSongCleanupButton',
    'isGeniusSongSectionsButtons',
    'isGeniusSongExpandSectionsButtons',
    'isGeniusSongAnnotationsButtons',
    'isGeniusSongFilterActivity',
    'isGeniusSongFilterNotifications',
    'isGeniusSongSaveFilters',
    'isGeniusSongFilterFirehose',
    'isGeniusSongCopyCover',
    'isGeniusSongAppleMusicPlayer',
    'isGeniusSongYouTubePlayer',
    'isGeniusSongSoundCloudPlayer',
    'isGeniusSongSpotifyPlayer',
    'isGeniusSongLyricEditor',
    'isGeniusSongRenameButtons'
], async function (result) {
    const isGeniusSongSongPage = result.isGeniusSongSongPage ?? true;
    const isGeniusSongSongPageZwsp = result.isGeniusSongSongPageZwsp ?? true;
    const isGeniusSongSongPageInfo = result.isGeniusSongSongPageInfo ?? true;
    const isGeniusSongSongId = result.isGeniusSongSongId ?? false;
    const isGeniusSongCheckIndex = result.isGeniusSongCheckIndex ?? false;
    const isGeniusSongFollowButton = result.isGeniusSongFollowButton ?? true;
    const isGeniusSongRecreateButton = result.isGeniusSongRecreateButton ?? true;
    const isGeniusSongTranslationButton = result.isGeniusSongTranslationButton ?? true;
    const isGeniusSongShellyButton = result.isGeniusSongShellyButton ?? true;
    const isGeniusSongCleanupMetadataButton = result.isGeniusSongCleanupMetadataButton ?? true;
    const isGeniusSongLanguageButton = result.isGeniusSongLanguageButton ?? true;
    const isGeniusSongCleanupButton = result.isGeniusSongCleanupButton ?? true;
    const isGeniusSongSectionsButtons = result.isGeniusSongSectionsButtons ?? true;
    const isGeniusSongExpandSectionsButtons = result.isGeniusSongExpandSectionsButtons ?? false;
    const isGeniusSongAnnotationsButtons = result.isGeniusSongAnnotationsButtons ?? true;
    const isGeniusSongFilterActivity = result.isGeniusSongFilterActivity ?? true;
    const isGeniusSongFilterNotifications = result.isGeniusSongFilterNotifications ?? true;
    const isGeniusSongSaveFilters = result.isGeniusSongSaveFilters ?? false;
    const isGeniusSongFilterFirehose = result.isGeniusSongFilterFirehose ?? true;
    const isGeniusSongCopyCover = result.isGeniusSongCopyCover ?? true;
    const isGeniusSongAppleMusicPlayer = result.isGeniusSongAppleMusicPlayer ?? true;
    const isGeniusSongYouTubePlayer = result.isGeniusSongYouTubePlayer ?? true;
    const isGeniusSongSoundCloudPlayer = result.isGeniusSongSoundCloudPlayer ?? true;
    const isGeniusSongSpotifyPlayer = result.isGeniusSongSpotifyPlayer ?? true;
    const isGeniusSongLyricEditor = result.isGeniusSongLyricEditor ?? true;
    const isGeniusSongRenameButtons = result.isGeniusSongRenameButtons ?? true;


    if (result['Services/genius_song.js'] === false) {
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                  MAIN PROGRAM                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    queueMicrotask(main);

    async function main() {
        const state = getScripts("window.__PRELOADED_STATE__");

        console.log(state);

        const userId = state?.session?.currentUser;
        const userRole = state?.entities?.users?.[userId]?.roleForDisplay;
        const userUrl = state?.entities?.users?.[userId]?.url;
        const songId = state?.songPage?.song;
        const songTitle = state?.entities?.songs?.[songId]?.title;
        const primaryColor = state?.entities?.songs?.[songId]?.songArtPrimaryColor;
        const secondaryColor = state?.entities?.songs?.[songId]?.songArtSecondaryColor;
        const textColor = state?.entities?.songs?.[songId]?.songArtTextColor;
        const headerImageUrl = state?.entities?.songs?.[songId]?.headerImageUrl;
        const customSongArtImageUrl = state?.entities?.songs?.[songId]?.customSongArtImageUrl;
        const songArtImageUrl = state?.entities?.songs?.[songId]?.songArtImageUrl;
        const album = state?.entities?.songs?.[songId]?.album;
        const songs = state?.entities?.songs;
        const primaryArtists = state?.entities?.songs?.[songId]?.primaryArtists;
        const featuredArtists = state?.entities?.songs?.[songId]?.featuredArtists;
        const artists = state?.entities?.artists;
        const primaryArtistNames = state?.entities?.songs?.[songId]?.primaryArtistNames;
        const lyricsMarkedCompleteBy = state?.entities?.songs?.[songId]?.lyricsMarkedCompleteBy;
        const lyricsMarkedStaffApprovedBy = state?.entities?.songs?.[songId]?.lyricsMarkedStaffApprovedBy;
        const lyricsVerified = state?.entities?.songs?.[songId]?.lyricsVerified;
        const updatedByHumanAt = state?.entities?.songs?.[songId]?.updatedByHumanAt;
        const lyricsUpdatedAt = state?.entities?.songs?.[songId]?.lyricsUpdatedAt;
        const writerArtists = state?.entities?.songs?.[songId]?.writerArtists;
        const producerArtists = state?.entities?.songs?.[songId]?.producerArtists;
        const customPerformances = state?.entities?.songs?.[songId]?.customPerformances;
        const primaryTag = state?.entities?.songs?.[songId]?.primaryTag;
        const secondaryTag = state?.entities?.songs?.[songId]?.tags;
        const tags = state?.entities?.tags;
        const songAlbums = state?.entities?.songs?.[songId]?.albums;
        const albums = state?.entities?.albums;
        const releaseDateComponents = state?.entities?.songs?.[songId]?.releaseDateComponents;
        const youtubeUrl = state?.entities?.songs?.[songId]?.youtubeUrl;
        const youtubeStart = state?.entities?.songs?.[songId]?.youtubeStart;
        const appleMusicId = state?.entities?.songs?.[songId]?.appleMusicId;
        const soundcloudUrl = state?.entities?.songs?.[songId]?.soundcloudUrl;
        const spotifyUuid = state?.entities?.songs?.[songId]?.spotifyUuid;
        const songLanguage = state?.entities?.songs?.[songId]?.language;
        const recordetAt = state?.entities?.songs?.[songId]?.recordetAt;
        const albumAppearances = state?.entities?.albumAppearances;
        const trackingData = state?.entities?.songs?.[songId]?.trackingData;


        const songFollow = state?.entities?.songs?.[songId]?.currentUserMetadata?.interactions?.following;


        const isFirehose = window.location.href === 'https://genius.com/firehose';
        const isSong = /-lyrics(?:#primary-album|#about|\?.*)?$|-annotated$|\d+\?$/.test(window.location.href);

        const profilePath = getProfilePathFromDocument();
        console.log(`Profile Path: ${profilePath}`);

        if (isFirehose) {
            if (isGeniusSongFilterFirehose) filterFirehose();
        }

        if (isGeniusSongFilterNotifications) filterNotifications(profilePath);

        if (!isSong) return
        getDomElements();

        editYouTubePlayer();
        editAppleMusicPlayer();
        playerSettings();

        console.log(`- User ID: ${userId}\n- Song ID: ${songId}`);


        if (isGeniusSongSongId) showSongIdButton(songId);
        if (isGeniusSongCheckIndex) showIndexButton();

        if (isGeniusSongSongPageInfo) showCoverInfo(headerImageUrl, primaryColor, secondaryColor, textColor);
        if (isGeniusSongSongPage) checkSongCover(customSongArtImageUrl, songArtImageUrl, album, songTitle);

        if (isGeniusSongFollowButton) addFollowButton();
        if (isGeniusSongRecreateButton) addRecreateButton(songId, songTitle, primaryArtists, featuredArtists, writerArtists, producerArtists, customPerformances, artists, primaryTag, secondaryTag, tags, songAlbums, albums, youtubeUrl, youtubeStart, soundcloudUrl, customSongArtImageUrl, releaseDateComponents, songLanguage, recordetAt, albumAppearances);
        if (isGeniusSongTranslationButton) addTranslationButton(songs, songId, songTitle, primaryArtistNames, featuredArtists, artists, primaryTag, releaseDateComponents, customSongArtImageUrl, youtubeUrl, youtubeStart);
        if (isGeniusSongShellyButton) addShellyButton(songId, lyricsMarkedCompleteBy, lyricsMarkedStaffApprovedBy, lyricsVerified, updatedByHumanAt, lyricsUpdatedAt);

        if (isGeniusSongCleanupMetadataButton) cleanupMetadata(songId, songTitle, writerArtists, customPerformances, artists);

        if (isGeniusSongLanguageButton) selectDropdown(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData, "Language");
        if (isGeniusSongCleanupButton) selectDropdown(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData, "Cleanup");
        if (isGeniusSongSectionsButtons) lyricsSectionsButtons(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData);
        if (isGeniusSongAnnotationsButtons) lyricsAnnotationsButtons();

        if (isGeniusSongFilterActivity) filterRecentActivity(profilePath);

        if (appleMusicId) storeAppleMusicStructure();

        if (primaryTag !== 1452) {
            //if (isGeniusSongSpotifyPlayer) addSpotifyPlayer(spotifyUuid, songTitle, primaryArtists, featuredArtists, artists);
        }
        if (soundcloudUrl) {
            if (isGeniusSongSoundCloudPlayer) addSoundCloudPlayer(soundcloudUrl);
        }
    }


    function getDomElements() {
        const metadatastatsContainer = document.querySelector('div[class^="MetadataStats__Container-"]');

        return {
            metadatastatsContainer,
            labelwithiconLabel: metadatastatsContainer?.querySelector('span[class^="LabelWithIcon__Label-"]'),
            adminSpan: [...document.querySelectorAll('span')].find(el => el.textContent.trim() === "Admin"),
            sizedimageImage: document.querySelector('img[class^="SizedImage__Image-"]'),
            songheaderCoverart: document.querySelector('div[class^="SongHeader-desktop__CoverArt-"]'),
            editmetadatabutonSmallbutton: document.querySelector('button[class*="EditMetadataButton__SmallButton-"]'),
            sharebuttonsContainer: document.querySelector('div[class^="ShareButtons__Container-"]'),
            stickytoolbarContainer: document.querySelector('div[class*="StickyToolbar__Container-"]'),
            stickytoolbarLeft: document.querySelector('div[class^="StickyToolbar__Left-"]'),
            stickytoolbarRight: document.querySelector('div[class^="StickyToolbar__Right-"]'),
            stickyNavContainer: document.querySelector('nav[class^="StickyNav-desktop__Container-"]'),
            texteditorTextarea: document.querySelector('textarea[class*="TextEditor__TextArea"]'),
            lyricseditexplainerContainer: document.querySelector('div[class^="LyricsEditExplainer__Container-"]'),
            lyricsTextareaInputTextarea: document.querySelector('textarea[class*="LyricsTextareaInput-"]'),
            mediaplayerscontainerContainer: document.querySelector('[class^="MediaPlayersContainer__Container-"]'),
            transcriptionplayerContainer: document.querySelector('div[class^="TranscriptionPlayer__Container-"]'),
            youtubebuttonPlayvideobutton: document.querySelector('[class*="YoutubeButton__PlayVideoButton-"]'),
            applemusicplayerPositioningcontainer: document.querySelector('div[class^="AppleMusicPlayer-desktop__PositioningContainer-"]'),
            applemusicplayerIframecontainer: document.querySelector('div[class*="AppleMusicPlayer-desktop__IframeContainer-"]'),
            applemusicplayerIframe: document.querySelector('iframe[class^="AppleMusicPlayer-desktop__Iframe-"]'),
            soundcloudplayerPositioningcontainer: document.querySelector('div[class^="SoundCloudPlayer-desktop__PositioningContainer-"]'),
            soundcloudplayerIframecontainer: document.querySelector('div[class*="SoundCloudPlayer-desktop__IframeContainer-"]'),
            soundcloudplayerIframe: document.querySelector('iframe[class^="SoundCloudPlayer-desktop__Iframe-"]'),
        };
    }

    function getProfilePathFromDocument() {
        const profileMatch = document.documentElement.innerHTML.match(/\\"profile_path\\":\\"([^"]+)\\"/);
        const profilePath = profileMatch?.[1] ?? null;
        if (profilePath) chrome.storage.local.set({ profilePath });
        return profilePath;
    }

    document.addEventListener('click', function (event) {
        const link = event.target.closest('a');
        if (link && link.getAttribute('href') === '#primary-album') {
            event.preventDefault();
            document.getElementById('primary-album').scrollIntoView({ behavior: 'instant' });
        }
    });


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                             SONG ID & INDEX BUTTON                             //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function showSongIdButton(songId) {
        const { metadatastatsContainer, labelwithiconLabel } = getDomElements();

        if (metadatastatsContainer && !document.getElementById("song-id-button")) {
            const songIdElement = document.createElement('span');
            songIdElement.id = "song-id-button";
            songIdElement.className = labelwithiconLabel?.className;

            const songIdLink = document.createElement('a');
            songIdLink.href = `https://genius.com/api/songs/${songId}`;
            songIdLink.target = "_blank";
            songIdLink.textContent = songId;
            songIdLink.style.textDecoration = "none";
            songIdLink.style.color = "inherit";
            songIdLink.onmouseover = () => songIdLink.style.textDecoration = "underline";
            songIdLink.onmouseout = () => songIdLink.style.textDecoration = "none";

            songIdElement.textContent = "Song ID: ";
            songIdElement.appendChild(songIdLink);

            metadatastatsContainer.appendChild(songIdElement);
        }
    }

    function showIndexButton() {
        const { adminSpan, metadatastatsContainer, labelwithiconLabel } = getDomElements();

        if (adminSpan && metadatastatsContainer && !document.getElementById("index-button")) {
            const indexElement = document.createElement('span');
            indexElement.id = "index-button";
            indexElement.className = labelwithiconLabel?.className;

            const siteQuery = `site:${window.location.href}`;
            const indexLink = document.createElement('a');
            indexLink.href = `https://www.google.com/search?q=${encodeURIComponent(siteQuery)}`;
            indexLink.target = "_blank";
            indexLink.textContent = "Index ⤤";
            indexLink.style.textDecoration = "none";
            indexLink.style.color = "inherit";
            indexLink.style.marginLeft = "4px";
            indexLink.onmouseover = () => indexLink.style.textDecoration = "underline";
            indexLink.onmouseout = () => indexLink.style.textDecoration = "none";

            indexElement.appendChild(indexLink);
            metadatastatsContainer.appendChild(indexElement);
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                   COVER INFO                                   //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function showCoverInfo(headerImageUrl, primaryColor, secondaryColor, textColor) {
        console.log("Run function showCoverInfo()");

        const { sizedimageImage, songheaderCoverart } = getDomElements();
        if (!sizedimageImage || !songheaderCoverart) return;

        const existing = songheaderCoverart.querySelector('div[data-type="resolution-info"]');
        if (existing) existing.remove();

        const pxToRem = (px) => {
            const rootFontSize = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
            return px / rootFontSize;
        };

        const createResolutionInfo = () => {
            const resolutionMatch = headerImageUrl.match(/(\d+)x(\d+)/);
            const formatMatch = headerImageUrl.match(/\.(\w+)$/);

            const resolutionText = resolutionMatch?.[1] ? `${resolutionMatch[1]}x${resolutionMatch[2]}` : "No";
            const formatText = formatMatch?.[1] ? formatMatch[1].toUpperCase() : "Cover";

            const resolutionInfo = document.createElement('div');
            resolutionInfo.dataset.type = "resolution-info";
            resolutionInfo.style.fontWeight = "100";
            resolutionInfo.style.textAlign = "center";
            resolutionInfo.style.position = "relative";
            resolutionInfo.style.color = textColor;

            resolutionInfo.textContent = [`${resolutionText} ${formatText}`, primaryColor, secondaryColor, textColor].join(" | ");

            const updateStyles = () => {
                const imgWidth = sizedimageImage.clientWidth || 1000;
                const dynamicFontPx = imgWidth * 0.05;
                const fontSizeRem = Math.min(pxToRem(dynamicFontPx), 0.75);

                resolutionInfo.style.fontSize = `${fontSizeRem}rem`;

                const topRem = -fontSizeRem / 2;
                resolutionInfo.style.top = `${topRem - 0.075}rem`;
            };

            updateStyles();

            const observer = new ResizeObserver(updateStyles);
            observer.observe(sizedimageImage);

            return resolutionInfo;
        };

        const infoElement = createResolutionInfo();
        songheaderCoverart.prepend(infoElement);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                COVER INDICATOR                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function checkSongCover(customSongArt, songArt, album, songTitle) {
        console.log("Run function checkSongCover()");

        const { editmetadatabutonSmallbutton } = getDomElements();
        if (!editmetadatabutonSmallbutton) return;

        let color, borderColor;

        if (customSongArt) {
            if (customSongArt.startsWith("https://images.genius.com") && customSongArt.endsWith("1000x1000x1.png")) {
                color = '#99f2a5'; // Green
                borderColor = '#66bfa3';
            } else if ((customSongArt.startsWith("http://images.genius.com") || customSongArt.startsWith("http://images.rapgenius.com") || customSongArt.startsWith("https://images.rapgenius.com")) && customSongArt.endsWith("1000x1000x1.png")) {
                color = '#7689e8'; // Blue
                borderColor = '#4a5e9d';
            } else if (customSongArt.startsWith("https://filepicker-images-rapgenius.s3.amazonaws.com/filepicker-images-rapgenius/") || customSongArt.endsWith("1000x1000bb.png") || customSongArt.endsWith("10000x10000bb.png") || customSongArt.endsWith("1000x1000.png") || customSongArt.endsWith("1000x1000-000000-80-0-0.png")) {
                color = '#ffff64'; // Yellow
                borderColor = '#cccc00';
            } else {
                color = '#fa7878'; // Red
                borderColor = '#a74d4d';
            }
        } else {
            if (!album) {
                color = '#dddddd'; // Grey
                borderColor = '#aaaaaa';
            } else {
                if (songArt.endsWith("1000x1000x1.png")) {
                    color = '#99f2a5'; // Green
                    borderColor = '#66bfa3';
                } else if (songArt.includes("default_cover_art.png")) {
                    color = '#dddddd'; // Grey
                    borderColor = '#aaaaaa';
                } else {
                    color = '#ffa335'; // Orange
                    borderColor = '#c76a2b';
                }
            }
        }

        addColoredCircle(editmetadatabutonSmallbutton, color, borderColor);
        if (isGeniusSongSongPageZwsp) checkSongTitleForZeroWidthSpace(songTitle);
    }

    function addBlackCross(circle) {
        const existingCross = circle.querySelector('.black-cross');
        if (!existingCross) {
            const cross = document.createElement('span');
            cross.className = 'black-cross';
            cross.style.cssText = `
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

            const line1 = document.createElement('div');
            line1.style.cssText = `
            position: absolute;
            width: 128%;
            height: 3px;
            border-radius: 2px;
            background-color: black;
            transform: rotate(25deg);
        `;

            const line2 = document.createElement('div');
            line2.style.cssText = `
            position: absolute;
            width: 128%;
            height: 3px;
            border-radius: 2px;
            background-color: black;
            transform: rotate(-25deg);
        `;

            cross.appendChild(line1);
            cross.appendChild(line2);
            circle.appendChild(cross);
        }
    }

    function addBlackDot(circle) {
        const existingDot = circle.querySelector('.black-dot');
        if (!existingDot) {
            const dot = document.createElement('span');
            dot.className = 'black-dot';
            dot.style.cssText = `
                height: 8px;
                width: 8px;
                background-color: #2C2C2C;
                border-radius: 50%;
                display: inline-block;
                position: absolute;
                top: 50%;
                transform: translate(-50%, -50%);
            `;
            circle.appendChild(dot);
        }
    }

    function addColoredCircle(button, color, borderColor) {
        const existingCircle = button.querySelector('.circle-indicator');
        if (existingCircle) {
            existingCircle.style.backgroundColor = color;
            existingCircle.style.borderColor = borderColor;
        } else {
            const circle = document.createElement('span');
            circle.className = 'circle-indicator';
            circle.style.cssText = `
                font-variant: JIS04;
                height: 16px;
                width: 28px;
                display: inline-block;
                margin-right: 0.375rem;
                margin-left: calc(-0.375rem);
                padding: 0px 0.25rem;
                background-color: ${color};
                border: 1px solid ${borderColor};
                border-radius: 1.25rem;
            `;
            button.prepend(circle);
        }
    }

    function checkSongTitleForZeroWidthSpace(songTitle) {
        if (songTitle.includes('\u200B')) {
            const { editmetadatabutonSmallbutton } = getDomElements();
            const circle = editmetadatabutonSmallbutton.querySelector('.circle-indicator');
            if (circle) {
                addBlackDot(circle);
            }
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 FOLLOW BUTTON                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function addFollowButton() {
        console.log("Run function addFollowButton()");

        const { sharebuttonsContainer, stickytoolbarLeft, editmetadatabutonSmallbutton } = getDomElements();
        const existingButton = sharebuttonsContainer?.children[3];

        if (existingButton && stickytoolbarLeft && editmetadatabutonSmallbutton && !document.getElementById("follow-song-button")) {
            const followButton = document.createElement('button');
            followButton.id = "follow-song-button";
            followButton.className = editmetadatabutonSmallbutton.className.replace("EditMetadataButton", "FollowButton");
            followButton.type = 'button';

            function updateFollowButton() {
                followButton.textContent = existingButton.textContent;
                followButton.disabled = existingButton.disabled;
            }

            updateFollowButton();

            followButton.addEventListener('click', () => {
                existingButton.click();
                updateFollowButton();
            });

            const observer = new MutationObserver(updateFollowButton);
            observer.observe(existingButton, { attributes: true, childList: true, subtree: true });

            stickytoolbarLeft.appendChild(followButton);
            followButton.style.float = 'right';
            followButton.style.maxWidth = 'fit-content';
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 SHELLY BUTTON                                  //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function addShellyButton(songId, lyricsMarkedCompleteBy, lyricsMarkedStaffApprovedBy, lyricsVerified, updatedByHumanAt, lyricsUpdatedAt) {
        console.log("Run function addShellyButton()");

        const { adminSpan } = getDomElements();
        if (!adminSpan) return;

        const dropdownContainer = adminSpan.closest('[class^="Dropdown__Container-"]');
        if (!dropdownContainer) return;

        const list = dropdownContainer.querySelector('[class^="StickyToolbarDropdown__DropdownItems-"]');
        if (!list) return;

        if (document.getElementById("shelly-cleanup-btn")) return;

        const lyricsAreValidated = lyricsMarkedCompleteBy || lyricsMarkedStaffApprovedBy || lyricsVerified === true;
        if (lyricsAreValidated) return;

        const existingButton = list.querySelector("button");
        const existingLi = list.querySelector("li");
        if (!existingButton || !existingLi) return;

        const li = document.createElement("li");
        li.className = existingLi.className;

        const btn = document.createElement("button");
        btn.type = "button";
        btn.id = "shelly-cleanup-btn";
        btn.textContent = "Shelly (Cleanup Bot)";
        btn.className = existingButton.className;

        btn.addEventListener("click", async () => {
            const message = "⚠️ Are you absolutely sure you want to run 'Shelly The Cleanup Bot'?";
            if (!confirm(message)) return;

            const payload = {
                text_format: "html,markdown,preview",
                react: true,
                client_timestamps: {
                    updated_by_human_at: updatedByHumanAt,
                    lyrics_updated_at: lyricsUpdatedAt
                },
                lyrics: {
                    body: {
                        html: "Page needs help... Paging ShellPageBot"
                    }
                }
            };

            await updateSongLyrics(songId, payload);

            const toggle = dropdownContainer.querySelector('[class^="Dropdown__Toggle-"]');
            toggle?.click();
            main()
        });

        li.appendChild(btn);
        list.appendChild(li);
    }


    function addRecreateButton(songId, songTitleRaw, primaryArtistsRaw, featuredArtistsRaw, writerArtistsRaw, producerArtistsRaw, customPerformancesRaw, artists, primaryTagRaw, secondaryTagRaw, tags, songAlbumsRaw, albums, youtubeUrl, youtubeStart, soundcloudUrl, customSongArtImageUrl, releaseDateComponents, songLanguageRaw, recordedAtRaw, albumAppearances) {
        console.log("Run function addRecreateButton()");

        const { adminSpan } = getDomElements();
        if (!adminSpan) return;

        const dropdownContainer = adminSpan.closest('[class^="Dropdown__Container-"]');
        if (!dropdownContainer) return;

        const list = dropdownContainer.querySelector('[class^="StickyToolbarDropdown__DropdownItems-"]');
        if (!list) return;

        if (document.getElementById("recreate-btn")) return;

        const existingButton = list.querySelector("button");
        const existingLi = list.querySelector("li");
        if (!existingButton || !existingLi) return;

        const li = document.createElement("li");
        li.className = existingLi.className;

        const btn = document.createElement("button");
        btn.type = "button";
        btn.id = "recreate-btn";
        btn.textContent = "Recreate Song";
        btn.className = existingButton.className;

        btn.addEventListener("click", async () => {
            const songTitle = songTitleRaw ? [{ name: songTitleRaw }] : [];
            const primaryArtists = (primaryArtistsRaw || []).map(id => artists[id]).filter(Boolean);
            const featuredArtists = (featuredArtistsRaw || []).map(id => artists[id]).filter(Boolean);
            const writerArtists = (writerArtistsRaw || []).map(id => artists[id]).filter(Boolean);
            const producerArtists = (producerArtistsRaw || []).map(id => artists[id]).filter(Boolean);
            const additionalCredits = (customPerformancesRaw || []).map(entry => ({
                role: entry.label,
                artists: (entry.artists || []).map(id => artists[id]).filter(Boolean)
            }));
            const primaryTags = primaryTagRaw ? [tags[primaryTagRaw]].filter(Boolean) : [];
            const secondaryTags = (secondaryTagRaw || []).map(id => tags[id]).filter(Boolean);
            const songAlbums = (songAlbumsRaw || []).map(id => albums[id]).filter(Boolean);
            const youtube = (youtubeUrl || youtubeStart) ? [{ url: youtubeUrl || null, start: youtubeStart || null }] : [];
            const soundcloud = soundcloudUrl ? [{ url: soundcloudUrl }] : [];
            const customSongArtImage = customSongArtImageUrl ? [{ url: customSongArtImageUrl }] : [];
            const releaseDate = releaseDateComponents ? [{ day: releaseDateComponents.day, month: releaseDateComponents.month, year: releaseDateComponents.year }] : [];
            const songLanguage = songLanguageRaw ? [{ name: songLanguageRaw }] : [];
            const recordedAt = recordedAtRaw ? [{ name: recordedAtRaw }] : [];

            openRecreateModal(songId, songTitle, primaryArtists, featuredArtists, writerArtists, producerArtists, additionalCredits, primaryTags, secondaryTags, songAlbums, youtube, soundcloud, customSongArtImage, releaseDate, songLanguage, recordedAt, albumAppearances);
        });

        li.appendChild(btn);
        list.appendChild(li);
    }

    function openRecreateModal(songId, songTitle, primaryArtists, featuredArtists, writerArtists, producerArtists, additionalCredits, primaryTags, secondaryTags, songAlbums, youtube, soundcloud, customSongArtImage, releaseDate, songLanguage, recordedAt, albumAppearances) {
        console.log(songId, songTitle, primaryArtists, featuredArtists, writerArtists, producerArtists, additionalCredits, primaryTags, secondaryTags, songAlbums, youtube, soundcloud, customSongArtImage, releaseDate, songLanguage, recordedAt, albumAppearances);

        const { editmetadatabutonSmallbutton } = getDomElements();
        if (document.getElementById("create-recreate-modal")) return;

        document.body.style.overflow = "hidden";

        const tagStyle = {
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
            background: "#eaeaea",
            padding: "4px 8px",
            borderRadius: "6px",
            fontSize: "0.8em",
            marginRight: "6px",
            marginBottom: "6px"
        };

        const tagRemoveStyle = {
            cursor: "pointer",
            fontWeight: "bold",
            color: "#444"
        };

        const overlay = document.createElement("div");
        overlay.id = "create-recreate-modal";
        Object.assign(overlay.style, {
            position: "fixed",
            top: "0",
            left: "0",
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: "9999"
        });

        const modal = document.createElement("div");
        Object.assign(modal.style, {
            background: "#fff",
            padding: "20px",
            borderRadius: "8px",
            width: "900px",
            maxHeight: "85vh",
            overflowY: "auto",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
            display: "flex",
            flexDirection: "column",
            gap: "18px"
        });

        const table = document.createElement("div");
        Object.assign(table.style, {
            display: "flex",
            flexDirection: "column",
            width: "100%",
            gap: "12px",
            overflowY: "auto",
            maxHeight: "75vh"
        });

        function removeValueFromArray(array, value) {
            const index = array.indexOf(value);
            if (index !== -1) array.splice(index, 1);
        }


        function buildTagRow(labelText, values) {
            const row = document.createElement("div");
            Object.assign(row.style, {
                display: "grid",
                gridTemplateColumns: "225px 1fr",
                alignItems: "flex-start",
                gap: "16px"
            });

            const lbl = document.createElement("div");
            lbl.textContent = labelText;
            Object.assign(lbl.style, {
                fontWeight: "600",
                paddingTop: "6px"
            });

            const tagContainer = document.createElement("div");
            Object.assign(tagContainer.style, {
                display: "flex",
                flexWrap: "wrap",
                gap: "6px"
            });

            function addTag(value, labelText) {
                const tag = document.createElement("div");
                Object.assign(tag.style, tagStyle);

                const text = document.createElement("span");

                let display = "";
                if (value && typeof value === "object") {
                    if (value.name) display = value.name;
                    else if (value.id) display = value.id;
                    else if (value.url) display = value.url;
                    else if (typeof value.day === "number" && typeof value.month === "number" && typeof value.year === "number") {
                        display = `${value.year}-${String(value.month).padStart(2, "0")}-${String(value.day).padStart(2, "0")}`;
                    } else {
                        display = JSON.stringify(value);
                    }
                } else {
                    display = value;
                }

                text.textContent = display;

                const protectedLabels = ["Primary Tag", "Song Title", "Primary Artists"];
                const allowRemove = !protectedLabels.includes(labelText);

                if (allowRemove) {
                    const remove = document.createElement("span");
                    remove.textContent = "×";
                    Object.assign(remove.style, tagRemoveStyle);

                    remove.addEventListener("click", () => {
                        tag.remove();
                        removeValueFromArray(values, value);
                    });

                    tag.appendChild(remove);
                }

                tag.insertBefore(text, tag.firstChild);
                tagContainer.appendChild(tag);
            }


            values.forEach(v => addTag(v, labelText));

            row.appendChild(lbl);
            row.appendChild(tagContainer);

            return { row, tagContainer };
        }

        const { row: titleRow, tagContainer: titleTags } = buildTagRow("Song Title", songTitle || []);
        const { row: primaryArtistRow, tagContainer: primaryArtistTags } = buildTagRow("Primary Artists", primaryArtists || []);
        const { row: featuredRow, tagContainer: featuredTags } = buildTagRow("Featured Artists", featuredArtists || []);
        const { row: writerRow, tagContainer: writerTags } = buildTagRow("Writers", writerArtists || []);
        const { row: producerRow, tagContainer: producerTags } = buildTagRow("Producers", producerArtists || []);
        const { row: youtubeRow, tagContainer: youtubeTags } = buildTagRow("YouTube URL", youtube || []);
        const { row: soundcloudRow, tagContainer: soundcloudTags } = buildTagRow("SoundCloud URL", soundcloud || []);
        const { row: artRow, tagContainer: artTags } = buildTagRow("Song Art", customSongArtImage || []);
        const { row: albumsRow, tagContainer: albumsTags } = buildTagRow("Albums", songAlbums || []);
        const { row: primaryTagRow, tagContainer: primaryTagTags } = buildTagRow("Primary Tag", primaryTags || []);
        const { row: secondaryTagRow, tagContainer: tagsTags } = buildTagRow("Tags", secondaryTags || []);
        const { row: releaseRow, tagContainer: releaseTags } = buildTagRow("Release Date", releaseDate || []);
        const { row: languageRow, tagContainer: languageTags } = buildTagRow("Language", songLanguage || []);
        const { row: recordedRow, tagContainer: recordedTags } = buildTagRow("Recorded At", recordedAt || []);

        const additionalRow = document.createElement("div");
        Object.assign(additionalRow.style, {
            display: "flex",
            flexDirection: "column",
            gap: "4px"
        });

        const headerRow = document.createElement("div");
        Object.assign(headerRow.style, {
            display: "grid",
            gridTemplateColumns: "225px 1fr",
            alignItems: "flex-start",
            gap: "16px"
        });

        const headerLeft = document.createElement("div");
        headerLeft.textContent = "Additional Credits";
        Object.assign(headerLeft.style, {
            fontWeight: "600",
            paddingTop: "6px"
        });

        const headerRight = document.createElement("div");

        headerRow.appendChild(headerLeft);
        headerRow.appendChild(headerRight);
        additionalRow.appendChild(headerRow);

        additionalCredits.forEach(entry => {
            const lineRow = document.createElement("div");
            Object.assign(lineRow.style, {
                display: "grid",
                gridTemplateColumns: "225px 1fr",
                alignItems: "flex-start",
                gap: "16px"
            });

            const roleLeft = document.createElement("div");
            roleLeft.textContent = `– ${entry.role}`;
            Object.assign(roleLeft.style, {
                fontWeight: "400"
            });

            const tagContainer = document.createElement("div");
            Object.assign(tagContainer.style, {
                display: "flex",
                flexWrap: "wrap",
                gap: "6px"
            });

            entry.artists.forEach(artist => {
                const tag = document.createElement("div");
                Object.assign(tag.style, tagStyle);

                const text = document.createElement("span");
                text.textContent = artist.name;

                const remove = document.createElement("span");
                remove.textContent = "×";
                Object.assign(remove.style, tagRemoveStyle);

                remove.addEventListener("click", () => {
                    tag.remove();
                    removeValueFromArray(entry.artists, artist);
                });

                tag.appendChild(text);
                tag.appendChild(remove);
                tagContainer.appendChild(tag);
            });

            lineRow.appendChild(roleLeft);
            lineRow.appendChild(tagContainer);
            additionalRow.appendChild(lineRow);
        });

        function appendIfNotEmpty(container, row, values) {
            if (Array.isArray(values)) {
                if (values.length > 0) container.appendChild(row);
            } else if (values) {
                container.appendChild(row);
            }
        }

        appendIfNotEmpty(table, titleRow, [songTitle]);
        appendIfNotEmpty(table, primaryArtistRow, primaryArtists);
        appendIfNotEmpty(table, featuredRow, featuredArtists);
        appendIfNotEmpty(table, writerRow, writerArtists);
        appendIfNotEmpty(table, producerRow, producerArtists);
        appendIfNotEmpty(table, additionalRow, additionalCredits);
        appendIfNotEmpty(table, youtubeRow, youtube);
        appendIfNotEmpty(table, soundcloudRow, soundcloud);
        appendIfNotEmpty(table, artRow, customSongArtImage);
        appendIfNotEmpty(table, albumsRow, songAlbums);
        appendIfNotEmpty(table, primaryTagRow, primaryTags);
        appendIfNotEmpty(table, secondaryTagRow, secondaryTags);
        appendIfNotEmpty(table, releaseRow, releaseDate);
        appendIfNotEmpty(table, languageRow, songLanguage);
        appendIfNotEmpty(table, recordedRow, recordedAt);


        const buttonRow = document.createElement("div");
        Object.assign(buttonRow.style, {
            display: "flex",
            flexDirection: "row",
            gap: "10px"
        });

        const createBtn = document.createElement("button");
        createBtn.textContent = "Recreate Song Page";

        const cancelBtn = document.createElement("button");
        cancelBtn.textContent = "Cancel";

        if (editmetadatabutonSmallbutton) {
            [createBtn, cancelBtn].forEach(btn => {
                btn.className = editmetadatabutonSmallbutton.className;
                Array.from(editmetadatabutonSmallbutton.attributes).forEach(attr => {
                    btn.setAttribute(attr.name, attr.value);
                });
                btn.style.width = "fit-content";
            });
        }

        const statusBox = document.createElement("div");
        statusBox.textContent = "";

        createBtn.addEventListener("click", async () => {
            createBtn.disabled = true;
            createBtn.style.pointerEvents = "none";
            createBtn.style.opacity = "0.5";

            async function waitWithStatus(seconds) {
                for (let i = seconds; i > 0; i--) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }

            async function runStepWithRetry(stepName, statusBox, fn, waitSeconds = 0) {
                const maxRetries = 3;

                for (let attempt = 1; attempt <= maxRetries; attempt++) {

                    if (attempt === 1) {
                        statusBox.textContent = `${stepName}`;
                    } else {
                        statusBox.textContent = `${stepName} (attempt ${attempt}/${maxRetries})`;
                    }

                    if (waitSeconds > 0) await waitWithStatus(waitSeconds);

                    const success = await fn();
                    if (success) {
                        statusBox.textContent = `${stepName}`;
                        return true;
                    }

                    statusBox.textContent = `${stepName} failed (${attempt}/${maxRetries}), retrying in 10s...`;
                    await waitWithStatus(10);
                }

                statusBox.textContent = `${stepName} failed (${maxRetries}/${maxRetries}). Aborting.`;
                return false;
            }


            const albumTracklists = {};
            let newSongId = null;


            // ----------------------------------------------------
            // STEP 1: GET TRACKLISTS
            // ----------------------------------------------------
            async function stepGetTracklists() {
                try {
                    if (!songAlbums.length) return true;

                    for (const album of songAlbums) {
                        let allTracks = [];
                        let page = 1;
                        let nextPage = 1;

                        while (nextPage) {
                            const response = await fetch(`https://genius.com/api/albums/${album.id}/tracks?page=${page}`);
                            if (!response.ok) return false;

                            const json = await response.json();
                            const tracks = json.response.tracks || [];
                            allTracks.push(...tracks);

                            nextPage = json.response.next_page;
                            page = nextPage;
                        }

                        albumTracklists[album.id] = allTracks;
                    }

                    console.log("Album Tracklists:", albumTracklists);
                    return true;

                } catch {
                    return false;
                }
            }

            if (!(await runStepWithRetry("Getting albums tracklist of the existing song", statusBox, stepGetTracklists, 1))) return;


            // ----------------------------------------------------
            // STEP 2: SET PRIMARY ARTIST TO SHELLY
            // ----------------------------------------------------
            const shellyPayload = { primary_artists: [{ id: 3703683, name: "Shelly The Cleanup Bot" }] };

            async function stepSetShelly() {
                try {
                    const result = await updateSongMetadata(songId, shellyPayload);
                    return !!result && result.ok;
                } catch {
                    return false;
                }
            }

            if (!(await runStepWithRetry("Changing primary artist to 'Shelly The Cleanup Bot'", statusBox, stepSetShelly, 1))) return;


            // ----------------------------------------------------
            // STEP 3: CREATE NEW SONG
            // ----------------------------------------------------
            async function stepCreateSong() {
                try {
                    const song = {};

                    if (songTitle?.[0]?.name) song.title = songTitle[0].name;
                    if (primaryArtists.length) song.primary_artists = primaryArtists.map(a => ({ id: a.id, name: a.name }));
                    if (featuredArtists.length) song.featured_artists = featuredArtists.map(a => ({ id: a.id, name: a.name }));
                    if (writerArtists.length) song.writer_artists = writerArtists.map(a => ({ id: a.id, name: a.name }));
                    if (producerArtists.length) song.producer_artists = producerArtists.map(a => ({ id: a.id, name: a.name }));
                    if (additionalCredits.length) { song.custom_performances = additionalCredits.map(c => { const artistsWithName = c.artists.filter(a => a && a.name); if (!artistsWithName.length) return null; return { label: c.role, artists: artistsWithName.map(a => ({ id: a.id, name: a.name })) }; }).filter(Boolean); }
                    if (primaryTags?.[0]?.id) song.primary_tag_id = primaryTags[0].id;
                    if (secondaryTags.length) song.tags = secondaryTags.map(t => ({ id: t.id, name: t.name }));
                    if (songAlbums.length) song.albums = songAlbums.map(a => ({ id: a.id, name: a.name }));
                    if (releaseDate?.[0]) { song.release_date_components = { day: releaseDate[0].day, month: releaseDate[0].month, year: releaseDate[0].year }; }
                    if (songLanguage?.[0]?.name) song.language = songLanguage[0].name;
                    if (recordedAt?.[0]?.name) song.recorded_at = recordedAt[0].name;
                    if (youtube?.[0]?.url) song.youtube_url = youtube[0].url;
                    if (youtube?.[0]?.start) song.youtube_start = youtube[0].start;
                    if (soundcloud?.[0]?.url) song.soundcloud_url = soundcloud[0].url;
                    if (customSongArtImage?.[0]?.url) song.custom_song_art_image_url = customSongArtImage[0].url;
                    song.lyrics_state = "incomplete";
                    song.lyrics = "";

                    const createPayload = {
                        text_format: "html,markdown,preview",
                        song
                    };

                    const result = await createSong(createPayload);
                    newSongId = result?.response?.song?.id;

                    return !!newSongId;
                } catch {
                    return false;
                }
            }

            if (!(await runStepWithRetry("Creating new song", statusBox, stepCreateSong, 1))) return;


            // ----------------------------------------------------
            // STEP 4: DELETE OLD SONG
            // ----------------------------------------------------
            async function stepDeleteOldSong() {
                try {
                    const ok = await deleteId(songId, "songs");
                    return ok;
                } catch {
                    return false;
                }
            }

            if (!(await runStepWithRetry("Deleting old song", statusBox, stepDeleteOldSong, 1))) return;


            // ----------------------------------------------------
            // STEP 5: UPDATE TRACKLISTS
            // ----------------------------------------------------
            async function stepUpdateTracklists() {
                try {
                    for (const album of songAlbums) {
                        const oldTracks = albumTracklists[album.id];
                        const oldSong = oldTracks.find(t => t.song.id === songId);

                        if (oldSong && oldSong.disc_track_number == null) continue;

                        const payload = oldTracks.map(t => ({
                            disc_track_number: t.disc_track_number,
                            disc_number: t.disc_number,
                            song_id: t.song.id === songId ? newSongId : t.song.id
                        }));

                        const ok = await updateTracklist(album.id, payload);
                        if (!ok) return false;
                    }

                    return true;
                } catch {
                    return false;
                }
            }

            if (songAlbums.length > 0) {
                const hasHugeTracklist = songAlbums.some(album => {
                    const tracks = albumTracklists[album.id];
                    return tracks && tracks.length > 200;
                });

                if (hasHugeTracklist) {
                    statusBox.textContent = "Done (skipped tracklist update: album has more than 200 tracks)";
                    await waitWithStatus(2);
                } else {
                    if (!(await runStepWithRetry("Updating album tracklists", statusBox, stepUpdateTracklists, 3))) return;
                }
            }


            // ----------------------------------------------------
            // DONE
            // ----------------------------------------------------
            statusBox.textContent = "Done";
            await waitWithStatus(2);

            overlay.remove();
            document.body.style.overflow = "";
        });

        cancelBtn.addEventListener("click", () => {
            overlay.remove();
            document.body.style.overflow = "";
        });

        buttonRow.appendChild(createBtn);
        buttonRow.appendChild(cancelBtn);
        buttonRow.appendChild(statusBox);


        modal.appendChild(table);
        modal.appendChild(buttonRow);

        overlay.appendChild(modal);
        document.body.appendChild(overlay);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               TRANSLATION BUTTON                               //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    const LANGUAGE_CONFIG = [
        {
            value: "Afrikaans",
            language: "af",
            artistName: "Genius Afrikaanse Vertalings",
            tagId: "5262",
            titleSuffix: "Afrikaanse Vertaling",
            urlSlug: "Genius-afrikaanse-vertalings"
        },
        {
            value: "Albanian",
            language: "sq",
            artistName: "Genius Përkthime në Shqip",
            tagId: "3771",
            titleSuffix: "Përkthim në Shqip",
            urlSlug: "Genius-perkthime-ne-shqip"
        },
        {
            value: "Amharic",
            language: "am",
            artistName: "Genius Amharic Translations (የአማርኛ ትርጉም)",
            tagId: "347", //Translation
            titleSuffix: "",
            urlSlug: "Genius-amharic-translations"
        },
        {
            value: "Arabic",
            language: "ar",
            artistName: "Genius Arabic Translations (الترجمات العربية)",
            tagId: "3504",
            titleSuffix: "الترجمة العربية",
            urlSlug: "Genius-arabic-translations"
        },
        {
            value: "Aragonese",
            language: "es",
            artistName: "Genius Aragonese Translations",
            tagId: "347", //Translation
            titleSuffix: "Traducción Aragonés",
            urlSlug: "Genius-aragonese-translations"
        },
        {
            value: "Armenian",
            language: "hy",
            artistName: "Genius Armenian Translations (Հայերեն Թարգմանություններ)",
            tagId: "347", //Translation
            titleSuffix: "Հայերեն Թարգմանություն",
            urlSlug: "Genius-armenian-translations"
        },
        {
            value: "Asturian",
            language: "es",
            artistName: "Genius Asturian Translations",
            tagId: "347", //Translation
            titleSuffix: "Traducción asturiana",
            urlSlug: "Genius-asturian-translations"
        },
        {
            value: "Austrian",
            language: "de-at",
            artistName: "Genius Österreichische Übersetzungen",
            tagId: "347", //Translation
            titleSuffix: "Österreichische Übersetzung",
            urlSlug: "Genius-osterreichische-ubersetzungen"
        },
        {
            value: "Azerbaijani",
            language: "az",
            artistName: "Genius Azərbaycan Tərcümə",
            tagId: "3644",
            titleSuffix: "Azərbaycan Tərcümə",
            urlSlug: "Genius-azrbaycan-trcum"
        },
        {
            value: "Bashkir",
            language: "ba",
            artistName: "Genius Bashkir Translations",
            tagId: "347", //Translation
            titleSuffix: "Башҡорт теленә тәржемә",
            urlSlug: "Genius-bashkir-translations"
        },
        {
            value: "Basque",
            language: "eu",
            artistName: "Genius Itzulpena Euskarara",
            tagId: "347", //Translation
            titleSuffix: "Itzulpena Euskarara",
            urlSlug: "Genius-itzulpena-euskarara"
        },
        {
            value: "Belarusian",
            language: "be",
            artistName: "Genius Belarusian Translations (Беларускі пераклад)",
            tagId: "4341",
            titleSuffix: "Беларускі пераклад",
            urlSlug: "Genius-belarusian-translations"
        },
        {
            value: "Bengali",
            language: "bn",
            artistName: "Genius Bengali Translations (বাংলা অনুবাদ)",
            tagId: "5280",
            titleSuffix: "বাংলা অনুবাদ",
            urlSlug: "Genius-bengali-translations"
        },
        {
            value: "Bosnian",
            language: "bs",
            artistName: "Genius bosanski prijevodi",
            tagId: "5624",
            titleSuffix: "Bosanski prijevod",
            urlSlug: "Genius-bosanski-prijevodi"
        },
        {
            value: "Bulgarian",
            language: "bg",
            artistName: "Genius Bulgarian Translations (Български преводи)",
            tagId: "5278",
            titleSuffix: "Български превод",
            urlSlug: "Genius-bulgarian-translations"
        },
        {
            value: "Burmese",
            language: "my",
            artistName: "Genius Burmese Translations",
            tagId: "347", //Translation
            titleSuffix: "မြန်မာဘာသာပြန်",
            urlSlug: "Genius-burmese-translations"
        },
        {
            value: "Cape Verdean Creole",
            language: "kea",
            artistName: "Genius Tradusons na Kriolu Kabuverdianu",
            tagId: "347", //Translation
            titleSuffix: "Traduson na Kriolu Kabuverdianu",
            urlSlug: "Genius-tradusons-na-kriolu-kabuverdianu"
        },
        {
            value: "Catalan",
            language: "ca",
            artistName: "Genius Traduccions al Català",
            tagId: "4292",
            titleSuffix: "Traducció al Català",
            urlSlug: "Genius-traduccions-al-catala"
        },
        {
            value: "Cebuano",
            language: "ceb",
            artistName: "Genius Cebuano Translations",
            tagId: "347", //Translation
            titleSuffix: "Cebuano Translation",
            urlSlug: "Genius-cebuano-translations"
        },
        {
            value: "Cherokee",
            language: "chr",
            artistName: "Genius Cherokee Translations",
            tagId: "347", //Translation
            titleSuffix: "Cherokee syllabary",
            urlSlug: "Genius-cherokee-translations"
        },
        {
            value: "Chinese (Simplified)",
            language: "zh",
            artistName: "Genius Chinese Translations (中文翻譯/中文翻译)",
            tagId: "5277",
            titleSuffix: "中文翻译 - Simplified",
            urlSlug: "Genius-chinese-translations"
        },
        {
            value: "Chinese (Traditional)",
            language: "zh-Hant",
            artistName: "Genius Chinese Translations (中文翻譯/中文翻译)",
            tagId: "5276",
            titleSuffix: "中文翻譯 - Traditional",
            urlSlug: "Genius-chinese-translations"
        },
        {
            value: "Croatian",
            language: "hr",
            artistName: "Genius hrvatski prijevodi",
            tagId: "5263",
            titleSuffix: "Hrvatski prijevod",
            urlSlug: "Genius-hrvatski-prijevodi"
        },
        {
            value: "Czech",
            language: "cs",
            artistName: "Genius České překlady",
            tagId: "4473",
            titleSuffix: "Český překlad",
            urlSlug: "Genius-ceske-preklady"
        },
        {
            value: "Danish",
            language: "da",
            artistName: "Genius Danske Oversættelser",
            tagId: "4801",
            titleSuffix: "Dansk Oversættelse",
            urlSlug: "Genius-danske-oversttelser"
        },
        {
            value: "Dutch",
            language: "nl",
            artistName: "Genius Nederlandse Vertalingen",
            tagId: "3268",
            titleSuffix: "Nederlandse Vertaling",
            urlSlug: "Genius-nederlandse-vertalingen"
        },
        {
            value: "English",
            language: "en",
            artistName: "Genius English Translations",
            tagId: "3269",
            titleSuffix: "English Translation",
            urlSlug: "Genius-english-translations"
        },
        {
            value: "Estonian",
            language: "et",
            artistName: "Genius Eestikeelsed tõlked",
            tagId: "5623",
            titleSuffix: "Eesti Tõlge",
            urlSlug: "Genius-eestikeelsed-tolked"
        },
        {
            value: "Farsi",
            language: "fa",
            artistName: "Genius Farsi Translations (ترجمه‌ی فارسی)",
            tagId: "3546",
            titleSuffix: "ترجمه فارسی",
            urlSlug: "Genius-farsi-translations"
        },
        {
            value: "Filipino",
            language: "tl",
            artistName: "Genius Pagsasalin Sa Filipino",
            tagId: "5213",
            titleSuffix: "Pagsasalin sa Filipino",
            urlSlug: "Genius-pagsasalin-sa-filipino"
        },
        {
            value: "Finnish",
            language: "fi",
            artistName: "Genius Suomenkielinen Käännös",
            tagId: "5279",
            titleSuffix: "Suomenkielinen Käännös",
            urlSlug: "Genius-suomenkielinen-kaannos"
        },
        {
            value: "French",
            language: "fr",
            artistName: "Genius traductions françaises",
            tagId: "3267",
            titleSuffix: "Traduction française",
            urlSlug: "Genius-traductions-francaises"
        },
        {
            value: "Galacian",
            language: "gl",
            artistName: "Genius Traducións ao Galego",
            tagId: "347", //Translation
            titleSuffix: "Tradución ao galego",
            urlSlug: "Genius-traducions-ao-galego"
        },
        {
            value: "Georgian",
            language: "ka",
            artistName: "Genius Georgian Translations (ქართული თარგმანები)",
            tagId: "347", //Translation
            titleSuffix: "ქართული თარგმანი",
            urlSlug: "Genius-georgian-translations"
        },
        {
            value: "German",
            language: "de",
            artistName: "Genius Deutsche Übersetzungen",
            tagId: "2405",
            titleSuffix: "Deutsche Übersetzung",
            urlSlug: "Genius-deutsche-ubersetzungen"
        },
        {
            value: "Greek",
            language: "el",
            artistName: "Genius Greek Translations (Ελληνικές μεταφράσεις)",
            tagId: "4077",
            titleSuffix: "Ελληνική μετάφραση",
            urlSlug: "Genius-greek-translations"
        },
        {
            value: "Guarani",
            language: "gn",
            artistName: "Genius Guarani Translations",
            tagId: "347", //Translation
            titleSuffix: "Guarani Translation",
            urlSlug: "Genius-guarani-translations"
        },
        {
            value: "Hawaiian",
            language: "haw",
            artistName: "Genius Unuhi ʻŌlelo Hawaiʻi",
            tagId: "347", //Translation
            titleSuffix: "Unuhi ʻŌlelo Hawaiʻi",
            urlSlug: "Genius-unuhi-olelo-hawaii"
        },
        {
            value: "Hebrew",
            language: "iw",
            artistName: "Genius Hebrew Translations - ג’ינייס תרגומים לעברית",
            tagId: "3849",
            titleSuffix: "תרגום לעברית",
            urlSlug: "Genius-hebrew-translations"
        },
        {
            value: "High German",
            language: "de",
            artistName: "Genius Hochdeutsche Übersetzungen",
            tagId: "3962",
            titleSuffix: "Hochdeutsche Übersetzung",
            urlSlug: "Genius-hochdeutsche-ubersetzungen"
        },
        {
            value: "Hindi",
            language: "hi",
            artistName: "Genius Hindi Translations (हिंदी अनुवाद)",
            tagId: "4177",
            titleSuffix: "हिंदी अनुवाद",
            urlSlug: "Genius-hindi-translations"
        },
        {
            value: "Hungarian",
            language: "hu",
            artistName: "Genius magyar fordítások",
            tagId: "3949",
            titleSuffix: "magyar fordítás",
            urlSlug: "Genius-magyar-forditasok"
        },
        {
            value: "Icelandic",
            language: "is",
            artistName: "Genius Íslensk Þýðingar",
            tagId: "347", //Translation
            titleSuffix: "Íslensk Þýðing",
            urlSlug: "Genius-islensk-yingar"
        },
        {
            value: "Ilocano",
            language: "tl",
            artistName: "Genius Ilocano Translations",
            tagId: "347", //Translation
            titleSuffix: "Ilocano Translation",
            urlSlug: "Genius-ilocano-translations"
        },
        {
            value: "Indonesian",
            language: "id",
            artistName: "Genius Terjemahan Indonesia",
            tagId: "4295",
            titleSuffix: "Terjemahan Indonesia",
            urlSlug: "Genius-terjemahan-indonesia"
        },
        {
            value: "Inuktitut",
            language: "iu",
            artistName: "Genius Inuktitut Translations",
            tagId: "347", //Translation
            titleSuffix: "ᐃᓄᒃᑎᑐᑦ ᐃᓄᒃᑎᑑᓕᖅᑎᑕᐅᓂᖅ",
            urlSlug: "Genius-inuktitut-translations"
        },
        {
            value: "Irish",
            language: "ga",
            artistName: "Genius Aistriúcháin Gaeilge",
            tagId: "347", //Translation
            titleSuffix: "Aistriúchán Gaeilge",
            urlSlug: "Genius-aistriuchain-gaeilge"
        },
        {
            value: "Italian",
            language: "it",
            artistName: "Genius Traduzioni Italiane",
            tagId: "3270",
            titleSuffix: "Traduzione Italiana",
            urlSlug: "Genius-traduzioni-italiane"
        },
        {
            value: "Japanese",
            language: "ja",
            artistName: "Genius Japanese Translations (歌詞和訳)",
            tagId: "4035",
            titleSuffix: "歌詞和訳",
            urlSlug: "Genius-japanese-translations"
        },
        {
            value: "Kannada",
            language: "kn",
            artistName: "Genius Kannada Translations (ಕನ್ನಡ ಭಾಷಾಂತರ)",
            tagId: "347", //Translation
            titleSuffix: "ಕನ್ನಡ ಅನುವಾದ",
            urlSlug: "Genius-kannada-translations"
        },
        {
            value: "Kazakh",
            language: "kk",
            artistName: "Genius Kazakh Translations (Қазақша Аудармалар)",
            tagId: "347", //Translation
            titleSuffix: "Қазақша Аударма",
            urlSlug: "Genius-kazakh-translations"
        },
        {
            value: "Khmer",
            language: "km",
            artistName: "Genius Khmer Translations",
            tagId: "347", //Translation
            titleSuffix: "បកប្រែខ្មែរ",
            urlSlug: "Genius-khmer-translations"
        },
        {
            value: "Korean",
            language: "ko",
            artistName: "Genius Korean Translations (한국어 번역)",
            tagId: "4111",
            titleSuffix: "한국어 번역",
            urlSlug: "Genius-korean-translations"
        },
        {
            value: "Kurdish",
            language: "ku",
            artistName: "Genius Kurdish Translations (وەڕگێڕانەکانی کوردی)",
            tagId: "347", //Translation
            titleSuffix: "وەرگێڕانی کوردی",
            urlSlug: "Genius-kurdish-translations"
        },
        {
            value: "Latin",
            language: "la",
            artistName: "Genius Translationes Latina",
            tagId: "347", //Translation
            titleSuffix: "Translatio Latina",
            urlSlug: "Genius-translationes-latina"
        },
        {
            value: "Latvian",
            language: "lv",
            artistName: "Genius Latviešu Tulkojums",
            tagId: "5282",
            titleSuffix: "Latviešu Tulkojums",
            urlSlug: "Genius-latviesu-tulkojums"
        },
        {
            value: "Lithuanian",
            language: "lt",
            artistName: "Genius Lietuviškos Vertimai",
            tagId: "347", //Translation
            titleSuffix: "Lietuvių Kalbos Vertimas",
            urlSlug: "Genius-lietuviskos-vertimai"
        },
        {
            value: "Low German",
            language: "de",
            artistName: "Genius Plattdeutsche Übersetzungen",
            tagId: "5626",
            titleSuffix: "Plattdeutsche Übersetzung",
            urlSlug: "Genius-plattdeutsche-ubersetzungen"
        },
        {
            value: "Luxembourgish",
            language: "lb",
            artistName: "Genius Lëtzebuergesch Iwwersetzungen",
            tagId: "347", //Translation
            titleSuffix: "Lëtzebuergesch Iwwersetzung",
            urlSlug: "Genius-letzebuergesch-iwwersetzungen"
        },
        {
            value: "Macedonian",
            language: "mk",
            artistName: "Genius Makedonski Prevodi",
            tagId: "4342",
            titleSuffix: "Македонски превод",
            urlSlug: "Genius-makedonski-prevodi"
        },
        {
            value: "Malay",
            language: "ms",
            artistName: "Terjemahan Bahasa Melayu Genius",
            tagId: "5475",
            titleSuffix: "Terjemahan Bahasa Melayu",
            urlSlug: "Terjemahan-bahasa-melayu-genius"
        },
        {
            value: "Malayalam",
            language: "ml",
            artistName: "Genius Malayalam Translations (മലയാളം പരിഭാഷ)",
            tagId: "347", //Translation
            titleSuffix: "മലയാളം പരിഭാഷ",
            urlSlug: "Genius-malayalam-translations"
        },
        {
            value: "Mongolian",
            language: "mn",
            artistName: "Genius Mongolian Translations (Монгол орчуулга)",
            tagId: "347", //Translation
            titleSuffix: "Монгол орчуулга",
            urlSlug: "Genius-mongolian-translations"
        },
        {
            value: "Nepali",
            language: "ne",
            artistName: "Genius Nepali Translations (नेपाली आनुवाद)",
            tagId: "347", //Translation
            titleSuffix: "नेपाली आनुवाद",
            urlSlug: "Genius-nepali-translations"
        },
        {
            value: "Northern Sotho",
            language: "st",
            artistName: "Genius Liphetolelo yaSesotho",
            tagId: "347", //Translation
            titleSuffix: "Phetolelo ya Sesotho",
            urlSlug: "Genius-liphetolelo-yasesotho"
        },
        {
            value: "Norwegian",
            language: "no",
            artistName: "Genius Norske Oversettelser",
            tagId: "4368",
            titleSuffix: "Norsk Oversettelse",
            urlSlug: "Genius-norske-oversettelser"
        },
        {
            value: "Pashto",
            language: "ps",
            artistName: "Genius Pashto Translations (پښتو ژباړې)",
            tagId: "347", //Translation
            titleSuffix: "پښتو ژباړه",
            urlSlug: "Genius-pashto-translations"
        },
        {
            value: "Polish",
            language: "pl",
            artistName: "Polskie tłumaczenia Genius",
            tagId: "3645",
            titleSuffix: "polskie tłumaczenie",
            urlSlug: "Polskie-tumaczenia-genius"
        },
        {
            value: "Portuguese (Brazil)",
            language: "pt",
            artistName: "Genius Brasil Traduções",
            tagId: "2281",
            titleSuffix: "Tradução em Português",
            urlSlug: "Genius-brasil-traducoes"
        },
        {
            value: "Portuguese (European)",
            language: "pt",
            artistName: "Genius Portugal Traduções",
            tagId: "2281",
            titleSuffix: "Tradução em Português de Portugal",
            urlSlug: "Genius-portugal-traducoes"
        },
        {
            value: "Punjabi",
            language: "pa",
            artistName: "Genius Punjabi Translations (ਗੁਰਮੁਖੀ/شاہ مُکھی)",
            tagId: "347", //Translation
            titleSuffix: "شاہ مُکھی پنجابی",
            urlSlug: "Genius-punjabi-translations"
        },
        {
            value: "Reintegrated Galician",
            language: "pt",
            artistName: "Genius Traducións ao Galego Reintegrado",
            tagId: "347", //Translation
            titleSuffix: "Tradución ao Galego Reintegrado",
            urlSlug: "Genius-traducions-ao-galego-reintegrado"
        },
        {
            value: "Romanian",
            language: "ro",
            artistName: "Genius traduceri în română",
            tagId: "4028",
            titleSuffix: "Traducere în română",
            urlSlug: "Genius-traduceri-in-romana"
        },
        {
            value: "Romanizations",
            language: "romanization",
            artistName: "Genius Romanizations",
            tagId: "3646",
            titleSuffix: "Romanized",
            urlSlug: "Genius-romanizations"
        },
        {
            value: "Russian",
            language: "ru",
            artistName: "Genius Russian Translations (Русский перевод)",
            tagId: "3274",
            titleSuffix: "Русский перевод",
            urlSlug: "Genius-russian-translations"
        },
        {
            value: "Sakha",
            language: "sah",
            artistName: "Genius Sakha Translations (Сахалыы Тылбаастар)",
            tagId: "347", //Translation
            titleSuffix: "Сахалыы Тылбаас",
            urlSlug: "Genius-sakha-translations"
        },
        {
            value: "Samoan",
            language: "sm",
            artistName: "Genius Samoan Translations",
            tagId: "347", //Translation
            titleSuffix: "Samoan Translation",
            urlSlug: "Genius-samoan-translations"
        },
        {
            value: "Serbian",
            language: "sr",
            artistName: "Genius srpski prevodi",
            tagId: "3899",
            titleSuffix: "Srpski prevod",
            urlSlug: "Genius-srpski-prevodi"
        },
        {
            value: "Sinhala",
            language: "si",
            artistName: "Genius Sinhala Translations (සිංහල පරිවර්තන)",
            tagId: "4554",
            titleSuffix: "සිංහල පරිවර්තන",
            urlSlug: "Genius-sinhala-translations"
        },
        {
            value: "Slovak",
            language: "sk",
            artistName: "Genius Slovenské preklady",
            tagId: "5627",
            titleSuffix: "Slovenský Preklad",
            urlSlug: "Genius-slovenske-preklady"
        },
        {
            value: "Slovenian",
            language: "sl",
            artistName: "Genius Slovenski Prevod",
            tagId: "4886",
            titleSuffix: "Slovenski Prevod",
            urlSlug: "Genius-slovenski-prevod"
        },
        {
            value: "Spanish",
            language: "es",
            artistName: "Genius Traducciones al Español",
            tagId: "3447",
            titleSuffix: "Traducción al Español",
            urlSlug: "Genius-traducciones-al-espanol"
        },
        {
            value: "Swahili",
            language: "sw",
            artistName: "Genius Swahili Translations",
            tagId: "5628",
            titleSuffix: "Swahili Translation",
            urlSlug: "Genius-swahili-translations"
        },
        {
            value: "Swedish",
            language: "sv",
            artistName: "Genius Svenska Översättningar",
            tagId: "3786",
            titleSuffix: "Svensk Översättning",
            urlSlug: "Genius-svenska-oversattningar"
        },
        {
            value: "Tamazight",
            language: "",
            artistName: "Genius Tamazight Translations",
            tagId: "347", //Translation
            titleSuffix: "ⵜⴰⵎⴰⵣⵉⵖⵜ",
            urlSlug: "Genius-tamazight-translations"
        },
        {
            value: "Tamil",
            language: "ta",
            artistName: "Genius Tamil Translations (தமிழ் மொழிபெயர்ப்பு)",
            tagId: "347", //Translation
            titleSuffix: "தமிழ் மொழிபெயர்ப்பு",
            urlSlug: "Genius-tamil-translations"
        },
        {
            value: "Tatar",
            language: "tt",
            artistName: "Genius Tatar Translations (Татарча тәрҗемәләре)",
            tagId: "347", //Translation
            titleSuffix: "Татар тәрҗемәсе",
            urlSlug: "Genius-tatar-translations"
        },
        {
            value: "Telugu",
            language: "te",
            artistName: "Genius Telugu Translations (తెలుగు అనువాదాలు)",
            tagId: "347", //Translation
            titleSuffix: "తెలుగు అనువాదాలు",
            urlSlug: "Genius-telugu-translations"
        },
        {
            value: "Thai",
            language: "th",
            artistName: "Genius Thai Translations (คำแปลภาษาไทย)",
            tagId: "4482",
            titleSuffix: "แปลภาษาไทย",
            urlSlug: "Genius-thai-translations"
        },
        {
            value: "Toki Pona",
            language: "",
            artistName: "Genius toki pona pi toki ante",
            tagId: "347", //Translation
            titleSuffix: "toki ni li kama toki pona",
            urlSlug: "Genius-toki-pona-pi-toki-ante"
        },
        {
            value: "Turkish",
            language: "tr",
            artistName: "Genius Türkçe Çeviriler",
            tagId: "3299",
            titleSuffix: "Türkçe Çeviri",
            urlSlug: "Genius-turkce-ceviriler"
        },
        {
            value: "Twi",
            language: "ak",
            artistName: "Genius Twi ɔkasadán",
            tagId: "347", //Translation
            titleSuffix: "Twi ɔkasadán",
            urlSlug: "Genius-twi-kasadan"
        },
        {
            value: "Ukrainian",
            language: "uk",
            artistName: "Genius Ukrainian Translations (Українські переклади)",
            tagId: "4225",
            titleSuffix: "Український переклад",
            urlSlug: "Genius-ukrainian-translations"
        },
        {
            value: "Urdu",
            language: "ur",
            artistName: "Genius Urdu Translations (اردو تراجم)",
            tagId: "5345",
            titleSuffix: "اردو ترجمہ",
            urlSlug: "Genius-urdu-translations"
        },
        {
            value: "Uzbek",
            language: "uz",
            artistName: "Genius Oʻzbekcha Tarjimalar",
            tagId: "347", //Translation
            titleSuffix: "Oʻzbekcha Tarjima",
            urlSlug: "Genius-ozbekcha-tarjimalar"
        },
        {
            value: "Vietnamese",
            language: "vi",
            artistName: "Genius Bản dịch tiếng Việt",
            tagId: "4497",
            titleSuffix: "Bản dịch tiếng Việt",
            urlSlug: "Genius-ban-dich-tieng-viet"
        },
        {
            value: "Welsh",
            language: "cy",
            artistName: "Genius Cyfieithiadau Cymraeg",
            tagId: "347", //Translation
            titleSuffix: "Cyfieithiad Cymraeg",
            urlSlug: "Genius-cyfieithiadau-cymraeg"
        },
        {
            value: "Xhosa",
            language: "xh",
            artistName: "Genius Izinguqulelo yesiXhosa",
            tagId: "347", //Translation
            titleSuffix: "Inguqulelo yesiXhosa",
            urlSlug: "Genius-izinguqulelo-yesixhosa"
        }
    ];

    function addTranslationButton(songs, songId, songTitle, primaryArtistNames, featuredArtistsRaw, artists, primaryTag, releaseDateComponents, customSongArtImageUrl, youtubeUrl, youtubeStart) {
        console.log("Run function addTranslationButton()");

        const currentUrl = window.location.href.toLowerCase();
        const isTranslationPage = LANGUAGE_CONFIG.some(cfg =>
            currentUrl.includes(`/artists/${cfg.urlSlug.toLowerCase()}`) ||
            currentUrl.includes(`/${cfg.urlSlug.toLowerCase()}-`)
        );

        // No button on translation pages
        if (isTranslationPage) return;

        const { adminSpan } = getDomElements();
        if (!adminSpan) return;

        const dropdownContainer = adminSpan.closest('[class^="Dropdown__Container-"]');
        if (!dropdownContainer) return;

        const list = dropdownContainer.querySelector('[class^="StickyToolbarDropdown__DropdownItems-"]');
        if (!list) return;

        if (document.getElementById("translation-btn")) return;

        const existingButton = list.querySelector("button");
        const existingLi = list.querySelector("li");
        if (!existingButton || !existingLi) return;

        const li = document.createElement("li");
        li.className = existingLi.className;

        const btn = document.createElement("button");
        btn.type = "button";
        btn.id = "translation-btn";
        btn.textContent = "Create Translation";
        btn.className = existingButton.className;

        btn.addEventListener("click", () => {
            const featuredArtists = (featuredArtistsRaw || [])
                .map(id => artists[id]?.name || "")
                .map(name => name.replace(/ *\([^)]*\) */g, "").replace(/\u200B/g, "").trim());

            openTranslationModal(songs, songId, songTitle, primaryArtistNames, featuredArtists, primaryTag, releaseDateComponents, customSongArtImageUrl, youtubeUrl, youtubeStart);
        });

        li.appendChild(btn);
        list.appendChild(li);
    }

    function openTranslationModal(songs, songId, songTitle, primaryArtistNames, featuredArtistsRaw, primaryTag, releaseDateComponents, customSongArtImageUrl, youtubeUrl, youtubeStart) {
        const { editmetadatabutonSmallbutton } = getDomElements();
        if (document.getElementById("create-translation-modal")) return;

        const translations = songs?.[songId]?.songRelationships?.find(r => r.relationshipType === "translations")?.songs || [];
        const existingTranslationLanguages = LANGUAGE_CONFIG.filter(cfg => translations.some(id => songs?.[id]?.artistNames === cfg.artistName)).map(cfg => cfg.value);

        document.body.style.overflow = "hidden";

        const baseInputStyle = {
            width: "100%",
            padding: "7.75px 8px",
            fontSize: "0.8em",
            border: "1px solid #ccc",
            borderRadius: "4px",
            minHeight: "32px"
        };

        const baseBoxStyle = {
            padding: "6px 8px",
            fontSize: "0.8em",
            border: "1px solid #ccc",
            borderRadius: "4px",
            background: "#f9f9f9",
            minHeight: "32px"
        };

        const columnStyle = {
            display: "flex",
            flexDirection: "column",
            flex: "1",
            gap: "4px"
        };

        const overlay = document.createElement("div");
        Object.assign(overlay.style, {
            position: "fixed",
            top: "0",
            left: "0",
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: "9999"
        });

        const modal = document.createElement("div");
        Object.assign(modal.style, {
            background: "#fff",
            padding: "20px",
            borderRadius: "8px",
            width: "800px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
            display: "flex",
            flexDirection: "column",
            gap: "18px"
        });

        const row = document.createElement("div");
        Object.assign(row.style, {
            display: "flex",
            flexDirection: "row",
            gap: "20px"
        });

        // --- Language Column ---
        const languageWrapper = document.createElement("div");
        Object.assign(languageWrapper.style, columnStyle);

        const languageLabel = document.createElement("label");
        languageLabel.textContent = "Language";
        languageLabel.style.fontWeight = "600";

        const languageSelect = document.createElement("select");
        Object.assign(languageSelect.style, {
            width: "100%",
            padding: "6.75px 8px",
            fontSize: "0.8em",
            border: "1px solid #ccc",
            borderRadius: "4px"
        });

        const placeholder = document.createElement("option");
        placeholder.value = "";
        placeholder.textContent = "Select language";
        placeholder.disabled = true;
        placeholder.selected = true;
        languageSelect.appendChild(placeholder);

        // Remove existing translation languages from the dropdown
        LANGUAGE_CONFIG
            .map(cfg => cfg.value)
            .sort()
            .filter(lang => !existingTranslationLanguages.includes(lang))
            .forEach(lang => {
                const opt = document.createElement("option");
                opt.value = lang;
                opt.textContent = lang;
                languageSelect.appendChild(opt);
            });

        languageWrapper.appendChild(languageLabel);
        languageWrapper.appendChild(languageSelect);

        // --- Artist Column ---
        const artistWrapper = document.createElement("div");
        Object.assign(artistWrapper.style, columnStyle);

        const artistLabel = document.createElement("label");
        artistLabel.textContent = "Artist";
        artistLabel.style.fontWeight = "600";

        const artistValue = document.createElement("div");
        Object.assign(artistValue.style, baseBoxStyle);
        artistValue.textContent = "";

        function updateArtistValue() {
            const selectedLang = languageSelect.value;
            if (!selectedLang) {
                artistValue.textContent = "";
                return;
            }
            const cfg = LANGUAGE_CONFIG.find(c => c.value === selectedLang);
            artistValue.textContent = cfg ? cfg.artistName : "";
            updateTitleValue();
        }

        artistWrapper.appendChild(artistLabel);
        artistWrapper.appendChild(artistValue);

        row.appendChild(languageWrapper);
        row.appendChild(artistWrapper);

        // --- Title Row ---
        const titleRow = document.createElement("div");
        Object.assign(titleRow.style, {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "14px"
        });

        const titleWrapper = document.createElement("div");
        Object.assign(titleWrapper.style, {
            display: "flex",
            flexDirection: "column",
            flex: "1",
            gap: "4px"
        });

        const titleLabel = document.createElement("label");
        titleLabel.textContent = "Title";
        titleLabel.style.fontWeight = "600";

        const titleInput = document.createElement("input");
        titleInput.type = "text";
        Object.assign(titleInput.style, {
            width: "100%",
            padding: "7.75px 8px",
            fontSize: "0.8em",
            border: "1px solid #ccc",
            borderRadius: "4px",
            minHeight: "32px"
        });
        titleInput.value = "";

        titleWrapper.appendChild(titleLabel);
        titleWrapper.appendChild(titleInput);

        const transcribeWrapper = document.createElement("label");
        Object.assign(transcribeWrapper.style, {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "6px",
            cursor: "pointer",
            whiteSpace: "nowrap",
            marginTop: "28px"
        });

        const transcribeCheckbox = document.createElement("input");
        transcribeCheckbox.type = "checkbox";
        Object.assign(transcribeCheckbox.style, {
            width: "0.9rem",
            height: "0.9rem",
            cursor: "pointer"
        });

        const transcribeText = document.createElement("span");
        transcribeText.textContent = "Transcribe lyrics now";
        transcribeText.style.fontSize = "0.8rem";

        transcribeWrapper.appendChild(transcribeCheckbox);
        transcribeWrapper.appendChild(transcribeText);

        titleRow.appendChild(titleWrapper);
        titleRow.appendChild(transcribeWrapper);

        // --- Lyrics Row ---
        const lyricsRow = document.createElement("div");
        Object.assign(lyricsRow.style, {
            display: "flex",
            flexDirection: "column",
            gap: "4px",
            marginTop: "4px"
        });
        lyricsRow.style.display = "none";

        const lyricsLabel = document.createElement("label");
        lyricsLabel.textContent = "Lyrics";
        lyricsLabel.style.fontWeight = "600";

        const lyricsTextarea = document.createElement("textarea");
        Object.assign(lyricsTextarea.style, {
            width: "100%",
            minHeight: "200px",
            padding: "8px",
            fontSize: "0.8em",
            border: "1px solid #ccc",
            borderRadius: "4px",
            resize: "vertical"
        });

        lyricsRow.appendChild(lyricsLabel);
        lyricsRow.appendChild(lyricsTextarea);

        transcribeCheckbox.addEventListener("change", () => {
            lyricsRow.style.display = transcribeCheckbox.checked ? "flex" : "none";
        });


        function updateTitleValue() {
            const selectedLang = languageSelect.value;
            if (!selectedLang) {
                titleInput.value = "";
                return;
            }

            const cfg = LANGUAGE_CONFIG.find(c => c.value === selectedLang);
            const suffix = cfg?.titleSuffix || "";

            const artist = (primaryArtistNames || "").replace(/\s*\([^()]*\)\s*$/, "");
            const title = songTitle || "";
            const featuredArtists = (featuredArtistsRaw || []).map(name => (name || "").replace(/\s*\([^()]*\)\s*$/, "").replace(/\u200B/g, "").trim());

            // Featured formatting
            let featuredString = "";
            if (featuredArtists.length === 1) {
                featuredString = ` ft. ${featuredArtists[0]}`;
            } else if (featuredArtists.length === 2) {
                featuredString = ` ft. ${featuredArtists[0]} & ${featuredArtists[1]}`;
            } else if (featuredArtists.length > 2) {
                const last = featuredArtists.pop();
                featuredString = ` ft. ${featuredArtists.join(", ")} & ${last}`;
            }

            const baseTitle = `${artist} - ${title}${featuredString}`;
            const endsWithRoundBracket = baseTitle.trim().endsWith(")");
            const finalSuffix = endsWithRoundBracket ? `[${suffix}]` : `(${suffix})`;

            titleInput.value = `${baseTitle} ${finalSuffix}`;
        }

        languageSelect.addEventListener("change", updateArtistValue);

        // --- Buttons ---
        const buttonRow = document.createElement("div");
        Object.assign(buttonRow.style, {
            display: "flex",
            flexDirection: "row",
            gap: "10px"
        });

        const createBtn = document.createElement("button");
        createBtn.textContent = "Create Translation Page";

        const cancelBtn = document.createElement("button");
        cancelBtn.textContent = "Cancel";

        if (editmetadatabutonSmallbutton) {
            [createBtn, cancelBtn].forEach(btn => {
                btn.className = editmetadatabutonSmallbutton.className;
                Array.from(editmetadatabutonSmallbutton.attributes).forEach(attr => {
                    btn.setAttribute(attr.name, attr.value);
                });
                btn.style.width = "fit-content";
            });
        }

        createBtn.addEventListener("click", async () => {
            const selectedLang = languageSelect.value;
            if (!selectedLang) return;

            const cleanArtist = artistValue.textContent.trim();
            const cleanTitle = titleInput.value.trim();

            if (!cleanArtist || !cleanTitle) return;

            const cfg = LANGUAGE_CONFIG.find(c => c.value === selectedLang);
            const language = cfg?.language || null;
            const tagId = cfg?.tagId ? Number(cfg.tagId) : null;

            const rawLyrics = lyricsTextarea?.value?.trim() || "";
            const hasLyrics = transcribeCheckbox.checked && rawLyrics.length > 0;

            const payload = {
                text_format: "html,markdown,preview",
                song: {
                    lyrics_state: "incomplete",
                    lyrics: hasLyrics ? rawLyrics : "",

                    primary_artists: [
                        {
                            name: cleanArtist
                        }
                    ],

                    title: cleanTitle,

                    primary_tag_id: primaryTag || null,
                    tags: tagId ? [{ id: tagId }] : [],

                    release_date_components: releaseDateComponents || null,

                    custom_song_art_image_url: customSongArtImageUrl || null,

                    youtube_url: youtubeUrl || null,
                    youtube_start: youtubeStart || null,

                    language: language,

                    song_relationships_by_id: songId
                        ? [
                            {
                                type: "translation_of",
                                song_ids: [songId]
                            }
                        ]
                        : [],
                }
            };

            console.log("Payload for creating translation:", payload);

            const result = await createSong(payload);
            overlay.remove();
            document.body.style.overflow = "";

            const newSongUrl = result?.response?.song?.url;
            if (newSongUrl) window.location.href = newSongUrl;
        });

        cancelBtn.addEventListener("click", () => {
            overlay.remove();
            document.body.style.overflow = "";
        });

        buttonRow.appendChild(createBtn);
        buttonRow.appendChild(cancelBtn);

        modal.appendChild(row);
        modal.appendChild(titleRow);
        modal.appendChild(lyricsRow);
        modal.appendChild(buttonRow);

        overlay.appendChild(modal);
        document.body.appendChild(overlay);
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                CLEANUP METADATA                                //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function cleanupMetadata(songId, songTitle, writerArtists, customPerformances, artists) {
        console.log("Run function cleanupMetadata()");
        checkZeroWidthSpaces(songId, songTitle);
        checkWriterArtists(songId, writerArtists, customPerformances, artists);
        renameAdditionalRoleLabels(songId, customPerformances, artists);
    }

    function checkZeroWidthSpaces(songId, songTitle) {
        let updatedTitle = songTitle;

        updatedTitle = updatedTitle.replace(/\u200B{2,}/g, '\u200B');
        updatedTitle = updatedTitle.replace(/^\u200B|(?<=[\p{L}\p{N}\p{P}])\u200B|(?=[\p{L}\p{N}\p{P}])\u200B/gu, '');

        if (/\u200B/.test(updatedTitle)) {
            console.info(`Remaining ZWSP: "${updatedTitle}"`);
        }
        if (songTitle !== updatedTitle) {
            addCleanupButton(songId, "ZWSP", "Remove ZWSP", { title: updatedTitle });
        }
    }

    function checkWriterArtists(songId, writerArtists, customPerformances, artists) {
        const getUniqueArtists = (performances, label) => {
            return performances
                .filter(p => p.label.toLowerCase() === label.toLowerCase())
                .flatMap(p => p.artists || [])
                .filter((artistId, index, self) =>
                    index === self.indexOf(artistId)
                );
        };

        const lyricists = getUniqueArtists(customPerformances, "Lyricist");
        const composers = getUniqueArtists(customPerformances, "Composer");
        const lyricistsAndComposers = [...new Set([...lyricists, ...composers])];
        const onlyWriters = writerArtists.filter(id => !lyricistsAndComposers.includes(id));
        const lyricistsAndComposersAndWriters = [...new Set([...lyricists, ...composers, ...onlyWriters])];

        if (lyricistsAndComposersAndWriters.length > writerArtists.length) {
            const newWriterArtists = lyricistsAndComposersAndWriters.map(id => ({
                id,
                name: artists[id]?.name
            }));

            addCleanupButton(songId, "Writers", "Add Writers", { writer_artists: newWriterArtists });
        }
    }


    function renameAdditionalRoleLabels(songId, customPerformances, artists) {
        let labelsToFix = [];

        const labelCorrections = {
            //"Primary Artists": "Group Members",
        };

        const updatedCustomPerformances = customPerformances.map(perf => {
            if (labelCorrections[perf.label]) {
                labelsToFix.push(perf.label);
                perf = { ...perf, label: labelCorrections[perf.label] };
            }

            const mappedArtists = perf.artists.map(id => ({
                id,
                name: artists[id]?.name
            }));

            return { ...perf, artists: mappedArtists };
        });

        if (!labelsToFix.length) return;

        const cleanupKey = labelsToFix.map(label => label.replace(/\s+/g, "")).join("And");
        const cleanupTitle = `Fix ${labelsToFix.join(", ")}`;

        addCleanupButton(songId, cleanupKey, cleanupTitle, { custom_performances: updatedCustomPerformances });
    }



    function addCleanupButton(songId, actionType, label, metadataUpdate) {
        const { stickytoolbarLeft, editmetadatabutonSmallbutton } = getDomElements();
        if (!stickytoolbarLeft || !editmetadatabutonSmallbutton) return;

        const actionButton = document.createElement('button');
        actionButton.className = editmetadatabutonSmallbutton.className.replace("EditMetadataButton", `${actionType}Button`);
        actionButton.type = 'button';
        actionButton.textContent = label;

        actionButton.addEventListener('click', () => {
            updateSongMetadata(songId, metadataUpdate);
            actionButton.style.display = 'none';
        });

        stickytoolbarLeft.appendChild(actionButton);
    }




    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                             LYRICS EDITOR BUTTONS                              //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function selectDropdown(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData, dropdownType) {
        console.log(`Run function selectDropdown() for ${dropdownType} dropdown`);

        const { stickytoolbarLeft } = getDomElements();
        if (!stickytoolbarLeft) return;

        if (document.getElementById(`${dropdownType}-dropdown-container`)) return;

        const dropdownContainer = document.createElement('div');
        dropdownContainer.id = `${dropdownType}-dropdown-container`;
        dropdownContainer.style.position = 'relative';

        const dropdownButton = document.createElement('button');
        dropdownButton.style.display = "block";
        dropdownButton.type = 'button';

        const dropdownSpan = document.createElement('span');
        Object.assign(dropdownSpan.style, {
            display: "flex",
            alignItems: "center",
            borderRadius: "1.25rem",
            padding: "0.25rem 0.75rem",
            border: "1px solid black",
            fontFamily: "HelveticaNeue, Arial, sans-serif",
            fontSize: "0.75rem",
            color: "black",
            lineHeight: "1rem",
            whiteSpace: "nowrap"
        });

        const dropdownText = document.createElement('span');
        const storedLanguage = localStorage.getItem("selectedLanguageText") || "??";
        dropdownText.textContent = dropdownType === "Language" ? `Language: ${storedLanguage}` : "Cleanup";

        const arrowSpan = document.createElement('span');
        arrowSpan.className = `${dropdownType}__DropdownIcon`;
        Object.assign(arrowSpan.style, { marginLeft: "0.375rem", width: "0.5rem" });

        const arrowSvgClosed = createArrowSvg('M4.488 7 0 0h8.977L4.488 7Z');
        const arrowSvgOpen = createArrowSvg('M4.488.5 0 7.5h8.977L4.488.5Z');

        const dropdownMenu = createDropdownMenu(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData, dropdownText, arrowSpan, dropdownType);

        arrowSpan.appendChild(arrowSvgClosed.cloneNode(true));
        dropdownSpan.append(dropdownText, arrowSpan);
        dropdownButton.appendChild(dropdownSpan);
        dropdownContainer.append(dropdownButton, dropdownMenu);
        stickytoolbarLeft.appendChild(dropdownContainer);

        dropdownButton.addEventListener('click', e => {
            e.stopPropagation();
            const isVisible = dropdownMenu.style.display === 'block';

            document.querySelectorAll('div.Dropdown__ContentContainer').forEach(menu => {
                menu.style.display = 'none';
                const icon = menu.parentElement.querySelector('span[class$="__DropdownIcon"]');
                if (icon) {
                    icon.innerHTML = '';
                    icon.appendChild(arrowSvgClosed.cloneNode(true));
                }
            });

            dropdownMenu.style.display = isVisible ? 'none' : 'block';
            arrowSpan.innerHTML = '';
            arrowSpan.appendChild(isVisible ? arrowSvgClosed.cloneNode(true) : arrowSvgOpen.cloneNode(true));
        });

        document.addEventListener('click', e => {
            if (!dropdownContainer.contains(e.target)) {
                dropdownMenu.style.display = 'none';
                arrowSpan.innerHTML = '';
                arrowSpan.appendChild(arrowSvgClosed.cloneNode(true));
            }
        });

        const toggleDropdownButton = () => {
            const { lyricsTextareaInputTextarea } = getDomElements();
            dropdownContainer.style.display = lyricsTextareaInputTextarea ? 'block' : 'none';
        };

        const observer = new MutationObserver(() => requestAnimationFrame(toggleDropdownButton));
        observer.observe(document.body, { childList: true, subtree: true });

        toggleDropdownButton();
    }

    function createDropdownMenu(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData, dropdownText, arrowSpan, dropdownType) {
        const LANGUAGE_OPTIONS = [
            //{ code: 'Auto', value: 'auto', name: 'Auto Language' },
            { code: 'SQ', value: 'sq', name: 'Albanian' },
            { code: 'EU', value: 'eu', name: 'Basque' },
            { code: 'BG', value: 'bg', name: 'Bulgarian' },
            { code: 'CA', value: 'ca', name: 'Catalan' },
            { code: 'CS', value: 'cs', name: 'Czech' },
            { code: 'ZH-T', value: 'zh-Hant', name: 'Chinese Traditional' },
            { code: 'ZH-S', value: 'zh', name: 'Chinese Simplified' },
            { code: 'DA', value: 'da', name: 'Danish' },
            { code: 'NL', value: 'nl', name: 'Dutch' },
            { code: 'EN', value: 'en', name: 'English' },
            { code: 'ET', value: 'et', name: 'Estonian' },
            { code: 'FR', value: 'fr', name: 'French' },
            { code: 'GL', value: 'gl', name: 'Galician' },
            { code: 'DE', value: 'de', name: 'German' },
            { code: 'HU', value: 'hu', name: 'Hungarian' },
            { code: 'IS', value: 'is', name: 'Icelandic' },
            { code: 'IT', value: 'it', name: 'Italian' },
            { code: 'JA', value: 'ja', name: 'Japanese' },
            { code: 'KO', value: 'ko', name: 'Korean' },
            { code: 'LA', value: 'la', name: 'Latin' },
            { code: 'LT', value: 'lt', name: 'Lithuanian' },
            { code: 'MK', value: 'mk', name: 'Macedonian' },
            { code: 'MN', value: 'mn', name: 'Mongolian' },
            { code: 'NO', value: 'no', name: 'Norwegian' },
            { code: 'PL', value: 'pl', name: 'Polish' },
            { code: 'PT', value: 'pt', name: 'Portuguese' },
            { code: 'RU', value: 'ru', name: 'Russian' },
            { code: 'SC', value: 'sc', name: 'Sardinian' },
            { code: 'SH-E', value: 'sr', name: 'Serbo-Croatian (ekavica)' },
            { code: 'SH-I', value: 'bs', name: 'Serbo-Croatian (ijekavica)' },
            { code: 'SK', value: 'sk', name: 'Slovak' },
            { code: 'ES', value: 'es', name: 'Spanish' },
            { code: 'SV', value: 'sv', name: 'Swedish' },
            { code: 'TR', value: 'tr', name: 'Turkish' },
            { code: 'UK', value: 'uk', name: 'Ukrainian' },
            { code: 'UZ', value: 'uz', name: 'Uzbek' },
            { code: 'VI', value: 'vi', name: 'Vietnamese' },
        ];

        const CLEANUP_OPTIONS = [
            ...(isGeniusSongLanguageButton ? [{ code: 'language', name: 'Language Cleanup' }] : []),
            { code: 'general', name: 'General Cleanup' },
            { code: 'punctuation', name: 'Fix Punctuation' },
            { code: 'capitalization', name: 'Fix Capitalization' }
        ];

        const options = dropdownType === "Language" ? LANGUAGE_OPTIONS : CLEANUP_OPTIONS;

        const dropdownMenu = document.createElement('div');
        dropdownMenu.className = "Dropdown__ContentContainer";
        Object.assign(dropdownMenu.style, {
            display: 'none',
            zIndex: '1000'
        });

        const ul = document.createElement('ul');
        ul.className = `${dropdownType}Menu__Dropdown`;
        Object.assign(ul.style, {
            zIndex: 4,
            backgroundColor: "#fff",
            marginTop: "1rem",
            fontSize: "0.75rem",
            fontWeight: 100,
            position: "absolute",
            right: "0px",
            border: "1px solid #000",
            minWidth: "100%",
            cursor: "pointer",
            whiteSpace: "nowrap",
            overflowY: "auto",
            scrollbarWidth: "none"
        });

        function adjustDropdownHeight() {
            const rect = dropdownMenu.getBoundingClientRect();
            let availableHeight = window.innerHeight - rect.top - 20;
            const step = window.innerWidth > 1526 ? 27 : 24;
            ul.style.maxHeight = `${Math.floor(availableHeight / step) * step}px`;
        }

        window.addEventListener('resize', adjustDropdownHeight);
        window.addEventListener('scroll', adjustDropdownHeight, { passive: true });
        new ResizeObserver(adjustDropdownHeight).observe(dropdownMenu);
        adjustDropdownHeight();

        const fragment = document.createDocumentFragment();
        options.forEach(option => {
            const li = document.createElement('li');
            li.className = `${dropdownType}MenuItem__Container`;

            const menuButton = document.createElement('button');
            menuButton.className = `${dropdownType}MenuItem__TextButton`;
            Object.assign(menuButton.style, {
                width: "100%",
                padding: "0.375rem 0.5rem",
                textAlign: "left",
                display: "flex",
                justifyContent: "space-between",
                fontFamily: "inherit",
                fontSize: "inherit",
                fontWeight: "inherit",
                color: "inherit",
                lineHeight: "1"
            });
            menuButton.type = 'button';
            menuButton.textContent = option.name;
            menuButton.dataset.code = option.code;
            if (option.value) menuButton.dataset.value = option.value;

            li.appendChild(menuButton);
            fragment.appendChild(li);
        });
        ul.appendChild(fragment);
        dropdownMenu.appendChild(ul);

        ul.addEventListener('click', e => {
            const menuButton = e.target.closest('button');
            if (!menuButton) return;

            const selectedCode = menuButton.dataset.code;
            const selectedValue = menuButton.dataset.value;

            if (dropdownType === "Language") {
                localStorage.setItem("selectedLanguage", selectedValue);
                localStorage.setItem("selectedLanguageText", selectedCode);
                dropdownText.textContent = `Language: ${selectedCode}`;
                document.querySelectorAll('#lyricsSectionsButtonsContainer').forEach(div => div.remove());
                document.querySelectorAll('#lyricsStyleButtonsContainer').forEach(div => div.remove());
                lyricsSectionsButtons(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData);
            } else if (dropdownType === "Cleanup") {
                lyricsCleanupLogic(selectedCode);
            }

            dropdownMenu.style.display = 'none';
            arrowSpan.innerHTML = '';
            arrowSpan.appendChild(createArrowSvg('M4.488 7 0 0h8.977L4.488 7Z'));
        });

        return dropdownMenu;
    }

    function createArrowSvg(pathData) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 9 7');
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', pathData);
        svg.appendChild(path);
        return svg;
    }

    function lyricsAnnotationsButtons() {
        const createGridContainer = (id, marginTop = "1.5rem") => {
            const div = document.createElement("div");
            div.id = id;
            div.style.marginTop = marginTop;
            div.style.display = "grid";
            div.style.gridTemplateColumns = "repeat(3, 1fr)";
            div.style.gap = "5px";
            return div;
        };

        const createButton = (label, hoverText, className) => {
            const btn = document.createElement("button");
            btn.style.minWidth = "0";
            btn.style.width = "100%";
            btn.style.display = "flex";
            btn.style.alignItems = "center";
            btn.style.justifyContent = "center";

            if (!label) {
                btn.style.visibility = "hidden";
                return btn;
            }

            btn.innerHTML = label;
            btn.title = hoverText;
            btn.type = "button";
            btn.className = className;
            return btn;
        };

        const applyTextFormatting = (openTag, closeTag) => {
            const { texteditorTextarea } = getDomElements();
            if (!texteditorTextarea) return;

            const start = texteditorTextarea.selectionStart;
            const end = texteditorTextarea.selectionEnd;

            if (start === end) {
                texteditorTextarea.setRangeText(openTag + closeTag, start, end, "end");
                const cursor = start + openTag.length;
                texteditorTextarea.selectionStart = cursor;
                texteditorTextarea.selectionEnd = cursor;
            } else {
                let selected = texteditorTextarea.value.substring(start, end);
                let trailing = "";

                while (/[ \n\r]$/.test(selected)) {
                    trailing = selected.slice(-1) + trailing;
                    selected = selected.slice(0, -1);
                }

                texteditorTextarea.setRangeText(openTag + selected + closeTag + trailing, start, end, "end");
            }

            texteditorTextarea.focus();
        };

        const renderButtons = (container, buttons, classNameMapper, storedLanguage) => {
            buttons.forEach(({ label, openTag, closeTag, hoverText, fullText }) => {
                const className = classNameMapper(hoverText || fullText);
                const btn = createButton(label, hoverText, className);

                btn.addEventListener("click", () => {
                    if (openTag !== undefined) {
                        applyTextFormatting(openTag, closeTag);
                    } else {
                        insertTextAtCursor(`[${fullText}]`);
                    }
                });

                container.appendChild(btn);
            });
        };

        let observer = new MutationObserver(() => {
            document.querySelectorAll('form[class*="AnnotationEditForm-desktop__Form"]').forEach(injectButtons);
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        function injectButtons(form) {
            if (form.querySelector("#lyricsStyleButtonsContainer")) return;

            const styleDiv = createGridContainer("lyricsStyleButtonsContainer", "0rem");

            const styleButtons = [
                { label: "Heading 1", openTag: "#", closeTag: "", hoverText: "Heading 1" },
                { label: "Heading 2", openTag: "##", closeTag: "", hoverText: "Heading 2" },
                { label: "Heading 3", openTag: "###", closeTag: "", hoverText: "Heading 3" },

                { label: "Italic", openTag: "*", closeTag: "*", hoverText: "Italic" },
                { label: "Bold", openTag: "**", closeTag: "**", hoverText: "Bold" },
                { label: "Italic + Bold", openTag: "***", closeTag: "***", hoverText: "Italic+Bold" },

                { label: "Plain Text", openTag: "`", closeTag: "`", hoverText: "Plain Text" },
                { label: "Strike-through", openTag: "<del>", closeTag: "</del>", hoverText: "Strike-through" },
                { label: "Underline", openTag: "<ins>", closeTag: "</ins>", hoverText: "Underline" },

                { label: "Link", openTag: "[", closeTag: "]()", hoverText: "Link" },
                { label: "Center", openTag: "<center>", closeTag: "</center>", hoverText: "Center" },
                { label: "Small", openTag: "<small>", closeTag: "</small>", hoverText: "Small" },

                { label: "Horizontal Rule", openTag: "---", closeTag: "", hoverText: "Horizontal Rule" },
                { label: "Em dash", openTag: "—", closeTag: "", hoverText: "Em dash" },
                //{ label: "NBSP", openTag: "&nbsp;", closeTag: "", hoverText: "Non-Breaking Space" },
            ];

            const { editmetadatabutonSmallbutton } = getDomElements();

            renderButtons(
                styleDiv,
                styleButtons,
                (name) => editmetadatabutonSmallbutton.className.replace("EditMetadataButton", `${name}Button`)
            );

            form.prepend(styleDiv);
        }
    }

    function lyricsSectionsButtons(primaryTag, songLanguage, songTitle, primaryArtists, featuredArtists, artists, trackingData) {
        console.log("Run function lyricsSectionsButtons()");

        const { lyricseditexplainerContainer, editmetadatabutonSmallbutton } = getDomElements();
        if (!lyricseditexplainerContainer || !editmetadatabutonSmallbutton) return;

        if (document.getElementById("lyricsSectionsButtonsContainer") && document.getElementById("lyricsStyleButtonsContainer")) return;

        const isNonMusic = primaryTag === 1452;

        const createGridContainer = (id, marginTop = "1.5rem") => {
            const div = document.createElement("div");
            div.id = id;
            div.style.marginTop = marginTop;
            div.style.display = "grid";
            div.style.gridTemplateColumns = "repeat(4, 1fr)";
            div.style.gap = "5px";
            return div;
        };

        const createButton = (label, hoverText, className) => {
            const btn = document.createElement("button");
            btn.style.minWidth = "0";
            btn.style.width = "100%";
            btn.style.display = "flex";
            btn.style.alignItems = "center";
            btn.style.justifyContent = "center";

            if (!label) {
                btn.style.visibility = "hidden";
                return btn;
            }

            btn.innerHTML = label;
            btn.title = hoverText;
            btn.type = "button";
            btn.className = className;

            return btn;
        };

        const convertToRoman = (num) => {
            const romanNumerals = [
                ["M", 1000], ["CM", 900], ["D", 500], ["CD", 400], ["C", 100],
                ["XC", 90], ["L", 50], ["XL", 40], ["X", 10], ["IX", 9],
                ["V", 5], ["IV", 4], ["I", 1]
            ];

            let result = "";
            for (const [symbol, value] of romanNumerals) {
                while (num >= value) {
                    result += symbol;
                    num -= value;
                }
            }
            return result;
        };

        const insertTextAtCursor = (text) => {
            const { lyricsTextareaInputTextarea } = getDomElements();
            if (lyricsTextareaInputTextarea) {
                const startPos = lyricsTextareaInputTextarea.selectionStart;
                const endPos = lyricsTextareaInputTextarea.selectionEnd;

                let beforeText = lyricsTextareaInputTextarea.value.substring(0, startPos).trimEnd();
                const afterText = lyricsTextareaInputTextarea.value.substring(endPos);

                while (!beforeText.endsWith('\n\n')) {
                    beforeText += '\n';
                }

                lyricsTextareaInputTextarea.value = beforeText + text + '\n' + afterText;

                const newCursorPos = beforeText.length + text.length + 1;
                lyricsTextareaInputTextarea.setSelectionRange(newCursorPos, newCursorPos);
                lyricsTextareaInputTextarea.focus();

                lyricsTextareaInputTextarea.value = lyricsTextareaInputTextarea.value.replace(/^\s+/, '');
                lyricsTextareaInputTextarea.dispatchEvent(new Event('input', { bubbles: true }));
            }
        };

        function insertSeoHeader(songTitleRaw, primaryArtistsRaw, featuredArtistsRaw, trackingData, headerType, storedLanguage) {
            const { lyricsTextareaInputTextarea } = getDomElements();
            if (!lyricsTextareaInputTextarea) return;

            const insertText = (text, position = "begin") => {
                lyricsTextareaInputTextarea.focus();
                const currentText = lyricsTextareaInputTextarea.value.trim();

                if (position === "begin" && !currentText.startsWith(text)) {
                    lyricsTextareaInputTextarea.value = text + "\n\n" + currentText;
                    lyricsTextareaInputTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                    lyricsTextareaInputTextarea.setSelectionRange(text.length + 2, text.length + 2);
                }

                if (position === "end" && !currentText.endsWith(text)) {
                    lyricsTextareaInputTextarea.value = currentText + "\n\n" + text;
                    lyricsTextareaInputTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                }
            };

            const containsCyrillic = (text) => /[А-Яа-яЁё]/.test(text);
            const containsChinese = (text) => /[\u4e00-\u9fff]/.test(text);
            const containsJapanese = (text) => /[\u3040-\u30ff\u31f0-\u31ff]/.test(text);
            const containsKorean = (text) => /[\uAC00-\uD7AF\u1100-\u11FF\u3130-\u318F]/.test(text);


            const cleanName = (name) => {
                name = name.replace(/”/g, '"').replace(/’/g, "'");
                if (containsCyrillic(name) || containsChinese(name) || containsJapanese(name) || containsKorean(name)) {
                    name = name.replace(/\s*\([^)]+\)/g, "").replace(/\s*\[[^\]]+\]/g, "");
                }
                return name;
            };

            // Clean song title (Cyrillic/Chinese/Japanese)
            let songTitle = cleanName(songTitleRaw);

            // Clean song title (Translation)
            const isTranslation = trackingData?.some((item) => item.key === "Translation" && item.value === true);

            if (isTranslation) {
                const dashIndex = songTitle.indexOf("-");
                const lastBracketIndex = Math.max(
                    songTitle.lastIndexOf("("),
                    songTitle.lastIndexOf("["),
                    songTitle.lastIndexOf("{")
                );
                if (dashIndex !== -1 && lastBracketIndex > dashIndex) {
                    songTitle = songTitle.substring(dashIndex + 1, lastBracketIndex).trim();
                }
            }

            // Round brackets
            const hasOpening = songTitle.includes("(");
            const hasClosing = songTitle.includes(")");

            if (hasOpening && !hasClosing) {
                songTitle = songTitle.replace(/\(/g, "&#40;");
            } else if (!hasOpening && hasClosing) {
                songTitle = songTitle.replace(/\)/g, "&#41;");
            }

            // Angle brackets
            const hasLt = songTitle.includes("<") || songTitle.includes("˂");
            const hasGt = songTitle.includes(">") || songTitle.includes("˃");

            if (hasLt && !hasGt) {
                songTitle = songTitle.replace(/[<˂]/g, "&lt;");
            } else if (!hasLt && hasGt) {
                songTitle = songTitle.replace(/[>˃]/g, "&gt;");
            }

            const primaryArtists = (primaryArtistsRaw || [])
                .map(id => artists[id]?.name || "")
                .map(name => cleanName(name));

            const featuredArtists = (featuredArtistsRaw || [])
                .map(id => artists[id]?.name || "")
                .map(name => cleanName(name));

            const primaryArtistsText = primaryArtists.length > 1
                ? primaryArtists.slice(0, -1).join(", ") + " & " + primaryArtists.at(-1)
                : primaryArtists.join("");

            const featuredArtistsText = featuredArtists.length > 1
                ? featuredArtists.slice(0, -1).join(", ") + " & " + featuredArtists.at(-1)
                : featuredArtists.join("");

            const featuringText = featuredArtistsText ? ` ft. ${featuredArtistsText}` : "";
            const formattedFeaturingText = featuredArtistsText ? `ft. ${featuredArtistsText} ` : "";

            const textFormats = {
                Header: {
                    'bg': `[Текст на песента "${songTitle}"${featuringText}]`,
                    'bs': `[Tekst pjesme „${songTitle}”${featuringText}]`,
                    'ca': `[Lletra de "${songTitle}"${featuringText}]`,
                    'cs': `[Text skladby „${songTitle}“${featuringText}]`,
                    'da': `[Tekst til "${songTitle}"${featuringText}]`,
                    'de': `[Songtext zu „${songTitle}“${featuringText}]`,
                    'es': `[Letra de "${songTitle}"${featuringText}]`,
                    'et': `[${songTitle} laulusõnad${featuringText}]`,
                    'eu': `["${songTitle}" abestiaren letra${featuringText}]`,
                    'fr': `[Paroles de "${songTitle}"${featuringText}]`,
                    'gl': `[Letra de "${songTitle}"${featuringText}]`,
                    'hu': `[„${songTitle}” dalszöveg${featuringText}]`,
                    'is': `[Söngtextar fyrir "${songTitle}"${featuringText}]`,
                    'it': `[Testo di "${songTitle}"${featuringText}]`,
                    'ja': `[${primaryArtistsText}「${songTitle}」${formattedFeaturingText}歌詞]`,
                    'ko': `[${primaryArtistsText} "${songTitle}" ${formattedFeaturingText}가사]`,
                    'la': `[Lyricis "${songTitle}"${featuringText}]`,
                    'lt': `[Dainos žodžiai „${songTitle}”${featuringText}]`,
                    'mk': `[Текст за песната „${songTitle}”${featuringText}]`,
                    'mn': `[«${songTitle}» Үгнүүд${featuringText}]`,
                    'nl': `[Songtekst van "${songTitle}"${featuringText}]`,
                    'no': `[Tekst til «${songTitle}»${featuringText}]`,
                    'pl': `[Tekst piosenki "${songTitle}"${featuringText}]`,
                    'pt': `[Letra de "${songTitle}"${featuringText}]`,
                    'ru': `[Текст песни «${songTitle}»${featuringText}]`,
                    'sc': `[Testu de "${songTitle}"${featuringText}]`,
                    'sk': `[Text skladby „${songTitle}“${featuringText}]`,
                    'sq': `[Teksti i "${songTitle}"${featuringText}]`,
                    'sr': `[Tekst pesme „${songTitle}”${featuringText}]`,
                    'tr': `["${songTitle}"${featuringText} için şarkı sözleri]`,
                    'uk': `[Текст пісні «${songTitle}»${featuringText}]`,
                    'uz': `[«${songTitle}» qoʻshigʻi matni${featuringText}]`,
                    'vi': `[Lời bài hát "${songTitle}"${featuringText}]`,
                    'zh': `[${primaryArtistsText}《${songTitle}》${formattedFeaturingText}歌词]`,
                    'zh-hant': `[${primaryArtistsText}《${songTitle}》${formattedFeaturingText}歌詞]`,
                },
                Translation: {
                    'de': `[Deutscher Songtext zu „${songTitle}“${featuringText}]`,
                    'hu': `[„${songTitle}” magyarul]`,
                    'nl': `[Songtekst van "${songTitle}"${featuringText} (Vertaling)]`,
                    'no': `[Tekst til ${primaryArtistsText} – «${songTitle}»${featuringText} (Oversettelse)]`,
                    'pt': `[Letra de "${songTitle}"${featuringText}]`,
                    'sq': `[Teksti i "${songTitle}"${featuringText} në shqip]`,
                    'tr': `["${songTitle}"${featuringText} için Türkçe şarkı sözleri]`,
                    'vi': `[Lời dịch tiếng Việt cho "${songTitle}"${featuringText}]`,
                },
                Snippet: {
                    'cs': `<b>[Lyrics from [Snippet]()]</b>`,
                    'da': `<b>[Tekst fra [snippet]()]</b>`,
                    'de': `<b>[Lyrics von [Snippet]()]</b>`,
                    'en': `<b>[Lyrics from [Snippet]()]</b>`,
                    'nl': `<b>[Songtekst van [Fragment]()]</b>`,
                    'pl': `<b>[Tekst piosenki pochodzi ze [Snippetu]()]</b>`,
                    'pt': `<b>[Letra da [prévia]()]</b>`,
                    'sk': `<b>[Lyrics from [Snippet]()]</b>`,
                    'tr': `<b>[[Kesit]() şarkı sözleri, resmî sözler yayımlanınca güncellenecektir]</b>`,
                }
            };

            const snippetInsertEndLangs = new Set(['de',]);

            const textToInsert = textFormats[headerType]?.[storedLanguage];

            if (textToInsert) {
                let position = "begin";

                if (headerType === "Snippet") {
                    position = snippetInsertEndLangs.has(storedLanguage) ? "end" : "begin";
                }

                insertText(textToInsert, position);
            }


        }

        function insertPartHeader(fullText) {
            insertTextAtCursor(`<b>[${fullText}]</b>`);

            const { lyricsTextareaInputTextarea } = getDomElements();
            if (lyricsTextareaInputTextarea) {
                const oldCursorPos = lyricsTextareaInputTextarea.selectionStart;

                let i = 1;
                const oldValue = lyricsTextareaInputTextarea.value;

                const newValue = oldValue.replace(
                    new RegExp(`<b>\\[${fullText}(?: [IVXLCDM]+)?`, "g"),
                    () => `<b>[${fullText} ${convertToRoman(i++)}`
                );

                lyricsTextareaInputTextarea.value = newValue;

                const diff = newValue.length - oldValue.length;
                const newCursorPos = oldCursorPos + diff;
                lyricsTextareaInputTextarea.focus();
                lyricsTextareaInputTextarea.setSelectionRange(newCursorPos, newCursorPos);
            }
        }

        function insertVerseHeader(fullText) {
            insertTextAtCursor(`[${fullText}]`);

            const { lyricsTextareaInputTextarea } = getDomElements();
            if (lyricsTextareaInputTextarea) {
                const oldCursorPos = lyricsTextareaInputTextarea.selectionStart;

                const oldValue = lyricsTextareaInputTextarea.value;

                const otherTags = ["Part", "Teil", "Część", "Часть", "Pjesa", "Kısım", "Qism"];
                const sectionRegex = new RegExp(
                    `(<b>\\[(?:${otherTags.join('|')})(?: [IVXLCDM]+)?[^<]*<\\/b>)`,
                    "g"
                );
                const ownRegex = new RegExp(`\\[${fullText}(?: \\d+)?(?:: ([^\\]]+))?\\]`, "g");

                const renumberTags = (text) => {
                    const matches = text.match(ownRegex);

                    if (matches && matches.length > 1) {
                        let i = 1;
                        return text.replace(ownRegex, (_, sub) => {
                            return sub
                                ? `[${fullText} ${i++}: ${sub}]`
                                : `[${fullText} ${i++}]`;
                        });
                    }

                    if (matches && matches.length === 1) {
                        return text.replace(ownRegex, (_, sub) => {
                            return sub
                                ? `[${fullText}: ${sub}]`
                                : `[${fullText}]`;
                        });
                    }

                    return text;
                };

                let lastIndex = 0;
                let updatedText = "";
                let match;

                while ((match = sectionRegex.exec(oldValue)) !== null) {
                    const sectionText = oldValue.substring(lastIndex, match.index);
                    updatedText += renumberTags(sectionText);
                    updatedText += match[1];
                    lastIndex = sectionRegex.lastIndex;
                }

                updatedText += renumberTags(oldValue.substring(lastIndex));
                lyricsTextareaInputTextarea.value = updatedText;

                const diff = updatedText.length - oldValue.length;
                const newCursorPos = oldCursorPos + diff;

                lyricsTextareaInputTextarea.focus();
                lyricsTextareaInputTextarea.setSelectionRange(newCursorPos, newCursorPos);
            }
        }

        const insertSectionHeader = (fullText, hoverText, storedLanguage) => {
            const actions = {
                Header: () => insertSeoHeader(songTitle, primaryArtists, featuredArtists, trackingData, hoverText, storedLanguage),
                Translation: () => insertSeoHeader(songTitle, primaryArtists, featuredArtists, trackingData, hoverText, storedLanguage),
                Snippet: () => insertSeoHeader(songTitle, primaryArtists, featuredArtists, trackingData, hoverText, storedLanguage),
                Part: () => insertPartHeader(fullText),
                Verse: () => insertVerseHeader(fullText),
                default: () => insertTextAtCursor(`[${fullText}]`)
            };
            const action = actions[hoverText] || actions.default;
            action();

        };

        const applyTextFormatting = (openTag, closeTag) => {
            const { lyricsTextareaInputTextarea } = getDomElements();
            if (!lyricsTextareaInputTextarea) return;

            const start = lyricsTextareaInputTextarea.selectionStart;
            const end = lyricsTextareaInputTextarea.selectionEnd;

            if (start === end) {
                lyricsTextareaInputTextarea.setRangeText(openTag + closeTag, start, end, "end");
                const cursor = start + openTag.length;
                lyricsTextareaInputTextarea.selectionStart = cursor;
                lyricsTextareaInputTextarea.selectionEnd = cursor;
            } else {
                let selected = lyricsTextareaInputTextarea.value.substring(start, end);
                let trailing = "";

                while (/[ \n\r]$/.test(selected)) {
                    trailing = selected.slice(-1) + trailing;
                    selected = selected.slice(0, -1);
                }

                lyricsTextareaInputTextarea.setRangeText(openTag + selected + closeTag + trailing, start, end, "end");
            }

            lyricsTextareaInputTextarea.focus();
        };

        const renderButtons = (container, buttons, classNameMapper, storedLanguage) => {
            buttons.forEach(item => {
                const { label, openTag, closeTag, hoverText, fullText, isDropdown, items } = item;
                const className = classNameMapper(hoverText || fullText);

                const btn = isDropdown
                    ? createDropdownButton(label, hoverText, className, items, storedLanguage)
                    : createButton(label, hoverText, className);

                if (!isDropdown) {
                    btn.addEventListener("click", () => {
                        if (openTag !== undefined) {
                            applyTextFormatting(openTag, closeTag);
                        } else {
                            insertSectionHeader(fullText, hoverText, storedLanguage);
                        }
                    });
                }

                container.appendChild(btn);
            });
        };

        function createDropdownButton(label, hoverText, className, items, storedLanguage) {
            const wrapper = document.createElement("div");
            wrapper.style.position = "relative";

            const btn = document.createElement("button");
            btn.title = hoverText;
            btn.type = "button";
            btn.className = className;

            btn.style.display = "grid";
            btn.style.gridTemplateColumns = "1fr auto";
            btn.style.alignItems = "center";
            btn.style.width = "100%";

            const svgDown = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 7" width="8" height="6.21">
                    <path d="M4.488 7 0 0h8.977L4.488 7Z"></path>
                </svg>`;
            const svgUp = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 8" width="8" height="6.21">
                    <path d="M4.488.5 0 7.5h8.977L4.488.5Z"></path>
                </svg>`;

            const textSpan = document.createElement("span");
            textSpan.textContent = label;
            textSpan.style.justifySelf = "center";

            const iconSpan = document.createElement("span");
            iconSpan.innerHTML = svgDown;
            iconSpan.style.justifySelf = "end";

            btn.appendChild(textSpan);
            btn.appendChild(iconSpan);

            const menu = document.createElement("div");
            menu.style.position = "absolute";
            menu.style.top = "107.5%";
            menu.style.background = "white";
            menu.style.border = "1px solid #000000";
            menu.style.padding = "0.25rem";
            menu.style.display = "none";
            menu.style.zIndex = "9999";
            menu.style.borderRadius = "0.5rem";
            menu.style.width = "100%";
            menu.style.gridTemplateColumns = "repeat(auto-fit, minmax(1rem, 1fr))";
            menu.style.gap = "0.125rem";

            items.forEach(entry => {
                const isObject = typeof entry === "object";

                const label = isObject ? entry.label : entry;
                const openTag = isObject ? entry.openTag : entry;
                const closeTag = isObject ? entry.closeTag ?? "" : "";

                const item = document.createElement("button");
                item.textContent = label;

                item.style.paddingTop = "0.25rem";
                item.style.paddingBottom = "0.25rem";
                item.style.cursor = "pointer";
                item.style.borderRadius = "0.125rem";
                item.style.fontSize = "0.75rem";

                const isSymbolsDropdown = hoverText === "Symbols";
                const WIDE_SYMBOLS = {
                    default: ["ZWSP", "NBSP", "„...“"],
                    de: ["ZWSP", "THSP", "NBSP", "„...“", "–", "—"],
                    ja: ["ZWSP", "「...」"]
                };

                const wideList = WIDE_SYMBOLS[storedLanguage] || WIDE_SYMBOLS.default;


                if (isSymbolsDropdown && wideList.includes(label)) {
                    item.style.gridColumn = "span 2";
                }

                item.addEventListener("click", () => {
                    applyTextFormatting(openTag, closeTag);
                });

                menu.appendChild(item);
            });

            btn.addEventListener("click", () => {
                const isClosed = menu.style.display === "none";
                menu.style.display = isClosed ? "grid" : "none";
                iconSpan.innerHTML = isClosed ? svgUp : svgDown;
            });

            wrapper.appendChild(btn);
            wrapper.appendChild(menu);
            return wrapper;
        }


        if (!isNonMusic) {
            // SECTION BUTTONS
            const headerDiv = createGridContainer("lyricsSectionsButtonsContainer", "2rem");

            let storedLanguage = localStorage.getItem("selectedLanguage");
            if (storedLanguage === "auto") storedLanguage = songLanguage;
            if (!storedLanguage) return;

            const HEADERS = {
                "bg": { // Bulgarian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Въведение", fullText: "Въведение", hoverText: "Intro" },
                        { displayText: "Финал", fullText: "Финал", hoverText: "Outro" },
                        { displayText: "Скит", fullText: "Скит", hoverText: "Skit" },
                        { displayText: "Част", fullText: "Част", hoverText: "Part" },
                        { displayText: "Куплет", fullText: "Куплет", hoverText: "Verse" },
                        { displayText: "Предприпев", fullText: "Предприпев", hoverText: "Pre-Chorus" },
                        { displayText: "Припев", fullText: "Припев", hoverText: "Chorus" },
                        { displayText: "Следприпев", fullText: "Следприпев", hoverText: "Post-Chorus" },
                        { displayText: "Рефрен", fullText: "Рефрен", hoverText: "Refrain" },
                        { displayText: "Мост", fullText: "Мост", hoverText: "Bridge" },
                        { displayText: "Интерлюдия", fullText: "Интерлюдия", hoverText: "Interlude" },
                        { displayText: "Инстр. Пауза", fullText: "Инструментална Пауза", hoverText: "Instrumental Break" },
                    ]
                },
                "bs": { // Serbian (Serbo-Croatian (ijekavica))
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Uvod", fullText: "Uvod", hoverText: "Intro" },
                        { displayText: "Završetak", fullText: "Završetak", hoverText: "Outro" },
                        { displayText: "Skeč", fullText: "Skeč", hoverText: "Skit" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Strofa", fullText: "Strofa", hoverText: "Verse" },
                        { displayText: "Predrefren", fullText: "Predrefren", hoverText: "Pre-Chorus" },
                        { displayText: "Refren", fullText: "Refren", hoverText: "Chorus" },
                        { displayText: "Postrefren", fullText: "Postrefren", hoverText: "Post-Chorus" },
                        { displayText: "Pripev", fullText: "Pripev", hoverText: "Refrain" },
                        { displayText: "Most", fullText: "Most", hoverText: "Bridge" },
                        { displayText: "Interludijum", fullText: "Interludijum", hoverText: "Interlude" },
                        { displayText: "Pauza", fullText: "Pauza", hoverText: "Break" },
                        { displayText: "Uzdizanje", fullText: "Uzdizanje", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "ca": { // Catalan
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "cs": { // Czech
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "da": { // Danish
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skitse", fullText: "Skitse", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Vers", fullText: "Vers", hoverText: "Verse" },
                        { displayText: "Bro", fullText: "Bro", hoverText: "Pre-Chorus" },
                        { displayText: "Omkvæd", fullText: "Omkvæd", hoverText: "Chorus" },
                        { displayText: "Post-omkvæd", fullText: "Post-omkvæd", hoverText: "Post-Chorus" },
                        { displayText: "Refræn", fullText: "Refræn", hoverText: "Refrain" },
                        { displayText: "Kontraststykke", fullText: "Kontraststykke", hoverText: "Bridge" },
                        { displayText: "Mellemspil", fullText: "Mellemspil", hoverText: "Interlude" },
                        { displayText: "Mellemstykke", fullText: "Mellemstykke", hoverText: "Interlude" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "de": { // German
                    1434: [
                        { displayText: "Songtext", fullText: "Songtext", hoverText: "Header" },
                        { displayText: "Übersetzung", fullText: "Übersetzung", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Teil", fullText: "Teil", hoverText: "Part" },
                        { displayText: "Part", fullText: "Part", hoverText: "Verse" },
                        { displayText: "Pre-Hook", fullText: "Pre-Hook", hoverText: "Pre-Chorus" },
                        { displayText: "Hook", fullText: "Hook", hoverText: "Chorus" },
                        { displayText: "Post-Hook", fullText: "Post-Hook", hoverText: "Post-Chorus" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ],
                    Default: [
                        { displayText: "Songtext", fullText: "Songtext", hoverText: "Header" },
                        { displayText: "Übersetzung", fullText: "Übersetzung", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Teil", fullText: "Teil", hoverText: "Part" },
                        { displayText: "Strophe", fullText: "Strophe", hoverText: "Verse" },
                        { displayText: "Pre-Refrain", fullText: "Pre-Refrain", hoverText: "Pre-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Chorus" },
                        { displayText: "Post-Refrain", fullText: "Post-Refrain", hoverText: "Post-Chorus" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "en": { // English
                    Default: [
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "es": { // Spanish
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "et": { // Estonian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "eu": { // Basque
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "fr": { // French
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Dialogue", fullText: "Dialogue", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Couplet", fullText: "Couplet", hoverText: "Verse" },
                        { displayText: "Pré-refrain", fullText: "Pré-refrain", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Chorus" },
                        { displayText: "Post-refrain", fullText: "Post-refrain", hoverText: "Post-Chorus" },
                        { displayText: "Riff", fullText: "Riff", hoverText: "Refrain" },
                        { displayText: "Pont", fullText: "Pont", hoverText: "Bridge" },
                        { displayText: "Intermède", fullText: "Intermède", hoverText: "Interlude" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Pause instr.", fullText: "Pause instrumentale", hoverText: "Instrumental Break" },
                        { displayText: "Vocalises", fullText: "Vocalises", hoverText: "Non-Lyrical Vocals" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "hu": { // Hungarian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "is": { // Icelandic
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "it": { // Italian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "ja": { // Japanese
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "ko": { // Korean
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "la": { // Latin
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "lt": { // Lithuanian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "mn": { // Mongolian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "mk": { // Macedonian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Увод", fullText: "Увод", hoverText: "Intro" },
                        { displayText: "Завршеток", fullText: "Завршеток", hoverText: "Outro" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Строфа", fullText: "Строфа", hoverText: "Verse" },
                        { displayText: "Предрефрен", fullText: "Предрефрен", hoverText: "Pre-Chorus" },
                        { displayText: "Рефрен", fullText: "Рефрен", hoverText: "Chorus" },
                        { displayText: "Пострефрен", fullText: "Пострефрен", hoverText: "Post-Chorus" },
                        { displayText: "Рефрен", fullText: "Рефрен", hoverText: "Refrain" },
                        { displayText: "Мост", fullText: "Мост", hoverText: "Bridge" },
                        { displayText: "Пауза", fullText: "Пауза", hoverText: "Breakdown" },
                        { displayText: "Инстр. пауза", fullText: "Инструментална пауза", hoverText: "Instrumental" },
                    ]
                },
                "nl": { // Dutch
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "no": { // Norwegian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Vers", fullText: "Vers", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refreng", fullText: "Refreng", hoverText: "Refrain" },
                        { displayText: "Bro", fullText: "Bro", hoverText: "Bridge" },
                        { displayText: "Mellomspill", fullText: "Mellomspill", hoverText: "Interlude" }
                    ]
                },
                "pl": { // Polish
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Część", fullText: "Część", hoverText: "Part" },
                        { displayText: "Zwrotka", fullText: "Zwrotka", hoverText: "Verse" },
                        { displayText: "Przedrefren", fullText: "Przedrefren", hoverText: "Pre-Chorus" },
                        { displayText: "Refren", fullText: "Refren", hoverText: "Chorus" },
                        { displayText: "Zarefren", fullText: "Zarefren", hoverText: "Post-Chorus" },
                        { displayText: "Przyśpiewka", fullText: "Przyśpiewka", hoverText: "Bridge" },
                        { displayText: "Przejście", fullText: "Przejście", hoverText: "Bridge" },
                        { displayText: "Interludium", fullText: "Interludium", hoverText: "Interlude" },
                        { displayText: "Przerwa instr.", fullText: "Przerwa instrumentalna", hoverText: "Instrumental Break" },
                        { displayText: "Wokaliza", fullText: "Wokaliza", hoverText: "Non-Lyrical Vocals" },
                    ]
                },
                "pt": { // Portuguese
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Saída", fullText: "Saída", hoverText: "Outro" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Verso", fullText: "Verso", hoverText: "Verse" },
                        { displayText: "Pré-Refrão", fullText: "Pré-Refrão", hoverText: "Pre-Chorus" },
                        { displayText: "Refrão", fullText: "Refrão", hoverText: "Chorus" },
                        { displayText: "Pós-Refrão", fullText: "Pós-Refrão", hoverText: "Post-Chorus" },
                        { displayText: "Estribilho", fullText: "Estribilho", hoverText: "Refrain" },
                        { displayText: "Ponte", fullText: "Ponte", hoverText: "Bridge" },
                        { displayText: "Interlúdio", fullText: "Interlúdio", hoverText: "Interlude" }
                    ]
                },
                "ru": { // Russian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Интро", fullText: "Интро", hoverText: "Intro" },
                        { displayText: "Аутро", fullText: "Аутро", hoverText: "Outro" },
                        { displayText: "Скит", fullText: "Скит", hoverText: "Skit" },
                        { displayText: "Часть", fullText: "Часть", hoverText: "Part" },
                        { displayText: "Куплет", fullText: "Куплет", hoverText: "Verse" },
                        { displayText: "Предприпев", fullText: "Предприпев", hoverText: "Pre-Chorus" },
                        { displayText: "Припев", fullText: "Припев", hoverText: "Chorus" },
                        { displayText: "Постприпев", fullText: "Постприпев", hoverText: "Post-Chorus" },
                        { displayText: "Рефрен", fullText: "Рефрен", hoverText: "Refrain" },
                        { displayText: "Бридж", fullText: "Бридж", hoverText: "Bridge" },
                        { displayText: "Брейкдаун", fullText: "Брейкдаун", hoverText: "Breakdown" },
                        { displayText: "Интерлюдия", fullText: "Интерлюдия", hoverText: "Interlude" },
                        { displayText: "Преддроп", fullText: "Преддроп", hoverText: "Build" },
                        { displayText: "Дроп", fullText: "Дроп", hoverText: "Drop" },
                    ]
                },
                "sc": { // Sardinian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "sk": { // Slovak
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "sq": { // Albanian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Hyrja", fullText: "Hyrja", hoverText: "Intro" },
                        { displayText: "Mbyllja", fullText: "Mbyllja", hoverText: "Outro" },
                        { displayText: "Dialogu", fullText: "Dialogu", hoverText: "Skit" },
                        { displayText: "Pjesa", fullText: "Pjesa", hoverText: "Part" },
                        { displayText: "Strofa", fullText: "Strofa", hoverText: "Verse" },
                        { displayText: "Pararefreni", fullText: "Pararefreni", hoverText: "Pre-Chorus" },
                        { displayText: "Refreni", fullText: "Refreni", hoverText: "Chorus" },
                        { displayText: "Pasrefreni", fullText: "Pasrefreni", hoverText: "Post-Chorus" },
                        { displayText: "Nënrefreni", fullText: "Nënrefreni", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Ndërhyrja ", fullText: "Ndërhyrja", hoverText: "Interlude" },
                        { displayText: "Ndë. Instr.", fullText: "Ndërhyrja Instrumentale", hoverText: "Instrumental Break" },
                        { displayText: "Vok. pa Tekst", fullText: "Vokale pa Tekst", hoverText: "Non-Lyrical Vocals" },
                        { displayText: "Yodeling", fullText: "Yodeling", hoverText: "Yodeling" },
                        { displayText: "Scatting", fullText: "Scatting", hoverText: "Scatting" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" },
                    ]
                },
                "sr": { // Serbian (Serbo-Croatian (ekavica))
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Uvod", fullText: "Uvod", hoverText: "Intro" },
                        { displayText: "Završetak", fullText: "Završetak", hoverText: "Outro" },
                        { displayText: "Skeč", fullText: "Skeč", hoverText: "Skit" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Strofa", fullText: "Strofa", hoverText: "Verse" },
                        { displayText: "Predrefren", fullText: "Predrefren", hoverText: "Pre-Chorus" },
                        { displayText: "Refren", fullText: "Refren", hoverText: "Chorus" },
                        { displayText: "Postrefren", fullText: "Postrefren", hoverText: "Post-Chorus" },
                        { displayText: "Pripev", fullText: "Pripev", hoverText: "Refrain" },
                        { displayText: "Most", fullText: "Most", hoverText: "Bridge" },
                        { displayText: "Interludijum", fullText: "Interludijum", hoverText: "Interlude" },
                        { displayText: "Pauza", fullText: "Pauza", hoverText: "Break" },
                        { displayText: "Uzdizanje", fullText: "Uzdizanje", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "sv": { // Swedish
                    Default: [
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Vers", fullText: "Vers", hoverText: "Verse" },
                        { displayText: "Brygga", fullText: "Brygga", hoverText: "Pre-Chorus" },
                        { displayText: "Refräng", fullText: "Refräng", hoverText: "Chorus" },
                        { displayText: "Post-Refräng", fullText: "Post-Refräng", hoverText: "Post-Chorus" },
                        { displayText: "Stick", fullText: "Stick", hoverText: "Bridge" },
                        { displayText: "Mellanspel", fullText: "Mellanspel", hoverText: "Interlude" }
                    ]
                },
                "tr": { // Turkish
                    1434: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Giriş", fullText: "Giriş", hoverText: "Intro" },
                        { displayText: "Çıkış", fullText: "Çıkış", hoverText: "Outro" },
                        { displayText: "Kesit", fullText: "Kesit", hoverText: "Skit" },
                        { displayText: "Kısım", fullText: "Kısım", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Ön Nakarat", fullText: "Ön Nakarat", hoverText: "Pre-Chorus" },
                        { displayText: "Nakarat", fullText: "Nakarat", hoverText: "Chorus" },
                        { displayText: "Arka Nakarat", fullText: "Arka Nakarat", hoverText: "Post-Chorus" },
                        { displayText: "Köprü", fullText: "Köprü", hoverText: "Bridge" },
                        { displayText: "Ara", fullText: "Ara", hoverText: "Interlude" },
                        { displayText: "Enst. Ara", fullText: "Enstrümantal Ara", hoverText: "Instrumental Break" },
                        { displayText: "Enst. Çıkış", fullText: "Enstrümantal Çıkış", hoverText: "Instrumental Outro" }
                    ],
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: "Snippet", fullText: "Snippet", hoverText: "Snippet" },
                        { displayText: "Giriş", fullText: "Giriş", hoverText: "Intro" },
                        { displayText: "Çıkış", fullText: "Çıkış", hoverText: "Outro" },
                        { displayText: "Kesit", fullText: "Kesit", hoverText: "Skit" },
                        { displayText: "Kısım", fullText: "Kısım", hoverText: "Part" },
                        { displayText: "Bölüm", fullText: "Bölüm", hoverText: "Verse" },
                        { displayText: "Ön Nakarat", fullText: "Ön Nakarat", hoverText: "Pre-Chorus" },
                        { displayText: "Nakarat", fullText: "Nakarat", hoverText: "Chorus" },
                        { displayText: "Arka Nakarat", fullText: "Arka Nakarat", hoverText: "Post-Chorus" },
                        { displayText: "Köprü", fullText: "Köprü", hoverText: "Bridge" },
                        { displayText: "Ara", fullText: "Ara", hoverText: "Interlude" },
                        { displayText: "Enst. Ara", fullText: "Enstrümantal Ara", hoverText: "Instrumental Break" },
                        { displayText: "Enst. Çıkış", fullText: "Enstrümantal Çıkış", hoverText: "Instrumental Outro" }
                    ]
                },
                "uk": { // Ukrainian
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "uz": { // Uzbek
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Kirish", fullText: "Kirish", hoverText: "Intro" },
                        { displayText: "Chiqish", fullText: "Chiqish", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Qism", fullText: "Qism", hoverText: "Part" },
                        { displayText: "Koʻplet", fullText: "Koʻplet", hoverText: "Verse" },
                        { displayText: "Oldinaqarot", fullText: "Oldinaqarot", hoverText: "Pre-Chorus" },
                        { displayText: "Naqarot", fullText: "Naqarot", hoverText: "Chorus" },
                        { displayText: "Keyingi-naq.", fullText: "Keyingi-naqarot", hoverText: "Post-Chorus" },
                        { displayText: "Refren", fullText: "Refren", hoverText: "Refrain" },
                        { displayText: "Koʻprik", fullText: "Koʻprik", hoverText: "Bridge" },
                        { displayText: "Breykdaun", fullText: "Breykdaun", hoverText: "Breakdown" },
                        { displayText: "Oraliq", fullText: "Oraliq", hoverText: "Interlude" },
                        { displayText: "Cholgʻu qismi", fullText: "Cholgʻu qismi", hoverText: "Instrumental" },
                        { displayText: "Oʻtish", fullText: "Oʻtish", hoverText: "Transition" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "vi": { // Vietnamese
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: "Translation", fullText: "Translation", hoverText: "Translation" },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Intro", fullText: "Intro", hoverText: "Intro" },
                        { displayText: "Outro", fullText: "Outro", hoverText: "Outro" },
                        { displayText: "Skit", fullText: "Skit", hoverText: "Skit" },
                        { displayText: "Part", fullText: "Part", hoverText: "Part" },
                        { displayText: "Verse", fullText: "Verse", hoverText: "Verse" },
                        { displayText: "Pre-Chorus", fullText: "Pre-Chorus", hoverText: "Pre-Chorus" },
                        { displayText: "Chorus", fullText: "Chorus", hoverText: "Chorus" },
                        { displayText: "Post-Chorus", fullText: "Post-Chorus", hoverText: "Post-Chorus" },
                        { displayText: "Refrain", fullText: "Refrain", hoverText: "Refrain" },
                        { displayText: "Bridge", fullText: "Bridge", hoverText: "Bridge" },
                        { displayText: "Breakdown", fullText: "Breakdown", hoverText: "Breakdown" },
                        { displayText: "Interlude", fullText: "Interlude", hoverText: "Interlude" },
                        { displayText: "Build", fullText: "Build", hoverText: "Build" },
                        { displayText: "Drop", fullText: "Drop", hoverText: "Drop" }
                    ]
                },
                "zh-Hant": { // Traditional Chinese
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
                "zh": { // Simplified Chinese
                    Default: [
                        { displayText: "Header", fullText: "Header", hoverText: "Header" },
                        { displayText: null, fullText: null, hoverText: null },
                        { displayText: "Instrumental", fullText: "Instrumental", hoverText: "Instrumental" },
                        { displayText: null, fullText: null, hoverText: null },
                    ]
                },
            };

            const langLabels = HEADERS[storedLanguage];
            const buttonLabels = langLabels?.[primaryTag] || langLabels?.Default || [];

            renderButtons(
                headerDiv,
                buttonLabels.map(b => ({
                    label: b.displayText,
                    fullText: b.fullText,
                    hoverText: b.hoverText
                })),
                (name) => editmetadatabutonSmallbutton.className.replace("EditMetadataButton", `${name}Button`),
                storedLanguage
            );

            lyricseditexplainerContainer.parentNode.insertBefore(headerDiv, lyricseditexplainerContainer);

            // STYLE BUTTONS
            const styleDiv = createGridContainer("lyricsStyleButtonsContainer");

            const STYLES = {
                default: [
                    { label: "<i>Italic</i>", openTag: "<i>", closeTag: "</i>", hoverText: "Italic" },
                    { label: "<b>Bold</b>", openTag: "<b>", closeTag: "</b>", hoverText: "Bold" },
                    { label: "<b><i>Italic + Bold</i></b>", openTag: "<b><i>", closeTag: "</i></b>", hoverText: "Italic+Bold" },
                    { label: "Parentheses", openTag: "(", closeTag: ")", hoverText: "Parentheses" },
                    {
                        label: "Diacritics",
                        isDropdown: true,
                        hoverText: "Diacritics (uppercase)",
                        items: [
                            "Á", "À", "Â", "Ä",
                            "É", "È", "Ê", "Ë",
                            "Í", "Ì", "Î", "Ï",
                            "Ó", "Ò", "Ô", "Ö",
                            "Ú", "Ù", "Û", "Ü",
                            "Ć", "Ń", "Ś", "Ź",
                            "Č", "Ğ", "Š", "Ž",
                            "Ç", "Ş", "I", "Ñ",
                            "Đ", "Æ", "Œ", "ẞ",
                        ]
                    },
                    {
                        label: "Diacritics",
                        isDropdown: true,
                        hoverText: "Diacritics (lowercase)",
                        items: [
                            "á", "à", "â", "ä",
                            "é", "è", "ê", "ë",
                            "í", "ì", "î", "ï",
                            "ó", "ò", "ô", "ö",
                            "ú", "ù", "û", "ü",
                            "ć", "ń", "ś", "ź",
                            "č", "ğ", "š", "ž",
                            "ç", "ş", "ı", "ñ",
                            "đ", "æ", "œ", "ß",
                        ]
                    },
                    {
                        label: "Symbols",
                        isDropdown: true,
                        hoverText: "Symbols",
                        items: [
                            { label: "(", openTag: "&#40;", closeTag: "" },
                            { label: ")", openTag: "&#41;", closeTag: "" },
                            { label: "<", openTag: "&lt;", closeTag: "" },
                            { label: ">", openTag: "&gt;", closeTag: "" },
                            { label: "–", openTag: "–", closeTag: "" },
                            { label: "—", openTag: "—", closeTag: "" },
                            { label: "„...“", openTag: "„", closeTag: "“" },
                            { label: "ZWSP", openTag: "&ZeroWidthSpace;", closeTag: "" },
                            { label: "NBSP", openTag: "&nbsp;", closeTag: "" },
                        ]
                    }
                ],
                de: {
                    Default: [
                        { label: "<i>Italic</i>", openTag: "<i>", closeTag: "</i>", hoverText: "Italic" },
                        { label: "<b>Bold</b>", openTag: "<b>", closeTag: "</b>", hoverText: "Bold" },
                        { label: "<b><i>Italic + Bold</i></b>", openTag: "<b><i>", closeTag: "</i></b>", hoverText: "Italic+Bold" },
                        { label: null, openTag: null, closeTag: null, hoverText: null },

                        { label: "(<i>Italic</i>)", openTag: "(<i>", closeTag: "</i>)", hoverText: "(<i></i>)" },
                        { label: "(<b>Bold</b>)", openTag: "(<b>", closeTag: "</b>)", hoverText: "(<b></b>)" },
                        { label: "(<b><i>Italic + Bold</i></b>)", openTag: "(<b><i>", closeTag: "</i></b>)", hoverText: "(<b><i></i></b>)" },
                        { label: null, openTag: null, closeTag: null, hoverText: null },

                        {
                            label: "Diacritics",
                            isDropdown: true,
                            hoverText: "Diacritics (uppercase)",
                            items: [
                                "Á", "À", "Â", "Ä",
                                "É", "È", "Ê", "Ë",
                                "Í", "Ì", "Î", "Ï",
                                "Ó", "Ò", "Ô", "Ö",
                                "Ú", "Ù", "Û", "Ü",
                                "Ć", "Ń", "Ś", "Ź",
                                "Č", "Ğ", "Š", "Ž",
                                "Ç", "Ş", "I", "Ñ",
                                "Đ", "Æ", "Œ", "ẞ",
                            ]
                        },
                        {
                            label: "Diacritics",
                            isDropdown: true,
                            hoverText: "Diacritics (lowercase)",
                            items: [
                                "á", "à", "â", "ä",
                                "é", "è", "ê", "ë",
                                "í", "ì", "î", "ï",
                                "ó", "ò", "ô", "ö",
                                "ú", "ù", "û", "ü",
                                "ć", "ń", "ś", "ź",
                                "č", "ğ", "š", "ž",
                                "ç", "ş", "ı", "ñ",
                                "đ", "æ", "œ", "ß",
                            ]
                        },
                        {
                            label: "Symbols",
                            isDropdown: true,
                            hoverText: "Symbols",
                            items: [
                                { label: "(", openTag: "&#40;", closeTag: "" },
                                { label: ")", openTag: "&#41;", closeTag: "" },
                                { label: "<", openTag: "&lt;", closeTag: "" },
                                { label: ">", openTag: "&gt;", closeTag: "" },
                                { label: "ZWSP", openTag: "&ZeroWidthSpace;", closeTag: "" },
                                { label: "–", openTag: "–", closeTag: "" },
                                { label: "THSP", openTag: "&thinsp;", closeTag: "" },
                                { label: "—", openTag: "—", closeTag: "" },
                                { label: "NBSP", openTag: "&nbsp;", closeTag: "" },
                                { label: "„...“", openTag: "„", closeTag: "“" },
                            ]
                        }
                    ]
                },
                ja: {
                    Default: [
                        { label: "<i>Italic</i>", openTag: "<i>", closeTag: "</i>", hoverText: "Italic" },
                        { label: "<b>Bold</b>", openTag: "<b>", closeTag: "</b>", hoverText: "Bold" },
                        { label: "<b><i>Italic + Bold</i></b>", openTag: "<b><i>", closeTag: "</i></b>", hoverText: "Italic+Bold" },
                        { label: "Parentheses", openTag: "(", closeTag: ")", hoverText: "Parentheses" },
                        {
                            label: "Diacritics",
                            isDropdown: true,
                            hoverText: "Diacritics (uppercase)",
                            items: [
                                "Á", "À", "Â", "Ä",
                                "É", "È", "Ê", "Ë",
                                "Í", "Ì", "Î", "Ï",
                                "Ó", "Ò", "Ô", "Ö",
                                "Ú", "Ù", "Û", "Ü",
                                "Ć", "Ń", "Ś", "Ź",
                                "Č", "Ğ", "Š", "Ž",
                                "Ç", "Ş", "I", "Ñ",
                                "Đ", "Æ", "Œ", "ẞ",
                            ]
                        },
                        {
                            label: "Diacritics",
                            isDropdown: true,
                            hoverText: "Diacritics (lowercase)",
                            items: [
                                "á", "à", "â", "ä",
                                "é", "è", "ê", "ë",
                                "í", "ì", "î", "ï",
                                "ó", "ò", "ô", "ö",
                                "ú", "ù", "û", "ü",
                                "ć", "ń", "ś", "ź",
                                "č", "ğ", "š", "ž",
                                "ç", "ş", "ı", "ñ",
                                "đ", "æ", "œ", "ß",
                            ]
                        },
                        {
                            label: "Symbols",
                            isDropdown: true,
                            hoverText: "Symbols",
                            items: [
                                { label: "(", openTag: "&#40;", closeTag: "" },
                                { label: ")", openTag: "&#41;", closeTag: "" },
                                { label: "<", openTag: "&lt;", closeTag: "" },
                                { label: ">", openTag: "&gt;", closeTag: "" },
                                { label: "–", openTag: "–", closeTag: "" },
                                { label: "—", openTag: "—", closeTag: "" },
                                { label: "„...“", openTag: "„", closeTag: "“" },
                                { label: "ZWSP", openTag: "&ZeroWidthSpace;", closeTag: "" },
                                { label: "NBSP", openTag: "&nbsp;", closeTag: "" },
                            ]
                        },
                        {
                            label: "Symbols",
                            isDropdown: true,
                            hoverText: "Symbols",
                            items: [
                                { label: "！", openTag: "！", closeTag: "" },
                                { label: "？", openTag: "？", closeTag: "" },
                                { label: "、", openTag: "、", closeTag: "" },
                                { label: "…", openTag: "…", closeTag: "" },
                                { label: "「...」", openTag: "「", closeTag: "」" },
                            ]
                        }
                    ],
                },
            };

            const langStyleButtons = STYLES[storedLanguage];
            const styleButtons = langStyleButtons?.Default || STYLES.default;

            renderButtons(
                styleDiv,
                styleButtons,
                (name) => editmetadatabutonSmallbutton.className.replace("EditMetadataButton", `${name}Button`),
                storedLanguage
            );

            lyricseditexplainerContainer.parentNode.insertBefore(styleDiv, lyricseditexplainerContainer);

        } else {
            // NON-MUSIC STYLE BUTTONS
            const styleDiv = createGridContainer("lyricsStyleButtonsContainer");

            const styleButtons = isGeniusSongExpandSectionsButtons
                ? [
                    { label: "Heading 1", openTag: "<h1>", closeTag: "</h1>", hoverText: "Heading 1" },
                    { label: "Heading 2", openTag: "<h2>", closeTag: "</h2>", hoverText: "Heading 2" },
                    { label: "Heading 3", openTag: "<h3>", closeTag: "</h3>", hoverText: "Heading 3" },
                    { label: "Heading 4", openTag: "<h4>", closeTag: "</h4>", hoverText: "Heading 4" },

                    { label: "Italic", openTag: "<i>", closeTag: "</i>", hoverText: "Italic" },
                    { label: "Bold", openTag: "<b>", closeTag: "</b>", hoverText: "Bold" },
                    { label: "Italic + Bold", openTag: "<b><i>", closeTag: "</i></b>", hoverText: "Italic+Bold" },
                    { label: "Monospace", openTag: "<code>", closeTag: "</code>", hoverText: "Monospace" },

                    { label: "Strike-through", openTag: "<del>", closeTag: "</del>", hoverText: "Strike-through" },
                    { label: "Underline", openTag: "<ins>", closeTag: "</ins>", hoverText: "Underline" },
                    { label: "Superscript", openTag: "<sup>", closeTag: "</sup>", hoverText: "Superscript" },
                    { label: "Subscript", openTag: "<sub>", closeTag: "</sub>", hoverText: "Subscript" },

                    { label: "Center", openTag: "<center>", closeTag: "</center>", hoverText: "Center" },
                    { label: "Small", openTag: "<small>", closeTag: "</small>", hoverText: "Small" },
                    { label: "Large", openTag: "<big>", closeTag: "</big>", hoverText: "Large" },
                    { label: "Horizontal Rule", openTag: "<hr>", closeTag: "", hoverText: "Horizontal Rule" },

                    { label: "Link", openTag: "[", closeTag: "]()", hoverText: "Link" },
                    { label: "Image", openTag: "<img src=\"", closeTag: "\">", hoverText: "Image" },
                    { label: "Abbreviation", openTag: "<abbr title=\"", closeTag: "\"></abbr>", hoverText: "Abbreviation" },
                    { label: "Preformatted", openTag: "<pre>", closeTag: "</pre>", hoverText: "Preformatted" },

                    { label: "Table", openTag: "<table>", closeTag: "</table>", hoverText: "Table" },
                    { label: "Table Header", openTag: "<th>", closeTag: "</th>", hoverText: "Table Header" },
                    { label: "Table Row", openTag: "<tr>", closeTag: "</tr>", hoverText: "Table Row" },
                    { label: "Table Data", openTag: "<td>", closeTag: "</td>", hoverText: "Table Data" },

                    { label: "Unordered List", openTag: "<ul>", closeTag: "</ul>", hoverText: "Unordered List" },
                    { label: "Ordered List", openTag: "<ol>", closeTag: "</ol>", hoverText: "Ordered List" },
                    { label: "List Item", openTag: "<li>", closeTag: "</li>", hoverText: "List Item" },
                    { label: null, openTag: null, closeTag: null, hoverText: null },

                    { label: "NBSP", openTag: "&nbsp;", closeTag: "", hoverText: "Non-Breaking Space" },
                    { label: "THSP", openTag: "&thinsp;", closeTag: "", hoverText: "Thin Space" },
                    { label: "ZWSP", openTag: "&ZeroWidthSpace;", closeTag: "", hoverText: "Zero-width space" },
                ]
                : [
                    { label: "Heading 1", openTag: "<h1>", closeTag: "</h1>", hoverText: "Heading 1" },
                    { label: "Heading 2", openTag: "<h2>", closeTag: "</h2>", hoverText: "Heading 2" },
                    { label: "Heading 3", openTag: "<h3>", closeTag: "</h3>", hoverText: "Heading 3" },
                    { label: "Heading 4", openTag: "<h4>", closeTag: "</h4>", hoverText: "Heading 4" },

                    { label: "Italic", openTag: "<i>", closeTag: "</i>", hoverText: "Italic" },
                    { label: "Bold", openTag: "<b>", closeTag: "</b>", hoverText: "Bold" },
                    { label: "Italic + Bold", openTag: "<b><i>", closeTag: "</i></b>", hoverText: "Italic+Bold" },
                    { label: "Monospace", openTag: "<code>", closeTag: "</code>", hoverText: "Monospace" },

                    { label: "Strike-through", openTag: "<del>", closeTag: "</del>", hoverText: "Strike-through" },
                    { label: "Underline", openTag: "<ins>", closeTag: "</ins>", hoverText: "Underline" },
                    { label: "Link", openTag: "[", closeTag: "]()", hoverText: "Link" },
                    { label: "Image", openTag: "<img src=\"", closeTag: "\">", hoverText: "Image" },

                    { label: "Center", openTag: "<center>", closeTag: "</center>", hoverText: "Center" },
                    { label: "Small", openTag: "<small>", closeTag: "</small>", hoverText: "Small" },
                    { label: "Horizontal Rule", openTag: "<hr>", closeTag: "", hoverText: "Horizontal Rule" },
                    { label: "ZWSP", openTag: "&ZeroWidthSpace;", closeTag: "", hoverText: "Zero-width space" },

                    { label: "Unordered List", openTag: "<ul>", closeTag: "</ul>", hoverText: "Unordered List" },
                    { label: "Ordered List", openTag: "<ol>", closeTag: "</ol>", hoverText: "Ordered List" },
                    { label: "List Item", openTag: "<li>", closeTag: "</li>", hoverText: "List Item" },
                    { label: "NBSP", openTag: "&nbsp;", closeTag: "", hoverText: "Non-Breaking Space" },
                ];

            renderButtons(
                styleDiv,
                styleButtons,
                (name) => editmetadatabutonSmallbutton.className.replace("EditMetadataButton", `${name}Button`)
            );

            lyricseditexplainerContainer.parentNode.insertBefore(styleDiv, lyricseditexplainerContainer);
        }
    }

    function lyricsCleanupLogic(cleanupType) {
        const { lyricsTextareaInputTextarea } = getDomElements();

        if (lyricsTextareaInputTextarea) {
            const originalText = lyricsTextareaInputTextarea.value;

            let text = lyricsTextareaInputTextarea.value;

            const storedLanguage = localStorage.getItem("selectedLanguage");

            const replacementsGeneral = {
                '`': "'", 	// Grave Accent
                '´': "'", 	// Acute Accent
                '＇': "'", 	// Fullwidth Apostrophe
                'ʹ': "'", 	// Modifier Letter Prime
                //'ʻ': "'", 	// Modifier Letter Turned Comma
                'ʼ': "'", 	// Modifier Letter Apostrophe
                'ʽ': "'", 	// Modifier Letter Reversed Comma
                'ʾ': "'", 	// Modifier Letter Right Half Ring
                'ʿ': "'", 	// Modifier Letter Left Half Ring
                'ˊ': "'", 	// Modifier Letter Acute Accent
                'ˋ': "'", 	// Modifier Letter Grave Accent
                '′': "'", 	// Prime
                '‵': "'", 	 // Reversed Prime
                '‘': "'", 	// Left Single Quotation Mark
                '‚': "'", 	// Single Low-9 Quotation Mark
                '‛': "'",	// Single High-Reversed-9 Quotation Mark
                '”': '"', 	// Right Double Quotation Mark
                '″': '"', 	// Double Prime
                '‶': '"', 	// Reversed Double Prime
                'ʺ': '"', 	// Modifier Letter Double Prime
                'ˮ': '"', 	// Modifier Letter Double Apostrophe
                '‟': '"', 	// Double High-Reversed-9 Quotation Mark
                '〝': '"', 	// Reversed Double Prime
                '〞': '"', 	// Double Prime Quotation Mark
                '⟪': '"', 	// Mathematical Left Double Angle Bracket
                '⟫': '"',	// Mathematical Right Double Angle Bracket
                '⪡': '"',	// Double Nested Less-Than
                '⪢': '"', 	// Double Nested Greater-Than
                '⪻': '"',	// Double Precedes
                '⪼': '"', 	// Double Succeeds
            };

            const replacementsLanguage = {
                '„': '"', 	// Double Low-9 Quotation Mark (German)
                '“': '"', 	// Left Double Quotation Mark (German)
                '«': '"',	// Left Pointing Double Angle Quotation Mark (Ukraine/Russia)
                '»': '"',	// Right Pointing Double Angle Quotation Mark (Ukraine/Russia)
                '《': '"',	// Left Pointing Double Angle Quotation Mark (Chinese)
                '》': '"',	// Right Pointing Double Angle Quotation Mark (Chinese)
                '"': (i => {
                    if (storedLanguage === 'de') {
                        return i % 2 === 0 ? '„' : '“'; 	// German quotation marks
                    } else if (storedLanguage === 'zh' || storedLanguage === 'zh-Hant') {
                        return i % 2 === 0 ? '《' : '》'; 	// Chinese quotation marks
                    } else if (storedLanguage === 'ru' || storedLanguage === 'uk' || storedLanguage === 'uz') {
                        return i % 2 === 0 ? '«' : '»'; 	// Russian/Ukrainian quotation marks
                    } else {
                        return '"'; // Default quotation mark
                    }
                })
            };

            replacementsLanguage['ʻ'] = storedLanguage !== 'uz' ? "'" : "ʻ";   // Modifier Letter Turned Comma
            replacementsLanguage['’'] = storedLanguage !== 'uz' ? "'" : "’";   // Right Single Quotation Mark


            const lines = text.split('\n');
            let index = 0;

            const processedLines = lines.map(line => {
                if (line.startsWith('[') && line.endsWith(']')) return line;
                if (line.startsWith('<b>[') && line.endsWith(']</b>')) return line;


                line = line.trim().replace(/ +/g, ' ');

                if (cleanupType === 'capitalization') {
                    line = line.toLowerCase();
                }

                if (cleanupType === 'punctuation') {
                    line = line.replace(/[.!]/g, '').replace(/\/\/|\\\\/g, '');
                }

                if (line.length > 0) {
                    line = line.charAt(0).toUpperCase() + line.slice(1);
                }

                if (cleanupType === 'general' || cleanupType === 'language') {
                    // Capitalize the first letter at line start and after punctuation (. ! ? ")
                    line = line.replace(
                        /(^|[.!?]\s+|\s+"|^\s*")(\p{L})/gu,
                        (match, prefix, char) => prefix + char.toUpperCase()
                    );
                    //ASCII
                    /*line = line.replace(/(^|\.\s+|!\s+|\?\s+|\s+"|^\s*")(\w)/g, (match, prefix, char) => {
                        return prefix + char.toUpperCase();
                    });*/

                    // Capitalize the first letter at line start with HTML tags
                    line = line.replace(/(^|\n|\r)(\s*(?:<[^>]+>\s*)+)([a-zA-Z])/g, (match, prefix, tags, char) => {
                        return prefix + tags + char.toUpperCase();
                    });

                    // Capitalize after opening brackets "("
                    line = line.replace(/(\()\s*(\w)/g, (match, bracket, char) => {
                        return bracket + char.toUpperCase();
                    });

                    // Capitalize after opening brackets "[" at the beginning of the line
                    line = line.replace(/^(\[)\s*(\w)/g, (match, bracket, char) => {
                        return bracket + char.toUpperCase();
                    });

                    // Capitalize after opening brackets "(" with HTML tags in between
                    line = line.replace(/^(\[)\s*((?:<[^>]+>\s*)+)(\w)/g, (match, bracket, tags, char) => {
                        return bracket + tags + char.toUpperCase();
                    });

                    // Capitalize after opening brackets "[" with HTML tags in between at the beginning of the line
                    line = line.replace(/(\()\s*((?:<[^>]+>\s*)+)(\w)/g, (match, bracket, tags, char) => {
                        return bracket + tags + char.toUpperCase();
                    });

                    for (const [key, value] of Object.entries(replacementsGeneral)) {
                        const regex = new RegExp(key, 'g');
                        line = line.replace(regex, value);
                    }

                    if (cleanupType === 'language') {
                        for (const [key, value] of Object.entries(replacementsLanguage)) {
                            const regex = new RegExp(key, 'g');
                            line = line.replace(regex, (match) => {
                                return typeof value === 'function' ? value(index++) : value;
                            });
                        }

                        if (storedLanguage === 'en') {
                            line = line.replace(/^(['"]?\s*<[^>]*>\s*|\s*['"])?(['"]?\w|'\w)/, (match, prefix, word) => {
                                if (word.startsWith("'")) {
                                    return (prefix || '') + "'" + word.charAt(1).toUpperCase() + word.slice(2);
                                } else {
                                    return (prefix || '') + word.charAt(0).toUpperCase() + word.slice(1);
                                }
                            });

                            line = line.replace(/\bi\b(?!>)/g, 'I');

                            line = line.replace(/\b(ai|are|ca|could|did|do|does|had|have|is|must|should|was|were|wo|would)nt\b/gi, (match, verb) => {
                                return `${verb.toLowerCase()}n't`;
                            });

                            line = line.replace(/\b(i|they|we|you)ve\b/gi, (match, subject) => {
                                return `${subject.toLowerCase()}'ve`;
                            });

                            line = line.replace(/\b(he|they|why|you)d\b/gi, (match, subject) => {
                                return `${subject.toLowerCase()}'d`;
                            });

                            line = line.replace(/\b(that|there|they|where|who)ll\b/gi, (match, subject) => {
                                return `${subject.toLowerCase()}'ll`;
                            });

                            line = line.replace(/\b(everybody|everyone|he|she|somebody|someone|that|there|they|where|who)s\b/gi, (match, subject) => {
                                return `${subject.toLowerCase()}'s`;
                            });

                            line = line.replace(/\b(mon|tues|wednes|thurs|fri|satur|sun)day\b|\b(janu|febru)ary\b|\b(septem|octo|novem|decem)ber\b|\b(dr|mr|mrs|ms)(\b|\.)|\b(april|june|july|august|advent|christmas|easter|halloween|hanukkah|kwanzaa|michaelmas|passover|purim|ramadan|thanksgiving|jupiter|mars|neptune|pluto|saturn|uranus|glock|prozac|perc'|percocet)\b/gi, (match) => {
                                return match.charAt(0).toUpperCase() + match.slice(1);
                            });

                            line = line.replace(/\b(AM\b|A\.M\.)/g, 'a.m.');
                            line = line.replace(/\b(PM\b|P\.M\.)/gi, 'p.m.');

                            line = line.replace(/'\bCuz\b/g, "'Cause");
                            line = line.replace(/'\bcuz\b/g, "'cause");

                            line = line.replace(/ & /g, " and ");

                            const slangMap = {
                                'ay': 'ayy',
                                'aye': 'ayy',
                                'boujee': 'bougie',
                                'boujie': 'bougie',
                                "ya'll": "y'all",
                                'yall': "y'all",
                                'ima': "i'ma",
                                'imma': "i'ma",
                                "i'mma": "i'ma",
                                "im'ma": "i'ma",
                                'ok': 'okay',
                                'o.k.': 'okay',
                                'sux': 'sucks',
                                'tec': 'TEC',
                                'alot': 'a lot',
                                'tv': 'TV',
                                'trynna': 'tryna',
                                'skrt': 'skrrt',
                                'whoa': 'woah',
                                // 'dawg': 'dog', // optional – uncomment if desired
                                'choppa': 'chopper',
                                'oughtta': 'oughta',
                                'naïve': 'naive',
                                'cliche': 'cliché'
                            };

                            for (const [key, value] of Object.entries(slangMap)) {
                                const pattern = new RegExp(`\\b${key}\\b`, 'gi');
                                line = line.replace(pattern, value);
                            }

                        }
                    }
                }
                return line;
            });

            lyricsTextareaInputTextarea.value = processedLines.join('\n');

            document.addEventListener('keydown', (event) => {
                if (event.ctrlKey && event.shiftKey && event.key === 'Z') {
                    lyricsTextareaInputTextarea.value = originalText;
                }
            });
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                RECENT ACTIVITY                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    const arrowSvgClosed = createArrowSvg('M4.488 7 0 0h8.977L4.488 7Z');
    const arrowSvgOpen = createArrowSvg('M4.488.5 0 7.5h8.977L4.488.5Z');

    function createArrowSvg(pathData) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 9 7');
        svg.setAttribute('width', '8');
        svg.setAttribute('height', '6.21');
        svg.style.display = "block";

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', pathData);
        svg.appendChild(path);

        return svg;
    }

    const ICONS = {
        svgUpvoted: `
            <svg data-icon-upvoted width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.62 21.36">
                <path d="M16.52 21.29H6V8.5l.84-.13a3.45 3.45 0 0 0 1.82-1.09 13.16 13.16 0 0 0 .82-1.85c1.06-2.69 2-4.78 3.52-5.31a2.06 2.06 0 0 1 1.74.17c2.5 1.42 1 5 .16 6.95-.11.27-.25.6-.31.77a.78.78 0 0 0 .6.36h4.1a2.29 2.29 0 0 1 2.37 2.37c0 .82-1.59 5.4-2.92 9.09a2.39 2.39 0 0 1-2.22 1.46zm-8.52-2h8.56a.48.48 0 0 0 .31-.17c1.31-3.65 2.73-7.82 2.79-8.44 0-.22-.1-.32-.37-.32h-4.1A2.61 2.61 0 0 1 12.54 8 4.29 4.29 0 0 1 13 6.46c.45-1.06 1.64-3.89.7-4.43-.52 0-1.3 1.4-2.38 4.14a10 10 0 0 1-1.13 2.38A5.28 5.28 0 0 1 8 10.11zM0 8.4h4.86v12.96H0z"></path>
            </svg>`,
        svgDownvoted: `
            <svg data-icon-downvoted width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.62 21.36">
                <path d="M8 21.36a2.12 2.12 0 0 1-1.06-.29c-2.5-1.42-1-5-.16-6.95.11-.27.25-.6.31-.77a.78.78 0 0 0-.6-.36H2.37A2.29 2.29 0 0 1 0 10.64c0-.82 1.59-5.4 2.92-9.09A2.39 2.39 0 0 1 5.1.07h10.56v12.79l-.84.13A3.45 3.45 0 0 0 13 14.08a13.16 13.16 0 0 0-.82 1.85c-1.06 2.69-2 4.79-3.49 5.31a2.06 2.06 0 0 1-.69.12zM5.1 2.07a.48.48 0 0 0-.31.17C3.48 5.89 2.07 10.06 2 10.68c0 .22.1.32.37.32h4.1a2.61 2.61 0 0 1 2.61 2.4 4.29 4.29 0 0 1-.48 1.51c-.46 1.09-1.65 3.89-.7 4.42.52 0 1.3-1.4 2.38-4.14a10 10 0 0 1 1.13-2.38 5.27 5.27 0 0 1 2.25-1.56V2.07zM16.76 0h4.86v12.96h-4.86z"></path>
            </svg>`,
        svgPinned: `
            <svg data-icon-pinned width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.82 22">
                <path d="M21.82 20.62L17 15.83l3.59-3.59-3.04-3.07-3.36.12-4.1-4.1v-3L7.91 0 0 7.91l2.16 2.16 2.84.18 4.1 4.12-.1 3.36 3.08 3.08 3.59-3.59L20.43 22zM11 16.94l.12-3.36-5.27-5.24L3 8.16l-.25-.25 5.16-5.14.22.23v3l5.27 5.27 3.36-.12 1.09 1.09L12.06 18z"></path>
            </svg>`,
        svgUnpinned: `
            <svg data-icon-unpinned width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.82 22">
                <path d="M21.82 20.62L17 15.83l3.59-3.59-3.04-3.07-3.36.12-4.1-4.1v-3L7.91 0 0 7.91l2.16 2.16 2.84.18 4.1 4.12-.1 3.36 3.08 3.08 3.59-3.59L20.43 22zM11 16.94l.12-3.36-5.27-5.24L3 8.16l-.25-.25 5.16-5.14.22.23v3l5.27 5.27 3.36-.12 1.09 1.09L12.06 18z"></path>
            </svg>`,
        svgLocked: `
            <svg data-icon-locked width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 15">
                <path fill-rule="evenodd" d="M1.642 6.864H.369V14.5h10.182V6.864H9.278V4.318a3.818 3.818 0 0 0-7.636 0v2.546zm1.272 0h5.091V4.318a2.546 2.546 0 0 0-5.09 0v2.546z"></path>
            </svg>`,
        svgUnlocked: `
            <svg data-icon-unlocked width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18">
                <path fill-rule="evenodd" d="M4.091 8.182H2.454V18h13.092V8.182H5.727V4.91a3.273 3.273 0 0 1 6.545 0h1.637a4.909 4.909 0 0 0-9.818 0v3.273Z"></path>
            </svg>`,
        svgAccepted: `
            <svg data-icon-accepted width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 16.2">
                <path d="M8.83 16.2L0 7.97l2.06-2.21 6.62 6.17L19.79 0 22 2.06 8.83 16.2"></path>
            </svg>`,
        svgRejected: `
            <svg data-icon-deleted width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22">
                <path d="M22 1.39L20.61 0 11 9.62 1.39 0 0 1.39 9.62 11 0 20.61 1.39 22 11 12.38 20.61 22 22 20.61 12.38 11 22 1.39"></path>
            </svg>`,
        svgRecognized: `
            <svg data-icon-recognized width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17.4 22">
                <path d="M15.47 1.92v18.16H1.92V1.92h13.55M17.4 0H0v22h17.4V0z"></path>
                <path d="M5.11 6.45h7.82v1.44H5.11zm0 8.1h7.82v1.44H5.11zm0-4.05h7.82v1.44H5.11z"></path>
            </svg>`,
        svgMerged: `
            <svg data-icon-merged width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.59 22">
                <path d="M16.76 5.87v14.3H6.22V5.87h10.54M18.59 4H4.39v18h14.2V4z"></path>
                <path d="M7.73 8.45h7.44V9.9H7.73zm0 7.7h7.44v1.45H7.73zm0-3.85h7.44v1.45H7.73z"></path>
                <path d="M3.45 19.89H0V0h16.13v3.12H14.2V1.93H1.93v16.03h1.52v1.93"></path>
            </svg>`,
        svgCreated: `
            <svg data-icon-created width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22">
                <path d="M15 10.47h1.7v4.3h-4.4v-3.75c0-2.78.63-5.3 4.39-5.52v2.22c-1.26 0-1.69.88-1.69 2.75zm-7 0h1.7v4.3H5.3v-3.75c0-2.78.63-5.3 4.39-5.52v2.22C8.43 7.72 8 8.6 8 10.47z"></path>
                <path d="M20.09 1.91v18.18H1.91V1.91h18.18M22 0H0v22h22V0z"></path>
            </svg>`,
        svgEdited: `
            <svg data-icon-edited width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19">
                <path d="M17.51 5.827c.654-.654.654-1.636 0-2.29L14.563.59c-.655-.655-1.637-.655-2.291 0L0 12.864V18.1h5.236L17.51 5.827Zm-4.092-4.09 2.946 2.945-2.455 2.454-2.945-2.945 2.454-2.455ZM1.636 16.463v-2.946l8.182-8.182 2.946 2.946-8.182 8.182H1.636Z"></path>
            </svg>`,
        svgSuggested: `
            <svg data-icon-added_a_suggestion_to width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.2 22">
                <path d="M19.29 1.91v11.46H7.69l-.57.7L5 16.64v-3.27H1.91V1.91h17.38M21.2 0H0v15.28h3.12V22l5.48-6.72h12.6V0z"></path>
                <path d="M4.14 4.29h12.93V6.2H4.14zm0 4.09h12.93v1.91H4.14z"></path>
            </svg>`,
        svgFollowed: `
            <svg data-icon-followed width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 18">
                <path d="M20.418 2.53a13.655 13.655 0 0 1 4.806 6.192.818.818 0 0 1 0 .556A13.655 13.655 0 0 1 13 18 13.655 13.655 0 0 1 .776 9.278a.818.818 0 0 1 0-.556A13.655 13.655 0 0 1 13 0c2.667.1 5.246.98 7.418 2.53ZM2.421 9C4.08 13.148 8.664 16.364 13 16.364S21.918 13.148 23.58 9C21.917 4.852 17.335 1.636 13 1.636S4.082 4.852 2.42 9Zm7.852-4.082a4.91 4.91 0 1 1 5.454 8.164 4.91 4.91 0 0 1-5.454-8.164Zm.909 6.803a3.272 3.272 0 1 0 3.636-5.442 3.272 3.272 0 0 0-3.636 5.442Z"></path>
            </svg>`,
        svgHid: `
            <svg data-icon-followed width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 2 11 10">
                <path d="M10.6562 6.8625C9.8312 4.7313 7.7687 3.2875 5.5 3.2188 3.2313 3.2875 1.1688 4.7313.3437 6.8624v.2062C1.1687 9.2 3.1625 10.6438 5.5 10.7126c2.2687-.0688 4.3313-1.5125 5.1562-3.6438v-.2062ZM5.5 10.0938c-1.8563 0-3.7125-1.375-4.4688-3.0938C1.7188 5.2812 3.6437 3.9062 5.5 3.9062S9.2125 5.2813 9.9688 7C9.2125 8.7188 7.2874 10.0938 5.5 10.0938Z"></path>
                <path d="M5.5 4.9375c-1.1688 0-2.0625.8937-2.0625 2.0625 0 1.1687.8937 2.0625 2.0625 2.0625S7.5625 8.1687 7.5625 7c0-1.1688-.8937-2.0625-2.0625-2.0625Zm0 3.4375c-.7562 0-1.375-.6188-1.375-1.375S4.7438 5.625 5.5 5.625 6.875 6.2438 6.875 7 6.2562 8.375 5.5 8.375Z"></path>
                <path d="M1.7713 10.7126 8.795 2.5929l.605.5233-7.0235 8.1197-.605-.5233Z"></path>
            </svg>`,
        svgPyonged: `
            <svg data-icon-pyonged width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11.37 22">
                <path d="M0 7l6.16-7 3.3 7H6.89S5.5 12.1 5.5 12.17h5.87L6.09 22l.66-7H.88l2.89-8z"></path>
            </svg>`,
        svgPageviews: `
            <svg data-icon-pageviews width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 8">
                <path d="M7.714 0v.857h2.823l-3.68 3.68-1.84-1.84a.43.43 0 0 0-.606 0L0 7.108l.606.606 4.108-4.108 1.84 1.84a.43.43 0 0 0 .606 0l3.983-3.983v2.823H12V0z"></path>
            </svg>`,
        svgCurrentPageviews: `
            <svg data-icon-pageviews width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 18">
                <path d="M3.33494 0C3.33494 0 4.09484 1.88505 3.82154 4.2567C3.54779 6.62835 0.236392 9.669 0.250042 12.6792C0.263692 15.6894 5.14004 18 5.14004 18C5.14004 18 4.03634 16.0332 5.97389 12.7953C5.97389 12.7953 8.21519 14.3668 7.98599 15.7594C7.74464 17.2239 6.60914 18 6.60914 18C6.60914 18 13.4295 17.1792 13.4899 11.676C13.551 6.1722 9.49469 2.73315 9.49469 2.73315C9.49469 2.73315 9.94184 4.95165 8.72384 6.97485C8.72384 6.97485 5.67599 0.7605 3.33494 0ZM5.38739 4.30215C6.08369 5.3508 6.77669 6.5532 7.32239 7.66335L8.58509 10.2348L10.0626 7.78005C10.285 7.4103 10.4641 7.0371 10.6069 6.66915C11.3284 7.9623 11.9508 9.6618 11.9287 11.6584C11.9079 13.524 10.786 14.681 9.55904 15.3902C9.44159 13.4235 7.33139 11.8395 6.87059 11.5164L5.49629 10.5534L4.63394 11.9932C3.95714 13.1242 3.58724 14.1443 3.40754 15.03C2.53679 14.3027 1.81514 13.4493 1.81199 12.672C1.80614 11.4366 2.69579 9.9708 3.55619 8.5536C4.40819 7.1514 5.21219 5.8263 5.37299 4.4358C5.37824 4.39095 5.38274 4.34625 5.38739 4.30215Z"></path>
            </svg>`,




        svgMarked: `
            <svg data-icon-marked width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="64 0 20 20">
                <circle cx="74" cy="10" r="9"></circle>
            </svg>`,
        svgVerified: `
            <svg data-icon-user width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10">
                <circle stroke="black" stroke-width="0.75" cx="5" cy="5" r="5"></circle>
                <path  fill="#000" d="M4.43 7 2.25 4.968l.509-.546 1.634 1.524L7.136 3l.546.509L4.43 7Z"></path>
            </svg>`,
        svgGenius: `
            <svg data-icon-user width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <g transform="scale(0.95) translate(0.63,0.63)">
                    <path d="M12.897 1.235c-.36.001-.722.013-1.08.017-.218-.028-.371.225-.352.416-.035 1.012.023 2.025-.016 3.036-.037.841-.555 1.596-1.224 2.08-.5.345-1.118.435-1.671.663.121.78.434 1.556 1.057 2.07 1.189 1.053 3.224.86 4.17-.426.945-1.071.453-2.573.603-3.854.286-.48.937-.132 1.317-.49-.34-1.249-.81-2.529-1.725-3.472a11.125 11.125 0 00-1.08-.04zm-10.42.006C.53 2.992-.386 5.797.154 8.361c.384 2.052 1.682 3.893 3.45 4.997.134-.23.23-.476.09-.73-.95-2.814-.138-6.119 1.986-8.19.014-.986.043-1.976-.003-2.961l-.188-.214c-1.003-.051-2.008 0-3.01-.022zm17.88.055l-.205.356c.265.938.6 1.862.72 2.834.58 3.546-.402 7.313-2.614 10.14-1.816 2.353-4.441 4.074-7.334 4.773-2.66.66-5.514.45-8.064-.543-.068.079-.207.237-.275.318 2.664 2.629 6.543 3.969 10.259 3.498 3.075-.327 5.995-1.865 8.023-4.195 1.935-2.187 3.083-5.07 3.125-7.992.122-3.384-1.207-6.819-3.636-9.19z"></path>
                </g>
            </svg>`,
    }

    function getFilterConfig(ICONS) {
        return {
            FILTERS: [
                { key: "metadata", label: "METADATA", color: "#000000", svg: ICONS.svgGenius },
                { key: "annotations", label: "ANNOTATIONS", color: "#000000", svg: ICONS.svgGenius },
                { key: "votes", label: "VOTES", color: "#000000", svg: ICONS.svgGenius },
                { key: "lyrics", label: "LYRICS", color: "#000000", svg: ICONS.svgGenius },
                { key: "q_and_a", label: "Q&A", color: "#000000", svg: ICONS.svgGenius },
                { key: "other", label: "OTHER", color: "#000000", svg: ICONS.svgGenius },
            ],
            SUBFILTERS: {
                votes: [
                    { key: "votes__upvoted", label: "Upvotes", regex: /.*? upvoted/i, color: "#0ecb27", svg: ICONS.svgUpvoted },
                    { key: "votes__downvoted", label: "Downvotes", regex: /.*? downvoted/i, color: "#ff1414", svg: ICONS.svgDownvoted },
                ],

                other: [
                    { key: "other__locked", label: "Locked / Unlocked", regex: /.*? (locked|unlocked)/i, color: "#9a9a9a", svg: ICONS.svgLocked },
                    { key: "other__hid", label: "Hid / Unhid", regex: /.*? (hid|unhid)/i, color: "#9a9a9a", svg: ICONS.svgHid },
                    { key: "other__followed", label: "Followed", regex: /.*? followed/i, color: "#9a9a9a", svg: ICONS.svgFollowed },
                    { key: "other__pyonged", label: "Pyonged", regex: /.*? pyonged($| an annotation on| the song bio on)/i, color: "#9a9a9a", svg: ICONS.svgPyonged },
                    { key: "other__pageviews", label: "Pageviews", regex: /.*pageviews\)\s*$/i, color: "#0ecb27", svg: ICONS.svgPageviews },
                ],

                q_and_a: [
                    { key: "q_and_a__edited", label: "Q&A Edits", regex: /.*? edited .*?(question|answer) on/i, color: "#9a9a9a", svg: ICONS.svgEdited },
                    { key: "q_and_a__asked_answered", label: "Asked / Answered", regex: /.*?(asked a question|answered a question) on/i, color: "#9a9a9a", svg: ICONS.svgCreated },
                    { key: "q_and_a__pinned_unpinned", label: "Pinned / Unpinned", regex: /.*? (pinned|unpinned) .*? question on/i, color: "#0ecb27", svg: ICONS.svgPinned },
                    { key: "q_and_a__archived_cleared", label: "Archived / Cleared", regex: /.*?(archived .*? question|cleared .*? answer) on/i, color: "#ff1414", svg: ICONS.svgRejected }
                ],

                annotations: [
                    { key: "annotations__annotation", label: "Annotations", regex: /.*?\s(?:created an annotation on|edited an annotation on|proposed an edit to an annotation on|accepted an annotation on|merged\s.*?'?s?\sannotation edit on|deleted an annotation on|rejected an annotation on|rejected\s.*?'?s?\sannotation edit on|marked (?:an|the .*?) annotation on|replied to an annotation on)/i, color: "#9a9a9a", svg: ICONS.svgCreated },
                    { key: "annotations__bio", label: "Song bios", regex: /.*?\s(?:created a song bio on|edited the song bio on|proposed an edit to the song bio on|accepted the song bio on|rejected the song bio on|marked the song bio on)/i, color: "#9a9a9a", svg: ICONS.svgCreated },
                    { key: "annotations__suggestion", label: "Suggestions", regex: /.*?\s(?:added a suggestion to an annotation on|added a suggestion to the song bio on|added a suggestion to$|integrated\s.*?'?s?\ssuggestion|archived\s.*?'?s?\ssuggestion|accepted\s.*?'?s?\ssuggestion|rejected a suggestion|mentioned\s.*? in a suggestion on)/i, color: "#9a9a9a", svg: ICONS.svgSuggested, },

                ],

                lyrics: [
                    { key: "lyrics__edited_lyrics", label: "Lyric edits", regex: /.*? edited the lyrics of/i, color: "#9a9a9a", svg: ICONS.svgEdited },
                    { key: "lyrics__lep", label: "Lyric edit proposals", regex: /.*? (?:rejected .*?|created(?: \d+| a)?|accepted .*?|automatically archived .*?) lyrics edit proposal(?:s)? on/i, color: "#9a9a9a", svg: ICONS.svgEdited },
                    { key: "lyrics__marked", label: "Marked real", regex: /.*?(marked as a real song|thanks! we've been looking for the lyrics to)/i, color: "#38ef51", svg: ICONS.svgRecognized },
                    { key: "lyrics__verified", label: "(Un)verified lyrics", regex: /.*? (verified|unverified) the lyrics of/i, color: "#ffff64", svg: ICONS.svgVerified },
                    { key: "lyrics__complete", label: "(Un)completed lyrics", regex: /.*? (marked|un-?marked) the lyrics complete on/i, color: "#0ecb27", svg: ICONS.svgAccepted }
                ],

                metadata: [
                    { key: "metadata__edited_metadata", label: "Metadata edits", regex: /.*? edited the metadata of/i, color: "#9a9a9a", svg: ICONS.svgEdited },
                    { key: "metadata__created", label: "Song creation", regex: /.*? created$/i, color: "#9a9a9a", svg: ICONS.svgCreated }
                ]
            }
        };
    }

    function filterRecentActivity(profilePath) {
        console.log("Run function filterRecentActivity()");

        const { svgUpvoted, svgDownvoted, svgPinned, svgUnpinned, svgLocked, svgUnlocked, svgAccepted, svgRejected, svgRecognized, svgMerged, svgCreated, svgEdited, svgSuggested, svgFollowed, svgHid, svgPyonged, svgPageviews, svgCurrentPageviews, svgMarked, svgVerified, svgGenius } = ICONS;
        const { FILTERS, SUBFILTERS } = getFilterConfig(ICONS);
        const ALL_SUBFILTERS = Object.values(SUBFILTERS).flat();
        const STORAGE_KEY = "geniusRecentActivityFilters";

        let savedStates = { filters: {}, userText: "" };
        let currentUIState = { checkboxes: null, userInput: null };

        let filterInitialized = false;
        let activityObserver = null;
        let currentActivityContainer = null;


        function saveStateToStorage() {
            if (!isGeniusSongSaveFilters) return;
            chrome.storage.local.set({
                [STORAGE_KEY]: {
                    filters: savedStates.filters,
                    userText: savedStates.userText
                }
            });
        }

        function loadStateFromStorage(callback) {
            if (!isGeniusSongSaveFilters) {
                callback();
                return;
            }

            chrome.storage.local.get(STORAGE_KEY, data => {
                if (data && data[STORAGE_KEY]) {
                    const stored = data[STORAGE_KEY];
                    savedStates.filters = stored.filters || {};
                    savedStates.userText = stored.userText || "";
                }
                callback();
            });
        }


        /* function filterItems(items, filters, userText) {
             let username = userText?.trim().toLowerCase();
 
             if (username && profilePath) {
                 const normalizedProfilePath = profilePath.replace(/^\//, "").trim().toLowerCase();
                 if (username === normalizedProfilePath) username = "you";
             }
 
             const escapedUsername = username ? username.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : null;
             const usernameRegex = escapedUsername ? new RegExp(escapedUsername, "i") : null;
 
             items.forEach(item => {
                 let visible = true;
 
                 //const span = item.querySelector('div[class^="LineItem__MessageContent-"] span');
                 const span = item.querySelector('div[class^="LineItem__MessageContent-"]')?.querySelector(':scope > span > span');
                 if (!span) return;
 
                 const clone = span.cloneNode(true);
                 clone.querySelectorAll("em").forEach(el => el.remove());
                 const text = clone.innerText.trim().toLowerCase().replace(/\s+/g, " ");
 
                 const match = ALL_SUBFILTERS.find(subfilter => subfilter.regex.test(text));
                 if (match && (filters[match.key] ?? true) === false) visible = false;
                 if (visible && usernameRegex && !usernameRegex.test(text)) visible = false;
 //                item.style.display = visible ? "" : "none";
                item.style.visibility = visible ? "visible" : "hidden";
 
 
             });
         }*/


        async function filterItems(items, filters, userText) {
            let username = userText?.trim().toLowerCase();

            if (username && profilePath) {
                const normalizedProfilePath = profilePath.replace(/^\//, "").trim().toLowerCase();
                if (username === normalizedProfilePath) username = "you";
            }

            const escapedUsername = username ? username.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : null;
            const usernameRegex = escapedUsername ? new RegExp(escapedUsername, "i") : null;

            const toHide = [];

            items.forEach(item => {
                let visible = true;

                const span = item.querySelector('div[class^="LineItem__MessageContent-"]')?.querySelector(':scope > span > span');
                if (!span) return;

                const clone = span.cloneNode(true);
                clone.querySelectorAll("em").forEach(el => el.remove());
                const text = clone.innerText.trim().toLowerCase().replace(/\s+/g, " ");

                const match = ALL_SUBFILTERS.find(subfilter => subfilter.regex.test(text));
                if (match && (filters[match.key] ?? true) === false) visible = false;
                if (visible && usernameRegex && !usernameRegex.test(text)) visible = false;

                if (!visible) {
                    item.style.visibility = "hidden";
                    toHide.push(item);
                } else {
                    item.style.visibility = "visible";
                    item.style.display = "";
                }
            });

            await new Promise(r => setTimeout(r, 50));
            window.scrollTo({
                top: document.documentElement.scrollHeight,
                behavior: "smooth"
            });

            await new Promise(r => setTimeout(r, 100));
            toHide.forEach(item => {
                item.style.visibility = "";
                item.style.display = "none";
            });
        }


        function getActivityModal() {
            return document.querySelector('[class^="Modal-desktop__Contents"]');
        }

        function getActivityItems(modal = getActivityModal()) {
            const container = modal?.querySelector('div[class^="LineItemList__Container-"]');
            if (!container) return null;

            return container.querySelectorAll('div[class^="LineItem__ItemRow-"]');
        }

        function applyActivityFilter(checkboxes, userInput) {
            const states = {};
            checkboxes.forEach(cb => {
                states[cb.dataset.filter] = cb.checked;
            });
            states.user = Boolean(userInput.value.trim());

            savedStates.filters = { ...savedStates.filters, ...states };
            savedStates.userText = userInput.value;
            saveStateToStorage();

            const items = getActivityItems();
            if (!items) return;

            filterItems(items, savedStates.filters, savedStates.userText);
        }

        function applyActivityFilterFromState() {
            if (!currentUIState.checkboxes || !currentUIState.userInput) return;
            applyActivityFilter(
                currentUIState.checkboxes,
                currentUIState.userInput
            );
        }

        function applyActivityFilterFromSavedState() {
            const items = getActivityItems();
            if (!items) return;

            filterItems(items, savedStates.filters, savedStates.userText);
        }


        function flexRow(el) {
            el.style.display = "flex";
            el.style.alignItems = "center";
            el.style.gap = "6px";
            el.style.cursor = "pointer";
        }

        function createIconSpan(key, svg) {
            const span = document.createElement("span");
            span.dataset.icon = key;
            span.style.display = "inline-flex";
            span.innerHTML = svg;
            return span;
        }

        function updateIconColors(dropdown, FILTERS) {
            FILTERS.forEach(f => {
                const cb = dropdown.querySelector(`input[data-filter="${f.key}"]`);
                const icon = dropdown.querySelector(`[data-icon="${f.key}"] svg`);
                if (cb && icon) icon.setAttribute("fill", cb.checked ? f.color : "#ddd");
            });

            ALL_SUBFILTERS.forEach(sf => {
                const cb = dropdown.querySelector(`input[data-filter="${sf.key}"]`);
                const icon = dropdown.querySelector(`[data-icon="${sf.key}"] svg`);
                if (cb && icon) icon.setAttribute("fill", cb.checked ? sf.color : "#ddd");
            });

            const userCb = dropdown.querySelector('input[data-filter="user"]');
            const userIcon = dropdown.querySelector('[data-icon="user"] svg');
            if (userIcon && userCb) userIcon.setAttribute("fill", userCb.checked ? "#000" : "#ddd");
        }


        function createFilterGrid(FILTERS, svgGenius) {
            const grid = document.createElement("div");
            grid.style.display = "grid";
            grid.style.gridTemplateColumns = "repeat(3, 1fr)";
            grid.style.gap = "6px 12px";
            grid.style.marginBottom = "10px";

            FILTERS.forEach(f => {
                const wrapper = document.createElement("div");
                wrapper.className = "filter-category";

                const masterLabel = document.createElement("label");
                flexRow(masterLabel);
                masterLabel.style.fontWeight = "600";

                const masterCb = document.createElement("input");
                masterCb.type = "checkbox";
                masterCb.dataset.filter = f.key;
                masterCb.classList.add("master-filter");
                masterCb.style.display = "none";

                const masterIcon = createIconSpan(f.key, f.svg);

                masterLabel.appendChild(masterCb);
                masterLabel.appendChild(masterIcon);
                masterLabel.append(f.label);

                wrapper.appendChild(masterLabel);

                const sub = document.createElement("div");
                sub.className = "subfilters";


                SUBFILTERS[f.key].forEach(sf => {
                    const subLabel = document.createElement("label");
                    flexRow(subLabel);
                    subLabel.style.fontSize = "0.9em";

                    const subCb = document.createElement("input");
                    subCb.type = "checkbox";
                    subCb.dataset.filter = sf.key;
                    subCb.classList.add("subfilter");
                    subCb.style.display = "none";

                    const subIcon = createIconSpan(sf.key, sf.svg);

                    subLabel.appendChild(subCb);
                    subLabel.appendChild(subIcon);
                    subLabel.append(sf.label);

                    sub.appendChild(subLabel);
                });

                wrapper.appendChild(sub);
                grid.appendChild(wrapper);
            });


            const userWrapper = document.createElement("div");
            userWrapper.className = "filter-category";
            userWrapper.style.gridColumn = "1 / span 3";

            const userLabel = document.createElement("label");
            userLabel.style.display = "flex";
            userLabel.style.alignItems = "center";
            userLabel.style.gap = "6px";
            userLabel.style.cursor = "pointer";

            const userCb = document.createElement("input");
            userCb.type = "checkbox";
            userCb.dataset.filter = "user";
            userCb.classList.add("master-filter");
            userCb.style.display = "none";

            const userIcon = createIconSpan("user", svgGenius);

            const userText = document.createElement("span");
            userText.textContent = "USER";
            userText.style.fontWeight = "600";

            const userInput = document.createElement("input");
            userInput.id = "activity-filter-text";
            userInput.placeholder = "User name";
            userInput.style.flex = "1";
            userInput.style.padding = "6px";
            userInput.style.border = "1px solid #ccc";
            userInput.style.borderRadius = "4px";

            userLabel.appendChild(userCb);
            userLabel.appendChild(userIcon);
            userLabel.appendChild(userText);
            userLabel.appendChild(userInput);

            userWrapper.appendChild(userLabel);
            grid.appendChild(userWrapper);
            return grid;
        }

        function addActivityFilterButton(modal) {
            const title = modal?.querySelector('[class^="ContributionsRecentActivity__Title"]');
            if (!title) return;

            if (modal.querySelector("#filter-activity-button")) return;

            const referenceButton = document.querySelector('button[class^="SmallButton__Container"]');
            if (!referenceButton) return;

            const parent = title.parentNode;

            let wrapper = parent.querySelector('.activity-filter-wrapper');
            if (!wrapper) {
                wrapper = document.createElement('div');
                wrapper.className = "activity-filter-wrapper";
                wrapper.style.display = 'flex';
                wrapper.style.alignItems = 'center';
                wrapper.style.justifyContent = 'center';
                wrapper.style.position = 'relative';
                parent.insertBefore(wrapper, title);
                wrapper.appendChild(title);
            }

            const controlContainer = document.createElement("div");
            controlContainer.style.position = "absolute";
            controlContainer.style.right = "0";
            controlContainer.style.top = "25%";
            controlContainer.style.transform = "translateY(-50%)";
            controlContainer.style.display = "flex";
            controlContainer.style.alignItems = "center";
            wrapper.appendChild(controlContainer);

            const counterSpan = document.createElement("span");
            counterSpan.id = "activity-item-count";
            counterSpan.style.marginRight = "0.75rem";
            counterSpan.textContent = "Pages: ...";
            controlContainer.appendChild(counterSpan);

            const filterButton = document.createElement('button');
            filterButton.id = "filter-activity-button";
            filterButton.type = "button";
            filterButton.className = referenceButton.className;

            const arrowSpan = document.createElement("span");
            arrowSpan.style.display = "inline-flex";
            arrowSpan.style.alignItems = "center";
            arrowSpan.style.justifyContent = "center";
            arrowSpan.style.marginLeft = "0.375rem";
            arrowSpan.appendChild(arrowSvgClosed.cloneNode(true));

            filterButton.append("Filter ", arrowSpan);
            controlContainer.appendChild(filterButton);

            const toggleAllButton = document.createElement("button");
            toggleAllButton.id = "activity-filter-toggle-all";
            toggleAllButton.className = referenceButton.className;
            toggleAllButton.textContent = "All / None";
            toggleAllButton.style.position = "absolute";
            toggleAllButton.style.left = "0";
            toggleAllButton.style.top = "25%";
            toggleAllButton.style.transform = "translateY(-50%)";
            toggleAllButton.style.display = "none";
            wrapper.appendChild(toggleAllButton);

            filterButton.addEventListener("click", () => {
                let dropdown = modal.querySelector("#activity-filter-dropdown");

                if (dropdown) {
                    const isClosed = dropdown.style.display === "none";
                    dropdown.style.display = isClosed ? "block" : "none";

                    arrowSpan.replaceChildren(
                        isClosed ? arrowSvgOpen.cloneNode(true) : arrowSvgClosed.cloneNode(true)
                    );

                    toggleAllButton.style.display = isClosed ? "block" : "none";
                    return;
                }

                dropdown = document.createElement("div");
                dropdown.id = "activity-filter-dropdown";
                dropdown.style.padding = "10px";
                dropdown.style.marginBottom = "10px";
                dropdown.style.background = "#fafafa";

                const grid = createFilterGrid(FILTERS, svgGenius);
                dropdown.appendChild(grid);

                wrapper.insertAdjacentElement("afterend", dropdown);

                arrowSpan.replaceChildren(arrowSvgOpen.cloneNode(true));
                toggleAllButton.style.display = "block";

                const checkboxes = dropdown.querySelectorAll('input[type="checkbox"]');
                const normalCheckboxes = [...checkboxes].filter(cb => cb.dataset.filter !== "user");
                const userInput = dropdown.querySelector('#activity-filter-text');

                loadStateFromStorage(() => {
                    FILTERS.forEach(f => {
                        const cb = dropdown.querySelector(`input[data-filter="${f.key}"]`);
                        if (cb) cb.checked = savedStates.filters[f.key] ?? true;
                    });

                    ALL_SUBFILTERS.forEach(sf => {
                        const cb = dropdown.querySelector(`input[data-filter="${sf.key}"]`);
                        if (cb) cb.checked = savedStates.filters[sf.key] ?? true;
                    });

                    const userCb = dropdown.querySelector('input[data-filter="user"]');
                    if (userInput) userInput.value = savedStates.userText ?? "";
                    if (userCb) userCb.checked = Boolean((userInput?.value || "").trim()) || savedStates.filters.user === true;

                    updateIconColors(dropdown, FILTERS);
                    applyActivityFilterFromState();
                });


                updateIconColors(dropdown, FILTERS);

                currentUIState.checkboxes = checkboxes;
                currentUIState.userInput = userInput;


                grid.addEventListener("change", e => {
                    const target = e.target;

                    // Master toggles all subfilters
                    if (target.classList.contains("master-filter")) {
                        const key = target.dataset.filter;
                        const subfilters = grid.querySelectorAll(`input[data-filter^="${key}__"]`);
                        subfilters.forEach(cb => cb.checked = target.checked);
                    }

                    // Subfilters update master state
                    if (target.classList.contains("subfilter")) {
                        const [key] = target.dataset.filter.split("__");
                        const subfilters = grid.querySelectorAll(`input[data-filter^="${key}__"]`);
                        const master = grid.querySelector(`input[data-filter="${key}"]`);

                        master.checked = [...subfilters].every(cb => cb.checked);
                    }

                    updateIconColors(dropdown, FILTERS);

                    applyActivityFilterFromState();
                });

                grid.addEventListener("input", e => {
                    if (e.target.id === "activity-filter-text") {
                        const userCb = dropdown.querySelector('input[data-filter="user"]');
                        if (userCb) userCb.checked = Boolean(e.target.value.trim());
                        savedStates.userText = e.target.value;
                        updateIconColors(dropdown, FILTERS);
                        applyActivityFilterFromState();
                    }
                });

                toggleAllButton.addEventListener("click", () => {
                    const newState = !normalCheckboxes.every(cb => cb.checked);
                    normalCheckboxes.forEach(cb => cb.checked = newState);
                    updateIconColors(dropdown, FILTERS);
                    applyActivityFilterFromState();
                });
            });
        }

        function updateActivityItemCount(modal = getActivityModal()) {
            const items = getActivityItems(modal);
            if (!items) return;

            const counter = modal?.querySelector("#activity-item-count");
            if (counter) counter.textContent = `Pages: ${Math.ceil((items.length - 1) / 30)}`;
        }

        function startActivityObserverIn(modal) {
            const container = modal.querySelector('div[class^="LineItemList__Container-"]');
            if (!container) return;

            if (container === currentActivityContainer) return;

            if (activityObserver) {
                activityObserver.disconnect();
                activityObserver = null;
            }

            currentActivityContainer = container;

            loadStateFromStorage(() => {
                applyActivityFilterFromSavedState();
            });

            const observer = new MutationObserver(() => {
                updateActivityItemCount();
                applyActivityFilterFromSavedState();
            });

            observer.observe(container, {
                childList: true,
                subtree: true
            });

            activityObserver = observer;
        }

        const modalObserver = new MutationObserver(() => {
            const modal = document.querySelector('[class^="Modal-desktop__Contents"]');
            const title = modal?.querySelector('[class^="ContributionsRecentActivity__Title"]');

            if (modal && title && !filterInitialized) {
                addActivityFilterButton(modal);
                filterInitialized = true;
            }

            if (!modal && filterInitialized) {
                filterInitialized = false;
                currentActivityContainer = null;
                currentUIState = {
                    checkboxes: null,
                    userInput: null
                };
                if (activityObserver) {
                    activityObserver.disconnect();
                    activityObserver = null;
                }
            }

            if (modal) {
                startActivityObserverIn(modal);
            }
        });

        modalObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }


    function filterNotifications(profilePath) {
        console.log("Run function filterNotifications()");

        const { svgUpvoted, svgDownvoted, svgPinned, svgLocked, svgAccepted, svgRejected, svgRecognized, svgCreated, svgEdited, svgSuggested, svgFollowed, svgHid, svgPyonged, svgPageviews, svgVerified, svgGenius } = ICONS;
        const { FILTERS, SUBFILTERS } = getFilterConfig(ICONS);
        const ALL_SUBFILTERS = Object.values(SUBFILTERS).flat();
        const STORAGE_KEY = "geniusNotificationFilters";

        let savedStates = { filters: {}, userText: "" };
        let currentUIState = { checkboxes: null, userInput: null };

        let notificationObserver = null;
        let currentContainer = null;
        let dropdownObserverScheduled = false;
        let notificationObserverScheduled = false;
        let hadActiveFilter = false;

        function saveStateToStorage() {
            if (!isGeniusSongSaveFilters) return;
            chrome.storage.local.set({
                [STORAGE_KEY]: {
                    filters: savedStates.filters,
                    userText: savedStates.userText
                }
            });
        }

        function loadStateFromStorage(callback) {
            if (!isGeniusSongSaveFilters) {
                callback();
                return;
            }

            chrome.storage.local.get(STORAGE_KEY, data => {
                if (data && data[STORAGE_KEY]) {
                    const stored = data[STORAGE_KEY];
                    savedStates.filters = stored.filters || {};
                    savedStates.userText = stored.userText || "";
                }
                callback();
            });
        }

        function getHeader(dropdown) {
            return dropdown?.querySelector('div[class^="PageHeaderInbox-desktop__DropdownHeader-"], .feed_dropdown-header') || null;
        }

        function getListContainer(dropdown) {
            return dropdown?.querySelector('div[class^="LineItemList__Container-"], div[infinite-scroll]') || null;
        }

        function isVisibleDropdown(dropdown) {
            if (!dropdown) return false;
            const style = window.getComputedStyle(dropdown);
            return style.display !== "none" && style.visibility !== "hidden";
        }

        function getDropdown() {
            return [...document.querySelectorAll('div[class*="PageHeaderDropdown-desktop__Container-"], div.feed_dropdown')].find(dropdown =>
                isVisibleDropdown(dropdown) &&
                getHeader(dropdown) &&
                getListContainer(dropdown)
            ) || null;
        }

        function getItems(dropdown = getDropdown()) {
            const container = getListContainer(dropdown);
            if (!container) return null;

            return container.querySelectorAll('div[class^="LineItem__ItemRow-"], div.feed_dropdown-item:not(.placeholder)');
        }



        function filterItems(items, filters, userText) {
            let username = userText?.trim().toLowerCase();

            if (username && profilePath) {
                const normalizedProfilePath = profilePath.replace(/^\//, "").trim().toLowerCase();
                if (username === normalizedProfilePath) username = "you";
            }

            const escapedUsername = username ? username.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : null;
            const usernameRegex = escapedUsername ? new RegExp(escapedUsername, "i") : null;

            items.forEach(item => {
                let visible = true;

                const span = item.querySelector('div[class^="LineItem__MessageContent-"] span, div.inbox_line_item-content span');
                if (!span) return;

                const clone = span.cloneNode(true);
                clone.querySelectorAll("em").forEach(el => el.remove());
                const text = clone.innerText.trim().toLowerCase().replace(/\s+/g, " ");

                const match = ALL_SUBFILTERS.find(subfilter => subfilter.regex.test(text));
                if (match && (filters[match.key] ?? true) === false) visible = false;
                if (visible && usernameRegex && !usernameRegex.test(text)) visible = false;
                item.style.display = visible ? "" : "none";
            });
        }

        function hasActiveFilters(filters, userText) {
            const hasDisabledFilter = Object.entries(filters).some(([key, value]) => key !== "user" && value === false);
            const hasUserFilter = Boolean(userText?.trim());
            return hasDisabledFilter || hasUserFilter;
        }

        function applyNotificationFilter(checkboxes, userInput) {
            const states = {};
            checkboxes.forEach(cb => {
                states[cb.dataset.filter] = cb.checked;
            });
            states.user = Boolean(userInput.value.trim());

            savedStates.filters = { ...savedStates.filters, ...states };
            savedStates.userText = userInput.value;
            saveStateToStorage();
            applyNotificationFilterFromSavedState();
        }

        function applyNotificationFilterFromState() {
            if (!currentUIState.checkboxes || !currentUIState.userInput) return;
            applyNotificationFilter(currentUIState.checkboxes, currentUIState.userInput);
        }

        function applyNotificationFilterFromSavedState() {
            const items = getItems();
            if (!items) return;

            const activeFilters = hasActiveFilters(savedStates.filters, savedStates.userText);
            if (!activeFilters) {
                if (hadActiveFilter) {
                    items.forEach(item => {
                        item.style.display = "";
                    });
                }
                hadActiveFilter = false;
                updateNotificationItemCount();
                return;
            }

            hadActiveFilter = true;
            filterItems(items, savedStates.filters, savedStates.userText);
            updateNotificationItemCount();
        }

        function flexRow(el) {
            el.style.display = "flex";
            el.style.alignItems = "center";
            el.style.gap = "6px";
            el.style.cursor = "pointer";
        }

        function createIconSpan(key, svg) {
            const span = document.createElement("span");
            span.dataset.icon = key;
            span.style.display = "inline-flex";
            span.innerHTML = svg;
            return span;
        }

        function updateIconColors(root) {
            FILTERS.forEach(filter => {
                const cb = root.querySelector(`input[data-filter="${filter.key}"]`);
                const icon = root.querySelector(`[data-icon="${filter.key}"] svg`);
                if (cb && icon) icon.setAttribute("fill", cb.checked ? filter.color : "#ddd");
            });

            ALL_SUBFILTERS.forEach(subfilter => {
                const cb = root.querySelector(`input[data-filter="${subfilter.key}"]`);
                const icon = root.querySelector(`[data-icon="${subfilter.key}"] svg`);
                if (cb && icon) icon.setAttribute("fill", cb.checked ? subfilter.color : "#ddd");
            });

            const userCb = root.querySelector('input[data-filter="user"]');
            const userIcon = root.querySelector('[data-icon="user"] svg');
            if (userIcon && userCb) userIcon.setAttribute("fill", userCb.checked ? "#000" : "#ddd");
        }

        function createFilterGrid() {
            const grid = document.createElement("div");
            grid.style.display = "grid";
            grid.style.gridTemplateColumns = "repeat(3, 1fr)";
            grid.style.gap = "6px 12px";

            FILTERS.forEach(filter => {
                const wrapper = document.createElement("div");

                const masterLabel = document.createElement("label");
                flexRow(masterLabel);
                masterLabel.style.color = "black";
                masterLabel.style.fontWeight = "600";
                masterLabel.style.marginBottom = "4px";

                const masterCb = document.createElement("input");
                masterCb.type = "checkbox";
                masterCb.dataset.filter = filter.key;
                masterCb.classList.add("master-filter");
                masterCb.style.display = "none";

                masterLabel.appendChild(masterCb);
                masterLabel.appendChild(createIconSpan(filter.key, filter.svg));
                masterLabel.append(filter.label);
                wrapper.appendChild(masterLabel);

                const sub = document.createElement("div");

                SUBFILTERS[filter.key].forEach(subfilter => {
                    const subLabel = document.createElement("label");
                    flexRow(subLabel);
                    subLabel.style.color = "black";
                    subLabel.style.fontSize = "0.9em";
                    subLabel.style.marginBottom = "2px";

                    const subCb = document.createElement("input");
                    subCb.type = "checkbox";
                    subCb.dataset.filter = subfilter.key;
                    subCb.classList.add("subfilter");
                    subCb.style.display = "none";

                    subLabel.appendChild(subCb);
                    subLabel.appendChild(createIconSpan(subfilter.key, subfilter.svg));
                    subLabel.append(subfilter.label);
                    sub.appendChild(subLabel);
                });

                wrapper.appendChild(sub);
                grid.appendChild(wrapper);
            });

            const userWrapper = document.createElement("div");
            userWrapper.style.paddingTop = "8px";
            userWrapper.style.borderTop = "1px solid #ececec";
            userWrapper.style.gridColumn = "1 / span 3";


            const userLabel = document.createElement("label");
            userLabel.style.display = "flex";
            userLabel.style.alignItems = "center";
            userLabel.style.gap = "6px";
            userLabel.style.cursor = "pointer";

            const userCb = document.createElement("input");
            userCb.type = "checkbox";
            userCb.dataset.filter = "user";
            userCb.classList.add("master-filter");
            userCb.style.display = "none";

            const userInput = document.createElement("input");
            userInput.id = "notification-filter-text";
            userInput.placeholder = "User name";
            userInput.style.flex = "1";
            userInput.style.padding = "6px";
            userInput.style.border = "1px solid #ccc";
            userInput.style.borderRadius = "4px";

            const userText = document.createElement("span");
            userText.textContent = "USER";
            userText.style.color = "black";
            userText.style.fontWeight = "600";

            userLabel.appendChild(userCb);
            userLabel.appendChild(createIconSpan("user", svgGenius));
            userLabel.appendChild(userText);
            userLabel.appendChild(userInput);
            userWrapper.appendChild(userLabel);
            grid.appendChild(userWrapper);

            return grid;
        }

        function getNotificationButtonClassName() {
            const referenceButton = document.querySelector('button[class^="SmallButton__Container"], button.SmallButton__Container-sc-52e3e09f-0');
            return referenceButton?.className || "SmallButton__Container-sc-52e3e09f-0 eAerHv StickyToolbar__SmallButton-sc-6f69c667-5 bmfuOf";
        }

        function createButton(label, className) {
            const button = document.createElement("button");
            button.type = "button";
            button.style.justifyContent = "center";
            button.style.backgroundColor = "white";
            button.style.color = "black";
            button.style.borderColor = "black";

            button.addEventListener("mouseover", () => {
                button.style.backgroundColor = "black";
                button.style.color = "white";
                button.style.borderColor = "white";
            });

            button.addEventListener("mouseout", () => {
                button.style.backgroundColor = "white";
                button.style.color = "black";
                button.style.borderColor = "black";
            });
            if (className) button.className = className;
            if (label) button.textContent = label;
            return button;
        }

        function updateNotificationItemCount() {
            const dropdown = getDropdown();
            const counter = dropdown?.querySelector("#notification-item-count");
            if (!counter) return;

            const items = [...(getItems(dropdown) || [])];
            const visibleItems = items.filter(item => item.style.display !== "none");
            counter.textContent = `Showing ${visibleItems.length}/${items.length}`;
        }

        function addNotificationFilterButton(dropdown) {
            const header = getHeader(dropdown);
            if (!header || dropdown.querySelector("#notification-filter-button")) return;
            const headerLabel = header.querySelector('span[class^="TextLabel-"]') || header.querySelector('span.text_label');
            const label = headerLabel ? headerLabel.textContent.trim().toLowerCase() : "";
            if (label === "forums" || label === "messages") return;



            const buttonClassName = getNotificationButtonClassName();

            const controls = document.createElement("div");
            controls.style.display = "flex";
            controls.style.alignItems = "center";
            controls.style.gap = "8px";
            controls.style.flexWrap = "wrap";
            controls.style.padding = "8px 12px";
            controls.style.background = "#fafafa";

            const counter = document.createElement("span");
            counter.id = "notification-item-count";
            counter.style.marginRight = "auto";
            counter.style.fontSize = "12px";
            counter.style.color = "#666";
            counter.textContent = "Showing 0/0";

            const toggleAllButton = createButton("All / None", buttonClassName);
            toggleAllButton.id = "notification-filter-toggle-all";
            toggleAllButton.style.display = "none";

            const filterButton = createButton("", buttonClassName);
            filterButton.id = "notification-filter-button";

            const arrowSpan = document.createElement("span");
            arrowSpan.style.display = "inline-flex";
            arrowSpan.style.alignItems = "center";
            arrowSpan.style.justifyContent = "center";
            arrowSpan.style.marginLeft = "0.375rem";
            arrowSpan.appendChild(arrowSvgClosed.cloneNode(true));

            filterButton.append("Filter ", arrowSpan);
            controls.appendChild(counter);
            controls.appendChild(toggleAllButton);
            controls.appendChild(filterButton);
            header.insertAdjacentElement("afterend", controls);

            filterButton.addEventListener("click", () => {
                let panel = dropdown.querySelector("#notification-filter-dropdown");

                if (panel) {
                    const isClosed = panel.style.display === "none";
                    panel.style.display = isClosed ? "block" : "none";
                    arrowSpan.replaceChildren(
                        isClosed ? arrowSvgOpen.cloneNode(true) : arrowSvgClosed.cloneNode(true)
                    );
                    toggleAllButton.style.display = isClosed ? "block" : "none";
                    return;
                }

                panel = document.createElement("div");
                panel.id = "notification-filter-dropdown";
                panel.style.padding = "10px 12px 12px";
                panel.style.background = "#fafafa";

                const grid = createFilterGrid();
                panel.appendChild(grid);
                controls.insertAdjacentElement("afterend", panel);

                arrowSpan.replaceChildren(arrowSvgOpen.cloneNode(true));
                toggleAllButton.style.display = "block";

                const checkboxes = panel.querySelectorAll('input[type="checkbox"]');
                const normalCheckboxes = [...checkboxes].filter(cb => cb.dataset.filter !== "user");
                const userInput = panel.querySelector("#notification-filter-text");

                currentUIState.checkboxes = checkboxes;
                currentUIState.userInput = userInput;

                loadStateFromStorage(() => {
                    FILTERS.forEach(filter => {
                        const cb = panel.querySelector(`input[data-filter="${filter.key}"]`);
                        if (cb) cb.checked = savedStates.filters[filter.key] ?? true;
                    });

                    ALL_SUBFILTERS.forEach(subfilter => {
                        const cb = panel.querySelector(`input[data-filter="${subfilter.key}"]`);
                        if (cb) cb.checked = savedStates.filters[subfilter.key] ?? true;
                    });

                    const userCb = panel.querySelector('input[data-filter="user"]');
                    if (userInput) userInput.value = savedStates.userText ?? "";
                    if (userCb) userCb.checked = Boolean((userInput?.value || "").trim()) || savedStates.filters.user === true;

                    updateIconColors(panel);
                    applyNotificationFilterFromState();
                });

                updateIconColors(panel);

                grid.addEventListener("change", e => {
                    const target = e.target;

                    if (target.classList.contains("master-filter")) {
                        const key = target.dataset.filter;
                        const subfilters = grid.querySelectorAll(`input[data-filter^="${key}__"]`);
                        subfilters.forEach(cb => cb.checked = target.checked);
                    }

                    if (target.classList.contains("subfilter")) {
                        const [key] = target.dataset.filter.split("__");
                        const subfilters = grid.querySelectorAll(`input[data-filter^="${key}__"]`);
                        const master = grid.querySelector(`input[data-filter="${key}"]`);
                        if (master) master.checked = [...subfilters].every(cb => cb.checked);
                    }

                    updateIconColors(panel);
                    applyNotificationFilterFromState();
                });

                grid.addEventListener("input", e => {
                    if (e.target.id === "notification-filter-text") {
                        const userCb = panel.querySelector('input[data-filter="user"]');
                        if (userCb) userCb.checked = Boolean(e.target.value.trim());
                        savedStates.userText = e.target.value;
                        updateIconColors(panel);
                        applyNotificationFilterFromState();
                    }
                });

                toggleAllButton.addEventListener("click", () => {
                    const newState = !normalCheckboxes.every(cb => cb.checked);
                    normalCheckboxes.forEach(cb => cb.checked = newState);
                    updateIconColors(panel);
                    applyNotificationFilterFromState();
                });
            });
        }

        function startNotificationObserverIn(dropdown) {
            const container = getListContainer(dropdown);
            if (!container || container === currentContainer) return;

            if (notificationObserver) {
                notificationObserver.disconnect();
                notificationObserver = null;
            }

            currentContainer = container;
            notificationObserverScheduled = false;

            loadStateFromStorage(() => {
                applyNotificationFilterFromSavedState();
            });

            const observer = new MutationObserver(() => {
                if (notificationObserverScheduled) return;
                notificationObserverScheduled = true;
                requestAnimationFrame(() => {
                    notificationObserverScheduled = false;
                    applyNotificationFilterFromSavedState();
                });
            });

            observer.observe(container, {
                childList: true,
                subtree: true
            });

            notificationObserver = observer;
        }

        const notificationDropdownObserver = new MutationObserver(() => {
            if (dropdownObserverScheduled) return;
            dropdownObserverScheduled = true;

            requestAnimationFrame(() => {
                dropdownObserverScheduled = false;
                const dropdown = getDropdown();

                if (!dropdown) {
                    currentContainer = null;
                    hadActiveFilter = false;
                    currentUIState = { checkboxes: null, userInput: null };
                    if (notificationObserver) {
                        notificationObserver.disconnect();
                        notificationObserver = null;
                    }
                    return;
                }

                addNotificationFilterButton(dropdown);
                startNotificationObserverIn(dropdown);
                updateNotificationItemCount();
            });
        });

        notificationDropdownObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }


    function filterFirehose() {
        console.log("Run function filterFirehose()");

        const container = document.querySelector('aside[class^="FirehoseFilters__Container-"]');
        if (!container) return;

        if (document.getElementById("custom_firehose_textfilter")) return;

        const originalSection = container.querySelector('[class^="FirehoseFilterSection__Section-"]');
        if (!originalSection) return;

        const fieldset = originalSection.cloneNode(true);
        fieldset.id = "custom_firehose_textfilter";

        const legend = fieldset.querySelector("legend");
        if (legend) legend.textContent = "DOM Filter";

        fieldset.querySelectorAll("label").forEach(label => label.remove());

        const input = document.createElement("input");
        input.type = "text";
        input.id = "custom_firehose_text_input";
        input.placeholder = "Custom filter...";
        input.autocomplete = "off";
        input.spellcheck = false;

        input.style.cssText = `
            width: 100%;
            outline: none;
            background: transparent;
            font-size: inherit;
            padding: 0.25rem 0.125rem;
            color: inherit;
        `;

        fieldset.appendChild(input);
        container.insertBefore(fieldset, container.firstChild);

        activateFirehoseFilter(input);
    }


    function activateFirehoseFilter(input) {
        const container = document.querySelector('div[class^="FirehoseStream__Container-"]');
        if (!container) return;

        function applyFilter() {
            const query = input.value.trim().toLowerCase();
            console.log("Applying firehose filter with query:", query);
            const items = container.querySelectorAll('div[class^="LineItem__ItemRow-"]');

            items.forEach(item => {
                const textEl = item.querySelector('div[class^="LineItem__MessageContent-"] span');
                const text = textEl ? textEl.textContent.toLowerCase() : "";
                console.log("Checking item with text:", text);

                const parent = item.parentElement;
                if (!parent) return;

                parent.style.display = text.includes(query) ? "block" : "none";
            });
        }

        input.addEventListener("input", applyFilter);

        const observer = new MutationObserver(() => applyFilter());
        observer.observe(container, { childList: true, subtree: true });
    }






    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                       STORE APPLE MUSIC PLAYER STRUCTURE                       //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function storeAppleMusicStructure() {

        function waitForIframe() {
            return new Promise(resolve => {
                const selector = '[class^="AppleMusicPlayer-desktop__Iframe-"]';

                if (document.querySelector(selector)) {
                    resolve();
                    return;
                }

                const observer = new MutationObserver(() => {
                    if (document.querySelector(selector)) {
                        observer.disconnect();
                        resolve();
                    }
                });

                observer.observe(document.documentElement, {
                    childList: true,
                    subtree: true
                });
            });
        }

        function clonePathToRoot(iframeNode) {
            const rootSelector = '[class^="AppleMusicPlayer-desktop__PositioningContainer-"]';

            let current = iframeNode;
            let clonedChild = null;
            let clonedRoot = null;

            while (current) {
                const clone = current.cloneNode(false);

                if (clonedChild) {
                    clone.appendChild(clonedChild);
                }

                clonedChild = clone;

                if (current.matches(rootSelector)) {
                    clonedRoot = clone;
                    break;
                }

                current = current.parentElement;
            }

            return clonedRoot;
        }

        waitForIframe().then(() => {
            const iframe = document.querySelector('[class^="AppleMusicPlayer-desktop__Iframe-"]');
            if (!iframe) return;

            const clone = clonePathToRoot(iframe);
            if (!clone) return;

            localStorage.setItem("AppleMusicStructure", clone.outerHTML);
        });
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               APPLE MUSIC PLAYER                               //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function editAppleMusicPlayer() {
        console.log("Run function editAppleMusicPlayer()");

        function checkAppleMusicPlayer() {
            const { applemusicplayerIframe } = getDomElements();

            if (applemusicplayerIframe) {
                const playerDocument = applemusicplayerIframe.contentDocument;
                const player = playerDocument?.querySelector('apple-music-player');
                if (player) {
                    const titleDiv = player.querySelector('.apple_music_player-player-info-title');
                    const previewTrackAttr = player.getAttribute('preview_track');
                    openAppleMusicUrl(titleDiv, previewTrackAttr);

                    const coverArtImage = player.querySelector('.cover_art-image');
                    const songInfoContainer = player.querySelector('.apple_music_player-player-info');
                    const playButtonContainer = player.querySelector('.apple_music_player-play_button');
                    const appleMusicPlayerLogo = player.querySelector('.apple_music_player-player-logo');
                    return addCopyCoverButton(coverArtImage, songInfoContainer, playButtonContainer, appleMusicPlayerLogo);
                }
            }
            return false;
        }

        function openAppleMusicUrl(titleDiv, previewTrackAttr) {
            if (titleDiv && previewTrackAttr) {
                const previewTrack = JSON.parse(previewTrackAttr.replace(/&quot;/g, '"'));
                const appleId = previewTrack.apple_id;
                const countryCode = previewTrack.country_codes?.[0]?.toLowerCase();

                if (appleId && countryCode) {
                    const appleMusicUrl = `https://music.apple.com/${countryCode}/song/${appleId}`;
                    titleDiv.style.cursor = 'pointer';
                    titleDiv.style.textDecoration = 'none';

                    if (!titleDiv.dataset.listenerAdded) {
                        titleDiv.addEventListener('mouseenter', () => titleDiv.style.textDecoration = 'underline');
                        titleDiv.addEventListener('mouseleave', () => titleDiv.style.textDecoration = 'none');
                        titleDiv.addEventListener('click', (e) => {
                            window.open(appleMusicUrl, '_blank');
                            e.stopPropagation();
                        });
                        titleDiv.dataset.listenerAdded = "true";
                    }
                }
            }
        }

        function addCopyCoverButton(coverArtImage, songInfoContainer, playButtonContainer, appleMusicPlayerLogo) {
            if (isGeniusSongCopyCover) {
                if (coverArtImage && songInfoContainer && playButtonContainer && appleMusicPlayerLogo) {
                    const copyCoverButton = document.createElement('button');
                    copyCoverButton.textContent = 'Copy Cover';

                    Object.assign(copyCoverButton.style, {
                        background: '#fff',
                        color: '#222',
                        border: '1px solid #222',
                        padding: '2px 4px',
                        fontSize: '12px',
                        cursor: 'pointer',
                        lineHeight: '2em',
                        marginRight: '8px',
                        borderRadius: '1.25rem',
                        whiteSpace: 'nowrap'
                    });
                    appleMusicPlayerLogo.parentNode.insertBefore(copyCoverButton, appleMusicPlayerLogo);
                    appleMusicPlayerLogo.remove();

                    copyCoverButton.addEventListener('click', () => {
                        const link = coverArtImage.src;
                        const newLink = link.replace('72x72bb.jpg', '1000x1000bb.png');
                        navigator.clipboard.writeText(newLink).then(() => {
                            const originalText = copyCoverButton.textContent;
                            copyCoverButton.textContent = 'Copied to clipboard';
                            setTimeout(() => copyCoverButton.textContent = originalText, 1500);
                        });
                    });
                    copyCoverButton.addEventListener('mouseover', () => {
                        copyCoverButton.style.backgroundColor = '#111212';
                        copyCoverButton.style.color = '#fff';
                    });
                    copyCoverButton.addEventListener('mouseout', () => {
                        copyCoverButton.style.backgroundColor = '#fff';
                        copyCoverButton.style.color = '#222';
                    });
                }
            }
        }

        if (isGeniusSongAppleMusicPlayer) {
            const observer = new MutationObserver(() => {
                if (checkAppleMusicPlayer()) {
                    observer.disconnect();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });

            checkAppleMusicPlayer();
        } else {
            const { applemusicplayerIframecontainer } = getDomElements();
            if (applemusicplayerIframecontainer) {
                applemusicplayerIframecontainer.remove();
            }
        }
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 YOUTUBE PLAYER                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function editYouTubePlayer() {
        const { youtubebuttonPlayvideobutton } = getDomElements();
        if (!youtubebuttonPlayvideobutton) return;

        if (!isGeniusSongYouTubePlayer) {
            youtubebuttonPlayvideobutton.style.display = "none";
        }

        if (isGeniusSongRenameButtons) {
            const svg = youtubebuttonPlayvideobutton.querySelector("svg");
            if (svg) svg.remove();

            youtubebuttonPlayvideobutton.textContent = "YouTube";
        }

        function adjustYouTubeMargin() {
            const { transcriptionplayerContainer } = getDomElements();
            if (transcriptionplayerContainer) {
                transcriptionplayerContainer.style.margin = "0rem 1rem 0rem 0rem";
            }
        }

        const observer = new MutationObserver(adjustYouTubeMargin);
        observer.observe(document.body, { childList: true, subtree: true });
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                               SOUNDCLOUD PLAYER                                //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function addSoundCloudPlayer(soundcloudUrl) {
        let isSoundCloudPlaying = false;
        let soundCloudContainer = null;

        function addSoundCloudButton(soundcloudUrl) {
            if (!soundcloudUrl) return;

            const { stickytoolbarRight } = getDomElements();
            if (!stickytoolbarRight) return;

            if (stickytoolbarRight.querySelector('#soundcloud-button')) return;

            const metadataButton = document.querySelector('[class*="EditMetadataButton__SmallButton-"]');
            const derivedClass = metadataButton.className.replace("EditMetadataButton__SmallButton", "SoundCloudButton__PlayVideoButton");
            const soundCloudButton = document.createElement("button");
            soundCloudButton.id = "soundcloud-button";
            soundCloudButton.type = "button";
            soundCloudButton.className = derivedClass;
            soundCloudButton.textContent = "SoundCloud";


            soundCloudButton.addEventListener('click', () => {
                if (isSoundCloudPlaying) {
                    stopSoundCloudPlayer();
                } else {
                    loadSoundCloudPlayer(soundcloudUrl);
                }
                isSoundCloudPlaying = !isSoundCloudPlaying;
            });

            stickytoolbarRight.insertBefore(soundCloudButton, stickytoolbarRight.firstChild);
        }


        function loadSoundCloudPlayer(soundcloudUrl) {
            const html = localStorage.getItem("AppleMusicStructure");
            if (!html) return;

            const wrapper = document.createElement("div");
            console.log(wrapper);
            wrapper.innerHTML = html.trim();
            soundCloudContainer = wrapper.firstElementChild;

            soundCloudContainer.className = soundCloudContainer.className.replace(/AppleMusic/g, "SoundCloud");
            soundCloudContainer.querySelectorAll("*").forEach(el => {
                el.classList.forEach(cls => {
                    if (cls.includes("AppleMusic")) {
                        el.classList.replace(cls, cls.replace(/AppleMusic/g, "SoundCloud"));
                    }
                });
            });

            const iframeContainer = soundCloudContainer.querySelector('[class^="SoundCloudPlayer-desktop__IframeContainer-"]');
            if (!iframeContainer) return;

            const iframe = iframeContainer.querySelector("iframe");
            if (!iframe) return;

            iframe.id = "soundcloud-player";

            Object.assign(iframeContainer.style, {
                marginLeft: "0rem",
                marginRight: "1rem",
            });

            Object.assign(iframe.style, {
                height: "116px",
                visibility: "visible",
                display: "block",
                justifySelf: "end",
                pointerEvents: "auto",
            });

            iframe.src = `https://w.soundcloud.com/player/?url=${encodeURIComponent(soundcloudUrl)}&color=%23ff5500&auto_play=true&hide_related=true&show_comments=false&show_user=false&show_reposts=false&show_teaser=false`;
            iframe.setAttribute("allow", "autoplay");

            const { mediaplayerscontainerContainer } = getDomElements();
            if (mediaplayerscontainerContainer) {
                mediaplayerscontainerContainer.insertBefore(soundCloudContainer, mediaplayerscontainerContainer.firstChild);
            }
        }


        function stopSoundCloudPlayer() {
            if (!soundCloudContainer) return;

            const { mediaplayerscontainerContainer } = getDomElements();
            if (mediaplayerscontainerContainer && soundCloudContainer.parentNode) {
                mediaplayerscontainerContainer.removeChild(soundCloudContainer);
            }

            soundCloudContainer = null;
        }

        addSoundCloudButton(soundcloudUrl);
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                 SPOTIFY PLAYER                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    async function addSpotifyPlayer(spotifyUuid, songTitle, primaryArtistsRaw, featuredArtistsRaw, artists) {
        async function getSpotifySongId(spotifyUuid, songTitle, primaryArtistsRaw, featuredArtistsRaw, artists) {
            console.log("Run function getSpotifySongId()");

            if (spotifyUuid) {
                loadSpotifyPlayer(spotifyUuid);
            } else {
                const containsCyrillic = text => /[А-Яа-яЁё]/.test(text);
                const containsChinese = text => /[\u4e00-\u9fff]/.test(text);

                let title = songTitle;
                if (containsCyrillic(title) || containsChinese(title)) {
                    title = title.replace(/\s*\([^)]+\)/g, '').replace(/\s*\[[^\]]+\]/g, '');
                }
                const primaryArtists = (primaryArtistsRaw || [])
                    .map(id => artists[id]?.name || "")
                    .map(name => name.replace(/ *\([^)]*\) */g, "").replace(/\u200B/g, "").trim());

                const featuredArtists = (featuredArtistsRaw || [])
                    .map(id => artists[id]?.name || "")
                    .map(name => name.replace(/ *\([^)]*\) */g, "").replace(/\u200B/g, "").trim());

                const searchSets = {
                    title: new Set([title]),
                    primaryArtists: new Set(primaryArtists),
                    featuredArtists: new Set(featuredArtists),
                    allArtists: new Set([...primaryArtists, ...featuredArtists])
                };

                const tokenResponse = await fetch("https://accounts.spotify.com/api/token", {
                    method: "POST",
                    headers: {
                        "Authorization": "Basic " + btoa(`${window.secrets.SPOTIFY_CLIENT_ID}:${window.secrets.SPOTIFY_CLIENT_SECRET}`),
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: "grant_type=client_credentials"
                });

                const tokenData = await tokenResponse.json();
                const token = `${tokenData.token_type} ${tokenData.access_token}`;



                let queries = [];

                const allArtistsArr = [...searchSets.allArtists];
                const primaryArtistsArr = [...searchSets.primaryArtists];

                if (featuredArtists.length > 1) {
                    queries.push(`${title} ${allArtistsArr.join(" ")}`);
                }

                if (primaryArtists.length > 1) {
                    queries.push(`${title} ${primaryArtistsArr.join(" ")}`);
                }

                for (const artist of searchSets.allArtists) {
                    queries.push(`${title} ${artist}`);
                }

                const responses = await Promise.all(
                    queries.map(async query => {
                        const params = new URLSearchParams({ query, type: "track", limit: 10 });

                        const result = await fetch(`https://api.spotify.com/v1/search?${params}`, {
                            method: "GET",
                            headers: { "Authorization": token }
                        });
                        return result.json();
                    })
                );

                const allTracks = [
                    ...new Map(
                        responses
                            .flatMap(data => (data.tracks && data.tracks.items ? data.tracks.items : []))
                            .map(track => [track.id, track])
                    ).values()
                ];

                const candidates = findCandidateMatches(allTracks, title, allArtistsArr.join(" "));
                const bestCandidate = selectBestMatch(candidates, title, allArtistsArr);

                if (bestCandidate) {
                    loadSpotifyPlayer(bestCandidate.id);
                }
            }
        }

        function loadSpotifyPlayer(spotifyId) {
            if (document.getElementById("spotify-player")) {
                return;
            }

            let spotifyContainer = document.createElement("div");
            spotifyContainer.className = savedClasses.spotifyContainer;
            let spotifyIframeContainer = document.createElement("div");
            spotifyIframeContainer.className = savedClasses.spotifyIframeContainer;

            const styleContainer = savedClasses.spotifyContainer.split(' ').pop();
            const styleIframeWrapper = savedClasses.spotifyIframeContainer.split(' ').pop();
            const styleIframe = savedClasses.spotifyIframe.split(' ').pop();

            const style = document.createElement('style');
            style.innerHTML = `
        .${styleContainer} {
            padding-bottom: 1rem;
        }
        .${styleIframe} {
            margin-bottom: -10px;
        }`;
            document.body.appendChild(style);

            const { applemusicplayerPositioningcontainer } = getDomElements();
            if (applemusicplayerPositioningcontainer) applemusicplayerPositioningcontainer.style.padding = "0";

            let spotifyIframe = document.createElement("iframe");
            spotifyIframe.style.width = "100%";
            spotifyIframe.style.height = "80px";
            spotifyIframe.style.marginRight = "0rem";
            spotifyIframe.style.gridColumn = "left-start / right-end";
            spotifyIframe.style.pointerEvents = "auto";
            spotifyIframe.className = savedClasses.spotifyIframe;
            spotifyIframe.id = "spotify-player";
            spotifyIframe.src = `https://open.spotify.com/embed/track/${spotifyId}`;
            spotifyIframe.setAttribute("allow", "encrypted-media");
            spotifyIframe.setAttribute("allowtransparency", "true");
            spotifyIframeContainer.appendChild(spotifyIframe);
            spotifyContainer.appendChild(spotifyIframeContainer);

            const { mediaplayerscontainerContainer } = getDomElements();
            if (mediaplayerscontainerContainer) {
                mediaplayerscontainerContainer.append(spotifyContainer);
            }
            if (isGeniusSongLyricEditor) {
                function adjustSpotifyPlayerGridColumn() {
                    const { stickytoolbarContainer, stickyNavContainer, lyricsTextareaInputTextarea } = getDomElements();

                    if (lyricsTextareaInputTextarea) {
                        spotifyIframe.style.gridColumn = "right-start / page-end";
                        spotifyIframe.style.marginRight = "1rem";
                        if (applemusicplayerPositioningcontainer) {
                            spotifyIframe.style.paddingLeft = "2.25rem";
                        } else {
                            spotifyIframe.style.paddingLeft = "1.25rem"; spotifyIframe.style.paddingRight = "1rem";
                        }
                        lyricsTextareaInputTextarea.style.marginRight = "0rem";
                        lyricsTextareaInputTextarea.style.position = "relative";
                        lyricsTextareaInputTextarea.style.zIndex = "5";
                        stickytoolbarContainer.style.zIndex = "7";
                        stickyNavContainer.style.zIndex = "8";
                    } else {
                        spotifyIframe.style.gridColumn = "left-start / right-end";
                        spotifyIframe.style.marginRight = "0rem";
                        spotifyIframe.style.paddingLeft = "0rem";
                        stickytoolbarContainer.style.zIndex = "3";
                        stickyNavContainer.style.zIndex = "6";
                    }
                }

                adjustSpotifyPlayerGridColumn();

                const observer = new MutationObserver(adjustSpotifyPlayerGridColumn);
                observer.observe(document.body, { childList: true, subtree: true });
            }
        }

        function normalize(str) {
            return str
                .toLowerCase()                 // convert everything to lowercase
                .replace(/['´‘’]/g, "")        // remove all apostrophe variants
                .replace(/[\-&]/g, " ")        // replace "-" and "&" with spaces
                .replace(/[()]/g, "")          // remove parentheses but keep their content
                .replace(/\u200B/g, "")        // remove zero-width spaces
                .replace(/\s+/g, " ")          // collapse multiple spaces into a single space
                .trim();                       // remove leading and trailing spaces
        }

        function findCandidateMatches(tracks, title, artist) {
            const diff = (a, b) => {
                const aSet = new Set(normalize(a).split(" "));
                const bSet = new Set(normalize(b).split(" "));
                const intersection = new Set([...aSet].filter(x => bSet.has(x)));
                return aSet.size + bSet.size - 2 * intersection.size;
            };

            const target = `${title} ${artist}`;

            const diffs = tracks.map(track => {
                const trackArtists = track.artists.map(a => a.name).join(" ");
                const trackString = `${track.name} ${trackArtists}`;
                const trackDiff = diff(trackString, target);
                return { track, trackDiff };
            });

            const minDiff = Math.min(...diffs.map(d => d.trackDiff));

            return diffs.filter(d => d.trackDiff === minDiff).map(d => d.track);
        }


        function selectBestMatch(tracks, title, artist) {
            let bestTrack = null;
            let bestScore = -Infinity;

            const normalizedTitle = normalize(title);
            const normalizedArtists = artist.map(artist => normalize(artist));

            for (const track of tracks) {
                let score = 0;

                const normalizedTrackTitle = normalize(track.name);
                const normalizedTrackArtists = track.artists.map(a => normalize(a.name));

                const geniusWords = normalizedTitle.split(" ");
                const spotifyWords = normalizedTrackTitle.split(" ");
                const matchCount = geniusWords.filter(word => spotifyWords.includes(word)).length;

                score += matchCount / spotifyWords.length;

                const matches = normalizedArtists.filter(na =>
                    normalizedTrackArtists.some(ta => ta.includes(na))
                ).length;

                score += matches / normalizedTrackArtists.length;

                if (score > bestScore) {
                    bestScore = score;
                    bestTrack = track;
                }
            }
            return bestScore >= 0.75 ? bestTrack : null;
        }

        await getSpotifySongId(spotifyUuid, songTitle, primaryArtistsRaw, featuredArtistsRaw, artists);
    }




    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////                                PLAYER SETTINGS                                 //////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    function playerSettings() {

        if (isGeniusSongLyricEditor) {
            function adjustPlayerGridColumn() {
                const { lyricsTextareaInputTextarea, applemusicplayerPositioningcontainer, applemusicplayerIframecontainer, soundcloudplayerIframecontainer } = getDomElements();

                if (applemusicplayerPositioningcontainer && applemusicplayerIframecontainer) {
                    if (lyricsTextareaInputTextarea) {
                        applemusicplayerIframecontainer.style.gridColumn = "right-start / page-end";
                        applemusicplayerIframecontainer.style.marginRight = "0rem";
                        applemusicplayerPositioningcontainer.style.paddingBottom = "0rem";
                    } else {
                        applemusicplayerIframecontainer.style.gridColumn = "left-start / right-end";
                        applemusicplayerIframecontainer.style.marginRight = "-1rem";
                        applemusicplayerPositioningcontainer.style.paddingBottom = "0.5rem";
                    }
                }

                if (soundcloudplayerIframecontainer) {
                    if (lyricsTextareaInputTextarea) {
                        console.log("1");
                        soundcloudplayerIframecontainer.style.gridColumn = "right-start / page-end";
                    } else {
                        console.log("2");
                        soundcloudplayerIframecontainer.style.gridColumn = "center-end / page-end";
                    }
                }
            }

            adjustPlayerGridColumn();

            const observer = new MutationObserver(adjustPlayerGridColumn);
            observer.observe(document.body, { childList: true, subtree: true });
        }


        document.addEventListener('click', (event) => {
            const button = event.target.closest('button[class*="YoutubeButton__PlayVideoButton-"], button[class*="SoundcloudButton__PlayVideoButton-"]');

            if (button) {
                const checkPlayerInterval = setInterval(() => {
                    const { mediaplayerscontainerContainer, transcriptionplayerContainer } = getDomElements();

                    if (mediaplayerscontainerContainer && transcriptionplayerContainer) {
                        mediaplayerscontainerContainer.insertBefore(transcriptionplayerContainer, mediaplayerscontainerContainer.firstChild);
                        clearInterval(checkPlayerInterval);
                    }
                }, 1);
            }
        });
    }

});
