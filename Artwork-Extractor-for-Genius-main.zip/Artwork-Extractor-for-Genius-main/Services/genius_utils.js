function getScripts2(type) {
    const scripts = document.body.querySelectorAll("script:not([src])");

    const regexMap = {
        preloaded: /window\.__PRELOADED_STATE__\s*=\s*JSON\.parse\('(.+?)'\)/s,
        appConfig: /window\.__APP_CONFIG__\s*=\s*JSON\.parse\('(.+?)'\)/s,
        iqByEventType: /window\.__IQ_BY_EVENT_TYPE__\s*=\s*JSON\.parse\('(.+?)'\)/s
    };

    const regex = regexMap[type];
    if (!regex) return null;

    const parse = (raw) => {
        if (!raw) return null;
        const cleaned = raw
            .replace(/\\"/g, '"')
            .replace(/\\\\/g, '\\')
            .replace(/\\n/g, '\n')
            .replace(/\\r/g, '\r')
            .replace(/\\t/g, '\t')
            .replace(/\\(?!["\\/bfnrtu])/g, "")
            .replace(/[\u0000-\u001F]+/g, "");
        return JSON.parse(cleaned);
    };

    for (const script of scripts) {
        const text = script.textContent;
        const match = text.match(regex);
        if (match) return parse(match[1]);
    }

    return null;
}

function getScripts(keyName) {
    let out = '';

    const unescapeJsString = (raw) => {
        for (let i = 0; i < raw.length; i++) {
            if (raw[i] !== '\\') {
                out += raw[i];
                continue;
            }
            const next = raw[++i];
            switch (next) {
                case 'n': out += '\n'; break;
                case 't': out += '\t'; break;
                case 'r': out += '\r'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'v': out += '\v'; break;
                case '0': out += '\0'; break;
                case 'x': out += String.fromCharCode(parseInt(raw.substr(i + 1, 2), 16)); i += 2; break;
                case 'u': out += String.fromCharCode(parseInt(raw.substr(i + 1, 4), 16)); i += 4; break;
                case '\n': break;
                default: out += next; break;
            }
        }
        return out;
    };

    const script = [...document.scripts].find(s => s.textContent.includes(keyName));
    if (!script) return null;

    const escapedKey = keyName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`${escapedKey}\\s*=\\s*JSON\\.parse\\('((?:[^'\\\\]|\\\\.)*)'\\);`);

    const match = script.textContent.match(regex);
    if (!match) return null;

    try {
        const cleaned = unescapeJsString(match[1]);
        return JSON.parse(cleaned);
    } catch {
        return null;
    }
}


function getId(type) {
    console.log(`Run getId(${type})`);
    const html = document.documentElement.innerHTML;

    const regex = new RegExp(`\\\\"${type}\\\\":(\\d+)`);
    const match = html.match(regex);

    return match ? match[1] : null;
}

function getSongIds() {
    console.log("Run getSongIds()");

    const scripts = document.body.querySelectorAll("script:not([src])");

    for (const script of scripts) {
        const text = script.textContent;

        const preloadedMatch = text.match(/window\.__PRELOADED_STATE__\s*=\s*JSON\.parse\('((?:\\'|[^'])*)'\);/s);
        if (!preloadedMatch) continue;

        const jsonString = preloadedMatch[1];
        const albumAppearances = JSON.parse("{" + jsonString.match(/\\"albumAppearances\\":\{([\s\S]*?)\}(?=,\\"[a-zA-Z])/)[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\') + "}");
        const songIds = Object.values(albumAppearances).sort((a, b) => a.trackNumber - b.trackNumber).map(entry => entry.song);

        return songIds;
    }
}

function getCsrfToken() {
    const match = document.cookie.match(/_csrf_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}

// ? Shared rate limiter for every Genius API call the extension can fan out over a tracklist.
// * Album pages need one request per song, so an unthrottled fan-out gets users rate limited and hammers Genius.
// * Requests queue here and start at most GENIUS_REQUESTS_PER_SECOND per rolling second, in the order they were queued.
const GENIUS_REQUESTS_PER_SECOND = 10;

const rateLimitGeniusRequest = (function createGeniusRateLimiter(maxPerSecond) {
    const windowMs = 1000;
    const starts = [];
    const queue = [];
    let pumpScheduled = false;

    function schedulePump(waitMs) {
        pumpScheduled = true;
        setTimeout(pump, waitMs);
    }

    function pump() {
        pumpScheduled = false;

        const now = Date.now();
        while (starts.length && now - starts[0] >= windowMs) starts.shift();

        while (queue.length && starts.length < maxPerSecond) {
            starts.push(Date.now());
            queue.shift()();
        }

        if (queue.length && !pumpScheduled) {
            const oldestStart = starts[0] ?? Date.now();

            schedulePump(Math.max(windowMs - (Date.now() - oldestStart), 10));

        }
    }

    return function rateLimitGeniusRequest(task) {
        return new Promise((resolve, reject) => {
            // ! A failing task must settle its own promise only, never stall the queue.
            queue.push(() => Promise.resolve().then(task).then(resolve, reject));
            if (!pumpScheduled) schedulePump(0);
        });
    };
})(GENIUS_REQUESTS_PER_SECOND);

// ? Drop-in fetch for genius.com/api calls that charges the request against the shared budget above.
function geniusFetch(url, options) {
    return rateLimitGeniusRequest(() => fetch(url, options));
}

async function getApiData(id, type) {
    return rateLimitGeniusRequest(async () => {
        const response = await fetch(`https://genius.com/api/${type}/${id}`);
        if (!response.ok) throw new Error(`${type}/${id}: ${response.status} ${response.statusText}`);

        const json = await response.json();
        if (!json?.response) throw new Error(`${type}/${id}: missing response payload`);


        return json.response;
    });
}

// ? Loads many ids through the rate limiter and keeps the input order.
// * A single failed request returns null instead of rejecting the whole batch, so one rate limited song can't blank the page.
async function getApiDataBatch(ids, type) {
    const results = await Promise.all(ids.map(id =>
        getApiData(id, type).catch(error => {
            console.warn(`Request for ${type}/${id} failed:`, error);
            return null;
        })
    ));

    const failed = results.filter(result => result === null).length;
    if (failed) console.warn(`${failed} of ${ids.length} ${type} requests failed`);

    return results;
}

async function followId(id, type, action) {
    const url = `https://genius.com/api/${type}/${id}/${action}`;
    const response = await geniusFetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Cookie': document.cookie,
            'X-CSRF-Token': getCsrfToken(),
            'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
        },
        body: JSON.stringify({})
    });
    return response.ok;
}

async function deleteId(id, type) {
    try {
        const response = await geniusFetch(`https://genius.com/api/${type}/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Cookie": document.cookie,
                "X-CSRF-Token": getCsrfToken(),
                "User-Agent": "ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)"
            },
        });

        return response.ok;

    } catch (error) {
        console.error("Error during DELETE Request:", error);
        return false;
    }
}

async function createSong(payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch("https://genius.com/api/songs", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            console.error(`Error creating song: ${response.statusText}`);
            return null;
        }
        return await response.json();
    } catch (error) {
        console.error(`Error: ${error}`);
        return null;
    }
}


async function updateSongMetadata(songId, payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch(`https://genius.com/api/songs/${songId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify({ song: payload })
        });
        return response;
    } catch (error) {
        console.error(`Error: ${error}`);
    }
}

async function updateAlbumMetadata(albumId, payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch(`https://genius.com/api/albums/${albumId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Cookie": document.cookie,
                "X-CSRF-Token": getCsrfToken(),
                "User-Agent": "ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)"
            },
            body: JSON.stringify({ album: payload })
        });

        if (!response.ok) {
            console.error(`Error updating album metadata: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`Error: ${error}`);
    }
}


async function updateCoverArts(albumId, payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch(`https://genius.com/api/albums/${albumId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify({ album: payload })
        });

        if (!response.ok) {
            console.error(`Error updating album cover art: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`Error: ${error}`);
    }
}

async function updateTracklist(albumId, payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch(`https://genius.com/api/albums/${albumId}/tracklist`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify({ tracklist: payload })
        });
        return response.ok;
    } catch (error) {
        console.error(`Error: ${error}`);
        return false;
    }
}


async function updateSongLyrics(songId, payload) {
    if (Object.keys(payload).length === 0) return;
    try {
        const response = await geniusFetch(`https://genius.com/api/songs/${songId}/lyrics`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            console.error(`Error updating song lyrics: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`Error: ${error}`);
    }
}


async function updateSongMetadata2(song, updates) {
    if (Object.keys(updates).length === 0) return;

    const needsTitleUpdate = typeof updates.title === 'string';
    const isPublished = song.published === true;

    try {
        if (needsTitleUpdate && isPublished) {
            const unpublishResponse = await geniusFetch(`https://genius.com/api/songs/${song.id}/unpublish`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Cookie': document.cookie,
                    'X-CSRF-Token': getCsrfToken(),
                    'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
                }
            });

            if (!unpublishResponse.ok) {
                console.error(`Error unpublishing song ${song.id}: ${unpublishResponse.statusText}`);
                return;
            }
        }

        const updateResponse = await geniusFetch(`https://genius.com/api/songs/${song.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Cookie': document.cookie,
                'X-CSRF-Token': getCsrfToken(),
                'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
            },
            body: JSON.stringify({ song: updates })
        });

        if (!updateResponse.ok) {
            console.error(`Error updating song metadata: ${updateResponse.statusText}`);
            return;
        }

        if (needsTitleUpdate && isPublished) {
            const publishResponse = await geniusFetch(`https://genius.com/api/songs/${song.id}/publish`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Cookie': document.cookie,
                    'X-CSRF-Token': getCsrfToken(),
                    'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
                }
            });

            if (!publishResponse.ok) {
                console.error(`Error publishing song ${song.id}: ${publishResponse.statusText}`);
            }
        }
    } catch (error) {
        console.error(`Error processing song ${song.id}:`, error);
    }
}



async function toggleFollowSong(songId, action) {
    const url = `https://genius.com/api/songs/${songId}/${action}`;
    const response = await geniusFetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Cookie': document.cookie,
            'X-CSRF-Token': getCsrfToken(),
            'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
        },
        body: JSON.stringify({})
    });
    return response.ok;
}

async function sendCoverArts(imageUrl, albumId) {
    const payload = {
        album_id: albumId,
        cover_art: {
            image_url: imageUrl
        }
    };

    try {
        const response = await geniusFetch("https://genius.com/api/cover_arts/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Cookie": document.cookie,
                "X-CSRF-Token": getCsrfToken(),
                "User-Agent": "ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)"
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

        const json = await response.json();
        coverId = json.response.cover_art.id;
        return coverId;
    } catch (error) {
        console.error("Error during POST Request:", error);
    }
}

async function deleteCoverArts(coverId) {
    try {
        const response = await geniusFetch(`https://genius.com/api/cover_arts/${coverId}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Cookie": document.cookie,
                "X-CSRF-Token": getCsrfToken(),
                "User-Agent": "ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)"
            },
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

    } catch (error) {
        console.error("Error during DELETE Request:", error);
    }
}

async function moveCoverArts(position, coverId, coverArts) {
    let payload = {};

    if (position === 1) {
        const coverBelowId = coverArts[position - 1].id;

        payload = {
            below_id: coverBelowId
        };
    } else if (position > 1) {
        const coverBelowId = coverArts[position - 1].id;
        const coverAboveId = coverArts[position - 2].id;

        payload = {
            above_id: coverAboveId,
            below_id: coverBelowId
        };
    }

    try {
        const response = await geniusFetch(`https://genius.com/api/cover_arts/${coverId}/move_between`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Cookie": document.cookie,
                "X-CSRF-Token": getCsrfToken(),
                "User-Agent": "ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)"
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

        const json = await response.json();
        return json;
    } catch (error) {
        console.error("Error:", error);
    }
}

async function sendUpdateRequest(songId, payload) {
    const url = `https://genius.com/api/songs/${songId}`;
    const response = await geniusFetch(url, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Cookie': document.cookie,
            'X-CSRF-Token': getCsrfToken(),
            'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
        },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        console.error(`Error during PUT Request for Song-ID ${songId}:`, response.statusText);
    } else {
        console.log(`Tags successfully saved for Song-ID ${songId}.`);
    }
}

async function fetchSuggestions(type, query) {
    const url = `https://genius.com/api/${type}/autocomplete?q=${encodeURIComponent(query)}&text_format=html,markdown`;
    const response = await geniusFetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Cookie': document.cookie,
            'X-CSRF-Token': getCsrfToken(),
            'User-Agent': 'ArtworkExtractorForGenius/0.8.7 (Artwork Extractor for Genius)'
        }
    });

    if (!response.ok) {
        console.error('Error:', response.statusText);
        return [];
    }
    const data = await response.json();
    return data.response[type];
}